# ruta-agents

AI copilots for **RUTA CARGO**, built as one platform:

- **Customs** — prepares Nicaraguan import declarations (DUCA-D drafts) for a licensed broker.
- **Import/Export** — tells staff and clients which documents each operation needs.
- **Logistics** — quotes freight and watches shipments for delays, customs holds and demurrage.
- **Sourcing** — finds suppliers, compares quotes on landed cost in Nicaragua, prepares RFQs.

Agents prepare and recommend; people approve. Nothing is filed with customs, sent to a supplier
or client, or awarded without a human decision. See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

> Status: platform core, the deterministic engine of every agent, and the AI layer (Anthropic
> Claude) are built and tested. Next: persistence workflows (cases, RFQs, shipments), Gmail
> sending/receiving for approved emails, MCP endpoint, OpenAPI and evals.

## Quick start

```bash
pnpm install
cp .env.example .env          # set SUPABASE_JWT_SECRET or SUPABASE_URL
docker compose up -d          # Postgres 16 + pgvector on localhost:54329
pnpm db:setup                 # migrations + sample seed (all rows is_sample = true)
pnpm dev                      # http://localhost:8787/health
pnpm import:tariff tariff.csv # load the official SAC tariff (+ embeddings if VOYAGE_API_KEY is set)
pnpm import:rates rates.csv   # load IVA / tax rates
```

Tests: `pnpm test` (set `TEST_DATABASE_URL` to also run the Postgres integration tests).

## API (all under `/api`, `Authorization: Bearer <Supabase access token>`)

| Method | Path                                            | Roles                        |
| ------ | ----------------------------------------------- | ---------------------------- |
| POST   | `/api/customs/calculate`                        | staff, broker                |
| POST   | `/api/customs/cross-check`                      | staff, broker                |
| POST   | `/api/customs/permits`                          | staff, broker                |
| GET    | `/api/trade/incoterms?lang=es`                  | any                          |
| POST   | `/api/trade/checklist`                          | staff, ops, broker, buyer    |
| POST   | `/api/logistics/quote`                          | staff, ops, buyer            |
| POST   | `/api/logistics/exceptions`                     | staff, ops                   |
| GET    | `/api/sourcing/suppliers?category=&q=&country=` | staff, buyer                 |
| POST   | `/api/sourcing/compare`                         | staff, buyer                 |
| GET    | `/api/approvals?status=pending`                 | any                          |
| POST   | `/api/approvals/:id/decision`                   | the approval's required role |

### AI endpoints (`/api/ai`, need `ANTHROPIC_API_KEY`)

| Method | Path                              | Roles                     | What it does                                                                                  |
| ------ | --------------------------------- | ------------------------- | --------------------------------------------------------------------------------------------- |
| POST   | `/api/ai/customs/extract`         | staff, broker             | Reads invoices / packing lists / BL / AWB / certificates (PDF or photo) and cross-checks them |
| POST   | `/api/ai/customs/classify`        | staff, broker             | Suggests up to 3 SAC codes with GRI reasoning, only from codes found in the tariff table      |
| POST   | `/api/ai/sourcing/parse-request`  | staff, buyer              | Turns a client's request (text or files) into RFQ items                                       |
| POST   | `/api/ai/sourcing/extract-quote`  | staff, buyer              | Reads a supplier reply; every price is checked against the email text                         |
| POST   | `/api/ai/sourcing/draft-rfq`      | buyer                     | Drafts the RFQ email in the supplier's language and puts it in the approvals inbox            |
| POST   | `/api/ai/logistics/client-update` | ops, staff                | Detects shipment issues and drafts a client notice for ops approval                           |
| POST   | `/api/ai/trade/explain`           | staff, ops, broker, buyer | Builds the document checklist and explains it in plain language                               |

Files are sent as `{ name, mimeType, url }` with a **signed Supabase Storage URL** (only your
`SUPABASE_URL` host is accepted) or `{ name, mimeType, base64 }` for small uploads.

How the AI is kept safe: Claude only reads, writes and chooses; all numbers, conversions and
rates come from code and tables. Replies must match a strict schema (checked twice), the model
can only pick tariff codes the database search returned, extracted prices must appear in the
supplier's email, supplier/client text is treated as data (never as instructions), every call is
logged with prompt version and model, and emails only go out after a person approves them.

Roles come from the Supabase user's `app_metadata.ruta_roles`, e.g. `["staff", "broker"]`
(set with the Supabase admin API or a custom access-token hook). `admin` can do everything.

Calling from the Lovable app:

```ts
const { data } = await supabase.auth.getSession();
const res = await fetch(`${import.meta.env.VITE_RUTA_AGENTS_URL}/api/logistics/quote`, {
  method: 'POST',
  headers: {
    Authorization: `Bearer ${data.session?.access_token}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    date: new Date().toISOString().slice(0, 10),
    mode: 'air',
    origin: 'USMIA',
    destination: 'NIMGA',
    packages: [{ qty: 2, lengthCm: 60, widthCm: 40, heightCm: 40, weightKg: 10 }],
    lang: 'es',
  }),
});
```

## Reference data

All seeded tariffs, tax rates, permits, trade agreements, document rules, freight rates and
suppliers are **illustrative samples** (`is_sample = true`); results that use them are marked as
estimates. Load official data before real use.
