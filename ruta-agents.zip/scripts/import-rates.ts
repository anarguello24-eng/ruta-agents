import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import { parseCsv, TaxRateRowSchema } from '../src/agents/customs/reference/csv.js';
import { upsertTaxRateRows } from '../src/agents/customs/reference/upsert.js';
import { loadConfig } from '../src/core/config.js';
import { createDb } from '../src/core/db/client.js';

// Usage: pnpm import:rates path/to/rates.csv   (columns: see seed/ni_tax_rates.sample.csv)
const path = process.argv[2];
if (!path) {
  console.error('usage: pnpm import:rates <file.csv>');
  process.exit(1);
}
const config = loadConfig();
const { sql, close } = createDb(config.DATABASE_URL, { ssl: config.DATABASE_SSL, max: 1 });
try {
  const rows = parseCsv(await readFile(path, 'utf8'), TaxRateRowSchema);
  console.log(`Upserted ${await sql.begin((tx) => upsertTaxRateRows(tx, rows))} tax rate rows.`);
} finally {
  await close();
}
