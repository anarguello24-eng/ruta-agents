import 'dotenv/config';
import { loadConfig } from '../src/core/config.js';
import { MIGRATIONS_DIR } from '../src/core/paths.js';
import { createDb } from '../src/core/db/client.js';
import { runMigrations } from '../src/core/db/migrate.js';

const config = loadConfig();
const { sql, close } = createDb(config.DATABASE_URL, { ssl: config.DATABASE_SSL, max: 1 });
try {
  const applied = await runMigrations(sql, MIGRATIONS_DIR);
  console.log(applied.length ? `Applied: ${applied.join(', ')}` : 'Database is up to date.');
} finally {
  await close();
}
