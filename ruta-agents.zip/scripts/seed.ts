import 'dotenv/config';
import { loadConfig } from '../src/core/config.js';
import { SEED_DIR } from '../src/core/paths.js';
import { createDb } from '../src/core/db/client.js';
import { seedAll } from '../src/seed.js';

const config = loadConfig();
const { sql, close } = createDb(config.DATABASE_URL, { ssl: config.DATABASE_SSL, max: 1 });
try {
  const r = await sql.begin((tx) => seedAll(tx, SEED_DIR));
  console.log('Seeded sample reference data (all rows is_sample = true):', JSON.stringify(r));
} finally {
  await close();
}
