import 'dotenv/config';
import { readFile } from 'node:fs/promises';
import { parseCsv, TariffRowSchema } from '../src/agents/customs/reference/csv.js';
import { upsertTariffRows } from '../src/agents/customs/reference/upsert.js';
import { embedMissingTariffRows } from '../src/agents/customs/tariff-search.js';
import { loadConfig } from '../src/core/config.js';
import { createDb } from '../src/core/db/client.js';
import { createLLMProvider } from '../src/core/llm/index.js';

// Usage: pnpm import:tariff path/to/tariff.csv   (columns: see seed/ni_tariff_sac.sample.csv)
const path = process.argv[2];
if (!path) {
  console.error('usage: pnpm import:tariff <file.csv>');
  process.exit(1);
}
const config = loadConfig();
const { sql, close } = createDb(config.DATABASE_URL, { ssl: config.DATABASE_SSL, max: 1 });
try {
  const rows = parseCsv(await readFile(path, 'utf8'), TariffRowSchema);
  const n = await sql.begin((tx) => upsertTariffRows(tx, rows));
  console.log(
    `Upserted ${n} tariff rows (${rows.filter((r) => r.is_sample).length} flagged as samples).`,
  );
  const provider = createLLMProvider(config);
  if (provider && config.VOYAGE_API_KEY) {
    console.log(
      `Embedded ${await embedMissingTariffRows(sql, provider)} rows for semantic search.`,
    );
  } else {
    console.log(
      'VOYAGE_API_KEY / ANTHROPIC_API_KEY not set: skipped embeddings (keyword search still works).',
    );
  }
} finally {
  await close();
}
