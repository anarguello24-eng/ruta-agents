# Architecture

One deployable service (`ruta-agents`), one Postgres database (Supabase), one schema per agent.
Agents call each other in-process, so a sourcing comparison can use the logistics quote engine
and the customs duty calculator without network hops.

```
                RUTA CARGO web app (Lovable)  ── Supabase session token ──┐
                                                                          ▼
┌───────────────────────────────── ruta-agents (Hono) ─────────────────────────────────┐
│  /api/*  auth (Supabase JWT, roles: staff, broker, buyer, ops, admin)                 │
│                                                                                       │
│  Sourcing ──uses──► Logistics (freight quote)                                         │
│     │      └──uses──► Customs (DAI/ISC/IVA)  ◄──uses── Import/Export (permits)        │
│     └──uses──► Trade/Incoterms 2020 ◄──────────── Customs (CIF from any Incoterm)     │
│                                                                                       │
│  core: approvals queue · audit log · LLM provider + zod validation · agent loop       │
│        money (exact decimals) · effective-dated rates · bilingual flags               │
└───────────────────────────────────────────────────────────────────────────────────────┘
                 │ schemas: core, customs, trade, logistics, sourcing
                 ▼
            Postgres + pgvector
```

## The agents

| Agent         | Deterministic engine (built)                                                                                    | AI layer (next)                                                          | Human checkpoint                         |
| ------------- | --------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ | ---------------------------------------- |
| Customs       | CIF/DAI/ISC/IVA calculator, document cross-checks, permits                                                      | document extraction, SAC classification                                  | broker approves every line and the case  |
| Import/Export | Incoterms 2020 matrix, document checklist, trade agreements                                                     | explain requirements to clients, draft documents                         | staff verifies documents                 |
| Logistics     | freight quotes (chargeable weight, breaks, W/M, FCL, surcharges), shipment status rules, delay/demurrage alerts | read carrier updates, draft client notices                               | ops approves client messages             |
| Sourcing      | landed-cost comparison and scoring, supplier search, RFQ status flow                                            | parse requests, draft RFQ emails, extract quotes with price verification | buyer approves every email and the award |

## Trust model

1. The model never does arithmetic or recalls rates. It calls tools; tools read versioned tables.
2. Every model reply is validated against a zod schema, retried once with the error, then fails visibly.
3. Every AI call is logged with prompt id@version, model, input hash, raw and validated output.
4. Outbound effects are queued in `core.approvals` and executed only after a human with the
   required role approves (edits are allowed and logged).
5. Sample reference data is flagged everywhere it is used.

## AI layer

`src/core/llm/anthropic.ts` calls Claude (`LLM_MODEL`, default `claude-opus-5-5`) through the
official SDK with structured outputs (the reply is constrained to the zod schema and validated
again in `generate.ts`), a cached system prompt, server-side refusal fallback, and PDF/image
input for document reading. Embeddings for semantic tariff search come from Voyage AI.
Prompts live in `src/prompts/<agent>/<task>.v<N>.ts`; the audit log records `id@version`.
