import 'dotenv/config';
import { serve } from '@hono/node-server';
import { createApp } from './app.js';
import { loadConfig } from './core/config.js';
import { createDb } from './core/db/client.js';

const config = loadConfig();
const db = createDb(config.DATABASE_URL, { ssl: config.DATABASE_SSL });
const app = createApp({ config, db });

const server = serve({ fetch: app.fetch, port: config.PORT }, (info) => {
  console.log(`ruta-agents listening on :${info.port}`);
});

const shutdown = () => {
  server.close();
  void db.close().finally(() => process.exit(0));
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
