import type { Queryable } from './core/db/client.js';
import { seedSampleData as seedCustoms } from './agents/customs/seed.js';
import { seedLogistics } from './agents/logistics/reference.js';
import { seedSourcing } from './agents/sourcing/suppliers.js';
import { seedTrade } from './agents/trade/seed.js';

/** Loads every agent's sample reference data (all rows flagged is_sample = true). */
export async function seedAll(sql: Queryable, seedDir: string) {
  return {
    customs: await seedCustoms(sql, seedDir),
    trade: await seedTrade(sql, seedDir),
    logistics: await seedLogistics(sql, seedDir),
    sourcing: await seedSourcing(sql, seedDir),
  };
}
