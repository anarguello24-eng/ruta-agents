import { Hono, type Context } from 'hono';
import { z } from 'zod';
import { classifyProduct } from './agents/customs/ai/classify.js';
import { extractDocuments } from './agents/customs/ai/extract.js';
import { draftClientUpdate } from './agents/logistics/ai/client-update.js';
import { detectExceptions, SHIPMENT_STATUSES } from './agents/logistics/tracking.js';
import { draftRfqEmail } from './agents/sourcing/ai/draft-rfq.js';
import { extractQuote } from './agents/sourcing/ai/extract-quote.js';
import { parsePurchaseRequest } from './agents/sourcing/ai/parse-request.js';
import { explainChecklist } from './agents/trade/ai/explain.js';
import { buildChecklist, ChecklistInputSchema } from './agents/trade/checklist.js';
import { DbCustomsReference } from './agents/customs/rate-source.js';
import { agreementsBetween, DbTradeReference } from './agents/trade/reference.js';
import type { AiDeps } from './core/ai/context.js';
import { requireRole, type AuthEnv } from './core/auth.js';
import type { Queryable } from './core/db/client.js';
import { AppError } from './core/errors.js';
import { FileSpecSchema, loadFiles } from './core/files.js';
import type { LLMProvider } from './core/llm/provider.js';

const langS = z.enum(['es', 'en']).default('es');
const dateS = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
const today = () => new Date().toISOString().slice(0, 10);
const body = async (c: Context) => {
  try {
    return await c.req.json();
  } catch {
    return {};
  }
};

/**
 * AI endpoints under /api/ai. Each one validates input, calls the model through the validated,
 * audited generation path, and returns drafts or suggestions. Outbound messages are only queued
 * in the approvals inbox; nothing is sent from here.
 */
export function aiRoutes(deps: {
  sql: Queryable;
  provider: LLMProvider | null;
  timeoutMs: number;
  allowedFileHosts: string[];
}) {
  const ai = new Hono<AuthEnv>();
  const files = (specs: z.infer<typeof FileSpecSchema>[]) =>
    loadFiles(specs, { allowedHosts: deps.allowedFileHosts });

  ai.use('*', async (_c, next) => {
    if (!deps.provider)
      throw new AppError(
        503,
        'ai_not_configured',
        'Set ANTHROPIC_API_KEY to enable the AI features',
      );
    await next();
  });
  const d = (): AiDeps => ({ provider: deps.provider!, sql: deps.sql, timeoutMs: deps.timeoutMs });

  // ---- Customs ----
  ai.post('/customs/extract', requireRole('staff', 'broker'), async (c) => {
    const input = z
      .object({
        lang: langS,
        country: z.string().length(2).toUpperCase().default('NI'),
        caseId: z.string().uuid().nullable().default(null),
        files: z.array(FileSpecSchema).min(1).max(10),
      })
      .parse(await body(c));
    const trade = new DbTradeReference(deps.sql);
    const all = await trade.agreements();
    const partners = [...new Set(all.flatMap((a) => a.members.map((m) => m.country)))];
    const preferentialOrigins = partners.filter(
      (p) => p !== input.country && agreementsBetween(all, input.country, p, today()).length,
    );
    return c.json(
      await extractDocuments(d(), {
        ...input,
        files: await files(input.files),
        preferentialOrigins,
      }),
    );
  });

  ai.post('/customs/classify', requireRole('staff', 'broker'), async (c) => {
    const input = z
      .object({
        lang: langS,
        country: z.string().length(2).toUpperCase().default('NI'),
        date: dateS.default(today()),
        description: z.string().min(3).max(4000),
      })
      .parse(await body(c));
    return c.json(await classifyProduct(d(), input));
  });

  // ---- Sourcing ----
  ai.post('/sourcing/parse-request', requireRole('staff', 'buyer'), async (c) => {
    const input = z
      .object({
        lang: langS,
        text: z.string().max(20000).default(''),
        files: z.array(FileSpecSchema).max(5).default([]),
      })
      .refine((v) => v.text.trim() || v.files.length, 'give text or files')
      .parse(await body(c));
    return c.json(await parsePurchaseRequest(d(), { ...input, files: await files(input.files) }));
  });

  ai.post('/sourcing/extract-quote', requireRole('staff', 'buyer'), async (c) => {
    const input = z
      .object({
        lang: langS,
        emailText: z.string().min(1).max(50000),
        attachments: z.array(FileSpecSchema).max(5).default([]),
        items: z.array(z.object({ ref: z.string().min(1), description: z.string().min(1) })).min(1),
      })
      .parse(await body(c));
    return c.json(
      await extractQuote(d(), { ...input, attachments: await files(input.attachments) }),
    );
  });

  ai.post('/sourcing/draft-rfq', requireRole('buyer'), async (c) => {
    const input = z
      .object({
        rfqRef: z.string().regex(/^[A-Z0-9-]{3,40}$/),
        supplierId: z.string().uuid(),
        replyBy: dateS,
        items: z
          .array(
            z.object({
              ref: z.string(),
              description: z.string(),
              specs: z.string().nullable().optional(),
              quantity: z.union([z.number(), z.string()]),
              unit: z.string(),
            }),
          )
          .min(1),
      })
      .parse(await body(c));
    const user = c.get('user');
    return c.json(
      await draftRfqEmail(d(), {
        ...input,
        buyerName: user.email ?? 'RUTA CARGO',
        requestedBy: user.id,
      }),
      201,
    );
  });

  // ---- Logistics ----
  ai.post('/logistics/client-update', requireRole('ops', 'staff'), async (c) => {
    const input = z
      .object({
        lang: langS,
        clientEmail: z.string().email(),
        clientName: z.string().min(1),
        shipment: z.object({
          reference: z.string(),
          mode: z.enum(['air', 'courier', 'sea_lcl', 'sea_fcl', 'ground']),
          origin: z.string(),
          destination: z.string(),
          status: z.enum(SHIPMENT_STATUSES),
          etaPromised: z.string().nullable().default(null),
          etaCurrent: z.string().nullable().default(null),
          statusSince: z.coerce.date(),
          lastEventAt: z.coerce.date().nullable().default(null),
          arrivedAt: z.coerce.date().nullable().default(null),
          freeDays: z.number().int().nullable().default(null),
        }),
      })
      .parse(await body(c));
    const flags = detectExceptions(input.shipment, new Date(), input.lang);
    const { reference, mode, origin, destination, status, etaPromised, etaCurrent } =
      input.shipment;
    const r = await draftClientUpdate(d(), {
      lang: input.lang,
      clientEmail: input.clientEmail,
      clientName: input.clientName,
      shipment: { reference, mode, origin, destination, status, etaPromised, etaCurrent },
      flags,
      requestedBy: c.get('user').id,
    });
    return c.json({ ...r, flags }, 201);
  });

  // ---- Import / export ----
  ai.post('/trade/explain', requireRole('staff', 'ops', 'broker', 'buyer'), async (c) => {
    const input = ChecklistInputSchema.parse({ date: today(), ...(await body(c)) });
    const lang = input.lang;
    const checklist = await buildChecklist(
      input,
      new DbTradeReference(deps.sql),
      new DbCustomsReference(deps.sql),
    );
    return c.json({ checklist, explanation: await explainChecklist(d(), { lang, checklist }) });
  });

  return ai;
}
