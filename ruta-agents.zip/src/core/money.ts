import { Decimal } from 'decimal.js';

/**
 * Exact decimal arithmetic for every money/weight/rate computation. Never use JS floats for money.
 * Rounding is half-up (away from zero on .5), the convention used on customs and freight documents.
 */
export const Dec = Decimal.clone({ precision: 40, rounding: Decimal.ROUND_HALF_UP });
export type Dec = Decimal;

export type Num = Decimal.Value;

export const D = (v: Num): Decimal => new Dec(v);

/** Rounds to `dp` decimal places, half-up. */
export const round = (v: Num, dp = 2): Decimal =>
  new Dec(v).toDecimalPlaces(dp, Decimal.ROUND_HALF_UP);

/** Rounds up (ceiling) to `dp` decimal places; used for chargeable weight. */
export const roundUp = (v: Num, dp = 0): Decimal =>
  new Dec(v).toDecimalPlaces(dp, Decimal.ROUND_UP);

/** Fixed-point string for JSON output (e.g. "1234.50"). */
export const money = (v: Num, dp = 2): string => round(v, dp).toFixed(dp);

export const sum = (values: Num[]): Decimal => values.reduce<Decimal>((a, v) => a.plus(v), D(0));

export const pct = (amount: Num, percent: Num): Decimal => D(amount).times(percent).dividedBy(100);

export const max = (...values: Num[]): Decimal => Dec.max(...values);
export const min = (...values: Num[]): Decimal => Dec.min(...values);

/**
 * Splits `total` across `weights` proportionally so that the rounded parts add up exactly to the
 * rounded total (largest-remainder method). Used to prorate freight/insurance across lines.
 */
export function allocate(total: Num, weights: Num[], dp = 2): Decimal[] {
  const t = round(total, dp);
  const w = weights.map(D);
  const wSum = sum(w);
  if (w.length === 0) return [];
  if (wSum.isZero()) {
    // Equal split when no weights are available.
    return allocate(
      t,
      w.map(() => 1),
      dp,
    );
  }
  const unit = D(1).dividedBy(D(10).pow(dp));
  const exact = w.map((x) => t.times(x).dividedBy(wSum));
  const floored = exact.map((x) => x.toDecimalPlaces(dp, Decimal.ROUND_DOWN));
  let remainder = t.minus(sum(floored));
  const order = exact
    .map((x, i) => ({ i, frac: x.minus(floored[i]!) }))
    .sort((a, b) => b.frac.comparedTo(a.frac) || a.i - b.i);
  const out = [...floored];
  for (const { i } of order) {
    if (remainder.lessThan(unit)) break;
    out[i] = out[i]!.plus(unit);
    remainder = remainder.minus(unit);
  }
  return out;
}
