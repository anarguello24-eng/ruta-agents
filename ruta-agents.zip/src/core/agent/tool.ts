import type { z } from 'zod';

export interface ToolContext {
  lang: 'es' | 'en';
  country: string;
  signal?: AbortSignal;
}

/** A capability the agent loop (and the MCP server) can call. Inputs are zod-validated. */
export interface Tool<I extends z.ZodType = z.ZodType, O = unknown> {
  name: string;
  description: string;
  input: I;
  run(args: z.infer<I>, ctx: ToolContext): Promise<O>;
}

export const defineTool = <I extends z.ZodType, O>(t: Tool<I, O>): Tool<I, O> => t;
