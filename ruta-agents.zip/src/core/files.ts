import { z } from 'zod';
import { AppError } from './errors.js';
import type { LLMFile } from './llm/provider.js';

export const MAX_FILE_BYTES = 20 * 1024 * 1024;

export const FileSpecSchema = z
  .object({
    name: z.string().min(1).max(200),
    mimeType: z.string().min(3),
    /** Base64 content (small uploads). */
    base64: z.string().optional(),
    /** Signed Supabase Storage URL (preferred). */
    url: z.string().url().optional(),
  })
  .refine((f) => Boolean(f.base64) !== Boolean(f.url), 'give exactly one of base64 or url');
export type FileSpec = z.infer<typeof FileSpecSchema>;

/**
 * Loads files for the model. URLs must point at an allowed host (the project's Supabase URL),
 * so the API cannot be used to fetch arbitrary internal or external addresses.
 */
export async function loadFiles(
  specs: FileSpec[],
  opts: { allowedHosts: string[]; fetch?: typeof fetch },
): Promise<LLMFile[]> {
  const out: LLMFile[] = [];
  for (const f of specs) {
    let data: Uint8Array;
    if (f.base64) {
      data = new Uint8Array(Buffer.from(f.base64, 'base64'));
    } else {
      const u = new URL(f.url!);
      if (u.protocol !== 'https:' || !opts.allowedHosts.includes(u.host))
        throw new AppError(
          400,
          'file_url_not_allowed',
          `files must be signed URLs from ${opts.allowedHosts.join(', ') || 'Supabase Storage'}`,
        );
      const res = await (opts.fetch ?? fetch)(u, { redirect: 'error' });
      if (!res.ok)
        throw new AppError(
          502,
          'file_download_failed',
          `could not download ${f.name}: HTTP ${res.status}`,
        );
      const len = Number(res.headers.get('content-length') ?? 0);
      if (len > MAX_FILE_BYTES)
        throw new AppError(400, 'file_too_large', `${f.name} exceeds 20 MB`);
      data = new Uint8Array(await res.arrayBuffer());
    }
    if (data.byteLength > MAX_FILE_BYTES)
      throw new AppError(400, 'file_too_large', `${f.name} exceeds 20 MB`);
    if (!data.byteLength) throw new AppError(400, 'file_empty', `${f.name} is empty`);
    out.push({ name: f.name, mimeType: f.mimeType, data });
  }
  return out;
}
