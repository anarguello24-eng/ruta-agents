import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/** Project root: the nearest ancestor with package.json (works from src/ via tsx and from dist/). */
function findRoot(start: string): string {
  let dir = start;
  while (!existsSync(join(dir, 'package.json'))) {
    const parent = dirname(dir);
    if (parent === dir) throw new Error(`package.json not found above ${start}`);
    dir = parent;
  }
  return dir;
}

export const PROJECT_ROOT = findRoot(dirname(fileURLToPath(import.meta.url)));
export const MIGRATIONS_DIR = join(PROJECT_ROOT, 'migrations');
export const SEED_DIR = join(PROJECT_ROOT, 'seed');
