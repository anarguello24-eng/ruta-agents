/** A row from a versioned reference table (tariff, tax, freight rate, ...). */
export interface Versioned {
  effectiveFrom: string; // YYYY-MM-DD
  effectiveTo: string | null; // inclusive; null = open-ended
}

export const isoDate = (d: Date | string): string =>
  typeof d === 'string' ? d.slice(0, 10) : d.toISOString().slice(0, 10);

export function isEffective(row: Versioned, on: string): boolean {
  return row.effectiveFrom <= on && (row.effectiveTo === null || row.effectiveTo >= on);
}

/**
 * Picks the row in force on `on`. When several overlap (data-entry error) the one with the latest
 * `effectiveFrom` wins and `ambiguous` is true so callers can warn.
 */
export function selectEffective<T extends Versioned>(
  rows: T[],
  on: string,
): { row: T; ambiguous: boolean } | null {
  const candidates = rows
    .filter((r) => isEffective(r, on))
    .sort((a, b) => (a.effectiveFrom < b.effectiveFrom ? 1 : -1));
  if (!candidates.length) return null;
  return { row: candidates[0]!, ambiguous: candidates.length > 1 };
}

/** Reference to the exact reference-data row used for a number, attached to every result. */
export interface RateRef {
  table: string;
  id: string;
  effectiveFrom: string;
  isSample: boolean;
}
