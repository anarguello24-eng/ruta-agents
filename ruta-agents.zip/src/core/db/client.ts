import postgres from 'postgres';
import { drizzle, type PostgresJsDatabase } from 'drizzle-orm/postgres-js';

export type Db = PostgresJsDatabase;

/** A connection or an open transaction; both accept tagged-template queries. */
export type Queryable = postgres.Sql | postgres.TransactionSql;

export interface DbHandle {
  db: Db;
  sql: postgres.Sql;
  close: () => Promise<void>;
}

export function createDb(url: string, opts: { ssl?: boolean; max?: number } = {}): DbHandle {
  const sql = postgres(url, {
    ssl: opts.ssl ? 'require' : undefined,
    max: opts.max ?? 10,
    onnotice: () => {},
  });
  const db = drizzle(sql);
  return { db, sql, close: () => sql.end({ timeout: 5 }) };
}
