import { readdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type postgres from 'postgres';

const LOCK_KEY = 727_001; // arbitrary advisory-lock key for this service

/**
 * Applies `migrations/*.sql` in filename order. Each file runs in its own transaction and
 * is recorded in `public.ruta_customs_migrations` so it is applied at most once.
 */
export async function runMigrations(sql: postgres.Sql, dir: string): Promise<string[]> {
  const files = (await readdir(dir)).filter((f) => /^\d{4}_.+\.sql$/.test(f)).sort();
  const applied: string[] = [];

  await sql.begin(async (tx) => {
    await tx`SELECT pg_advisory_xact_lock(${LOCK_KEY})`;
    await tx`
      CREATE TABLE IF NOT EXISTS public.ruta_customs_migrations (
        name text PRIMARY KEY,
        applied_at timestamptz NOT NULL DEFAULT now()
      )`;
    const done = new Set(
      (await tx<{ name: string }[]>`SELECT name FROM public.ruta_customs_migrations`).map(
        (r) => r.name,
      ),
    );
    for (const file of files) {
      if (done.has(file)) continue;
      const body = await readFile(join(dir, file), 'utf8');
      await tx.unsafe(body);
      await tx`INSERT INTO public.ruta_customs_migrations (name) VALUES (${file})`;
      applied.push(file);
    }
  });

  return applied;
}
