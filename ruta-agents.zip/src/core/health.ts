import { Hono } from 'hono';
import type postgres from 'postgres';
import { SERVICE_NAME, SERVICE_VERSION } from './version.js';

export function healthRoutes(deps: { sql: postgres.Sql; defaultCountry: string }) {
  const app = new Hono();

  app.get('/health', async (c) => {
    const started = Date.now();
    try {
      const [ref] = await deps.sql<{ tariff_rows: number; sample_rows: number }[]>`
        SELECT count(*)::int AS tariff_rows,
               count(*) FILTER (WHERE is_sample)::int AS sample_rows
        FROM customs.tariff_sac
        WHERE country = ${deps.defaultCountry}`;
      return c.json({
        status: 'ok',
        service: SERVICE_NAME,
        version: SERVICE_VERSION,
        country: deps.defaultCountry,
        db: { status: 'ok', latencyMs: Date.now() - started },
        referenceData: {
          tariffRows: ref?.tariff_rows ?? 0,
          sampleTariffRows: ref?.sample_rows ?? 0,
        },
      });
    } catch (err) {
      return c.json(
        {
          status: 'degraded',
          service: SERVICE_NAME,
          version: SERVICE_VERSION,
          db: { status: 'error', error: err instanceof Error ? err.message : String(err) },
        },
        503,
      );
    }
  });

  return app;
}
