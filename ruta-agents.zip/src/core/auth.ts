import type { MiddlewareHandler } from 'hono';
import { createRemoteJWKSet, jwtVerify, type JWTPayload, type JWTVerifyGetKey } from 'jose';
import { AppError } from './errors.js';

/** Application roles. Stored in the Supabase user's `app_metadata.ruta_roles` (string array). */
export const ROLES = ['staff', 'broker', 'buyer', 'ops', 'admin'] as const;
export type Role = (typeof ROLES)[number];

export interface AuthUser {
  id: string;
  email: string | null;
  roles: Role[];
}

export type AuthEnv = { Variables: { user: AuthUser } };

export interface AuthOptions {
  /** Legacy Supabase projects: HS256 shared secret. */
  jwtSecret?: string;
  /** Newer Supabase projects: asymmetric keys published at /auth/v1/.well-known/jwks.json. */
  supabaseUrl?: string;
  audience?: string;
}

export type TokenVerifier = (token: string) => Promise<AuthUser>;

export function rolesFromClaims(payload: JWTPayload): Role[] {
  const meta = (payload.app_metadata ?? {}) as Record<string, unknown>;
  const raw = meta.ruta_roles ?? meta.roles ?? (meta.role ? [meta.role] : []);
  const list = Array.isArray(raw) ? raw : [];
  return [...new Set(list.filter((r): r is Role => ROLES.includes(r as Role)))];
}

export function createVerifier(opts: AuthOptions): TokenVerifier {
  let key: Uint8Array | JWTVerifyGetKey;
  if (opts.jwtSecret) key = new TextEncoder().encode(opts.jwtSecret);
  else if (opts.supabaseUrl)
    key = createRemoteJWKSet(new URL('/auth/v1/.well-known/jwks.json', opts.supabaseUrl));
  else throw new Error('Auth needs SUPABASE_JWT_SECRET or SUPABASE_URL');

  return async (token) => {
    const { payload } = await jwtVerify(token, key as Uint8Array, {
      audience: opts.audience ?? 'authenticated',
    });
    if (!payload.sub) throw new Error('token has no subject');
    return {
      id: payload.sub,
      email: typeof payload.email === 'string' ? payload.email : null,
      roles: rolesFromClaims(payload),
    };
  };
}

/** Rejects requests without a valid Supabase session token, or whose user has no RUTA role. */
export function requireAuth(verify: TokenVerifier): MiddlewareHandler<AuthEnv> {
  return async (c, next) => {
    const header = c.req.header('authorization') ?? '';
    const token = header.startsWith('Bearer ') ? header.slice(7).trim() : '';
    if (!token) throw new AppError(401, 'unauthenticated', 'missing bearer token');
    let user: AuthUser;
    try {
      user = await verify(token);
    } catch {
      throw new AppError(401, 'unauthenticated', 'invalid or expired token');
    }
    if (!user.roles.length) throw new AppError(403, 'forbidden', 'user has no RUTA role');
    c.set('user', user);
    await next();
  };
}

/** Allows the request when the user has any of `roles` (admin always passes). */
export function requireRole(...roles: Role[]): MiddlewareHandler<AuthEnv> {
  return async (c, next) => {
    const user = c.get('user');
    if (!hasRole(user, ...roles))
      throw new AppError(403, 'forbidden', `requires role: ${roles.join(' or ')}`);
    await next();
  };
}

export function hasRole(user: AuthUser | undefined, ...roles: Role[]): boolean {
  return Boolean(
    user && (user.roles.includes('admin') || roles.some((r) => user.roles.includes(r))),
  );
}
