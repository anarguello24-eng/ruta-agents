import { writeAudit, type AgentName } from './audit.js';
import { hasRole, type AuthUser, type Role } from './auth.js';
import type { Queryable } from './db/client.js';
import { AppError, conflict, forbidden, notFound } from './errors.js';

export type ApprovalStatus =
  'pending' | 'approved' | 'rejected' | 'executed' | 'failed' | 'cancelled';

export interface Approval {
  id: string;
  country: string;
  agent: AgentName;
  kind: string;
  refId: string | null;
  title: string;
  payload: unknown;
  status: ApprovalStatus;
  requiredRole: Role;
  requestedByType: 'ai' | 'user' | 'system';
  requestedBy: string | null;
  decidedBy: string | null;
  decidedAt: Date | null;
  decisionNote: string | null;
  executedAt: Date | null;
  result: unknown;
  error: string | null;
  createdAt: Date;
}

type Row = Record<string, unknown>;
const toApproval = (r: Row): Approval => ({
  id: r.id as string,
  country: r.country as string,
  agent: r.agent as AgentName,
  kind: r.kind as string,
  refId: (r.ref_id as string) ?? null,
  title: r.title as string,
  payload: r.payload,
  status: r.status as ApprovalStatus,
  requiredRole: r.required_role as Role,
  requestedByType: r.requested_by_type as Approval['requestedByType'],
  requestedBy: (r.requested_by as string) ?? null,
  decidedBy: (r.decided_by as string) ?? null,
  decidedAt: (r.decided_at as Date) ?? null,
  decisionNote: (r.decision_note as string) ?? null,
  executedAt: (r.executed_at as Date) ?? null,
  result: r.result ?? null,
  error: (r.error as string) ?? null,
  createdAt: r.created_at as Date,
});

export interface ApprovalRequest {
  agent: AgentName;
  kind: string;
  title: string;
  payload: unknown;
  requiredRole: Role;
  refId?: string | null;
  country?: string;
  requestedByType: 'ai' | 'user' | 'system';
  requestedBy?: string | null;
}

/** Queues an outbound action. Nothing happens outside the system until a human approves it. */
export async function requestApproval(sql: Queryable, req: ApprovalRequest): Promise<Approval> {
  const [row] = await sql<Row[]>`
    INSERT INTO core.approvals
      (country, agent, kind, ref_id, title, payload, required_role, requested_by_type, requested_by)
    VALUES
      (${req.country ?? 'NI'}, ${req.agent}, ${req.kind}, ${req.refId ?? null}, ${req.title},
       ${JSON.stringify(req.payload)}::jsonb, ${req.requiredRole}, ${req.requestedByType},
       ${req.requestedBy ?? null})
    RETURNING *`;
  const a = toApproval(row!);
  await writeAudit(sql, req.agent, {
    country: a.country,
    refId: a.refId,
    entityType: 'approval',
    entityId: a.id,
    // AI-call audit rows are reserved for model calls; an agent's request is a system action.
    actorType: req.requestedByType === 'ai' ? 'system' : req.requestedByType,
    actorId:
      req.requestedByType === 'ai'
        ? `ai:${req.requestedBy ?? req.agent}`
        : (req.requestedBy ?? null),
    action: `approval.requested:${req.kind}`,
    after: req.payload,
  });
  return a;
}

export async function getApproval(sql: Queryable, id: string): Promise<Approval> {
  const [row] = await sql<Row[]>`SELECT * FROM core.approvals WHERE id = ${id}`;
  if (!row) throw notFound('approval');
  return toApproval(row);
}

export async function listApprovals(
  sql: Queryable,
  f: { status?: ApprovalStatus; agent?: AgentName; refId?: string; limit?: number } = {},
): Promise<Approval[]> {
  const rows = await sql<Row[]>`
    SELECT * FROM core.approvals
    WHERE (${f.status ?? null}::text IS NULL OR status = ${f.status ?? null})
      AND (${f.agent ?? null}::text IS NULL OR agent = ${f.agent ?? null})
      AND (${f.refId ?? null}::uuid IS NULL OR ref_id = ${f.refId ?? null})
    ORDER BY created_at
    LIMIT ${f.limit ?? 100}`;
  return rows.map(toApproval);
}

/**
 * Approves or rejects a pending item. The approver may edit the payload (e.g. fix an email draft);
 * the original and edited versions both go to the audit log.
 */
export async function decideApproval(
  sql: Queryable,
  args: {
    id: string;
    user: AuthUser;
    decision: 'approve' | 'reject';
    note?: string;
    editedPayload?: unknown;
  },
): Promise<Approval> {
  const [row] = await sql<Row[]>`SELECT * FROM core.approvals WHERE id = ${args.id} FOR UPDATE`;
  if (!row) throw notFound('approval');
  const current = toApproval(row);
  if (!hasRole(args.user, current.requiredRole))
    throw forbidden(`approval requires role: ${current.requiredRole}`);
  if (current.status !== 'pending')
    throw conflict(`approval is already ${current.status}`, { status: current.status });
  if (args.decision === 'reject' && args.editedPayload !== undefined)
    throw new AppError(400, 'bad_request', 'cannot edit a rejected payload');

  const status = args.decision === 'approve' ? 'approved' : 'rejected';
  const payload = args.editedPayload ?? current.payload;
  const [updated] = await sql<Row[]>`
    UPDATE core.approvals
    SET status = ${status}, decided_by = ${args.user.id}, decided_at = now(),
        decision_note = ${args.note ?? null}, payload = ${JSON.stringify(payload)}::jsonb
    WHERE id = ${args.id}
    RETURNING *`;
  await writeAudit(sql, current.agent, {
    country: current.country,
    refId: current.refId,
    entityType: 'approval',
    entityId: current.id,
    actorType: 'user',
    actorId: args.user.id,
    action: `approval.${status}:${current.kind}`,
    before: current.payload,
    after: args.editedPayload === undefined ? undefined : payload,
  });
  return toApproval(updated!);
}

/** Records the outcome of executing an approved action (e.g. the email was sent). */
export async function markExecuted(
  sql: Queryable,
  id: string,
  outcome: { ok: true; result?: unknown } | { ok: false; error: string },
): Promise<Approval> {
  const [row] = await sql<Row[]>`SELECT * FROM core.approvals WHERE id = ${id} FOR UPDATE`;
  if (!row) throw notFound('approval');
  const a = toApproval(row);
  if (a.status !== 'approved') throw conflict(`cannot execute an approval that is ${a.status}`);
  const [updated] = outcome.ok
    ? await sql<Row[]>`
        UPDATE core.approvals SET status = 'executed', executed_at = now(),
          result = ${JSON.stringify(outcome.result ?? null)}::jsonb
        WHERE id = ${id} RETURNING *`
    : await sql<Row[]>`
        UPDATE core.approvals SET status = 'failed', error = ${outcome.error}
        WHERE id = ${id} RETURNING *`;
  await writeAudit(sql, a.agent, {
    country: a.country,
    refId: a.refId,
    entityType: 'approval',
    entityId: a.id,
    actorType: 'system',
    action: outcome.ok ? `approval.executed:${a.kind}` : `approval.failed:${a.kind}`,
    after: outcome.ok ? (outcome.result ?? null) : undefined,
    error: outcome.ok ? null : outcome.error,
  });
  return toApproval(updated!);
}
