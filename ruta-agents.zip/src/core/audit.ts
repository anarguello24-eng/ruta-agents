import { createHash } from 'node:crypto';
import type { Queryable } from './db/client.js';

export type AgentName = 'customs' | 'sourcing' | 'logistics' | 'trade';

/** Each agent schema has its own append-only audit_log; this is its top-level record column. */
const REF_COLUMN: Record<AgentName, string> = {
  customs: 'case_id',
  sourcing: 'rfq_id',
  logistics: 'shipment_id',
  trade: 'operation_id',
};

export interface AuditEntry {
  country?: string;
  refId?: string | null;
  entityType: string;
  entityId?: string | null;
  actorType: 'ai' | 'user' | 'system';
  actorId?: string | null;
  action: string;
  promptVersion?: string | null;
  model?: string | null;
  inputHash?: string | null;
  rawOutput?: string | null;
  validatedOutput?: unknown;
  before?: unknown;
  after?: unknown;
  error?: string | null;
}

/** Stable SHA-256 of any JSON-serializable input (object keys sorted). */
export function hashInput(input: unknown): string {
  return createHash('sha256').update(stableStringify(input)).digest('hex');
}

export function stableStringify(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v) ?? 'null';
  if (Array.isArray(v)) return `[${v.map(stableStringify).join(',')}]`;
  const o = v as Record<string, unknown>;
  return `{${Object.keys(o)
    .sort()
    .filter((k) => o[k] !== undefined)
    .map((k) => `${JSON.stringify(k)}:${stableStringify(o[k])}`)
    .join(',')}}`;
}

const j = (v: unknown) => (v === undefined || v === null ? null : JSON.stringify(v));

export async function writeAudit(sql: Queryable, agent: AgentName, e: AuditEntry): Promise<number> {
  const table = sql(`${agent}.audit_log`);
  const refCol = sql(REF_COLUMN[agent]);
  const [row] = await sql<{ id: number }[]>`
    INSERT INTO ${table}
      (country, ${refCol}, entity_type, entity_id, actor_type, actor_id, action, prompt_version,
       model, input_hash, raw_output, validated_output, before, after, error)
    VALUES
      (${e.country ?? 'NI'}, ${e.refId ?? null}, ${e.entityType}, ${e.entityId ?? null},
       ${e.actorType}, ${e.actorId ?? null}, ${e.action}, ${e.promptVersion ?? null},
       ${e.model ?? null}, ${e.inputHash ?? null}, ${e.rawOutput ?? null},
       ${j(e.validatedOutput)}::jsonb, ${j(e.before)}::jsonb, ${j(e.after)}::jsonb, ${e.error ?? null})
    RETURNING id`;
  return Number(row!.id);
}

/** Every agent's audit table, so migrations can create identical ones. */
export const AUDIT_TABLES = Object.keys(REF_COLUMN) as AgentName[];
