export const SERVICE_NAME = 'ruta-agents';
export const SERVICE_VERSION = '0.1.0';
