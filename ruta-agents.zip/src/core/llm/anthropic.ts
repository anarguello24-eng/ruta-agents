import type Anthropic from '@anthropic-ai/sdk';
import { zodOutputFormat } from '@anthropic-ai/sdk/helpers/zod';
import type {
  Effort,
  GenerateRequest,
  GenerateResponse,
  LLMFile,
  LLMProvider,
} from './provider.js';

/** Server-side fallback: if a request is declined, the API re-runs it on Anthropic's recommended model. */
const FALLBACK_BETA = 'server-side-fallback-2026-07-01';

export class LLMRefusalError extends Error {
  constructor(public readonly category: string | null) {
    super(`model declined the request${category ? ` (${category})` : ''}`);
  }
}

export interface AnthropicProviderOptions {
  client: Anthropic;
  model: string;
  visionModel: string;
  effort: Effort;
  maxTokens?: number;
  embeddings?: { apiKey: string; model: string; dimensions: number; fetch?: typeof fetch };
}

const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'] as const;
type ImageType = (typeof IMAGE_TYPES)[number];

/** Turns downloaded files into document/image content blocks (base64). */
export function fileBlocks(files: LLMFile[]): Anthropic.Beta.BetaContentBlockParam[] {
  return files.map((f): Anthropic.Beta.BetaContentBlockParam => {
    const data = Buffer.from(f.data).toString('base64');
    if (f.mimeType === 'application/pdf')
      return {
        type: 'document',
        title: f.name,
        source: { type: 'base64', media_type: 'application/pdf', data },
      };
    if ((IMAGE_TYPES as readonly string[]).includes(f.mimeType))
      return {
        type: 'image',
        source: { type: 'base64', media_type: f.mimeType as ImageType, data },
      };
    if (f.mimeType.startsWith('text/'))
      return {
        type: 'document',
        title: f.name,
        source: {
          type: 'text',
          media_type: 'text/plain',
          data: Buffer.from(f.data).toString('utf8'),
        },
      };
    throw new Error(
      `unsupported file type ${f.mimeType} (${f.name}); use PDF, JPEG, PNG, GIF, WebP or text`,
    );
  });
}

/**
 * Claude via the official SDK. Structured outputs constrain the reply to the zod schema (the
 * caller validates again), the system prompt is cached, and declined requests fall back
 * server-side. Embeddings come from Voyage AI, Anthropic's recommended embeddings provider.
 */
export class AnthropicProvider implements LLMProvider {
  readonly name = 'anthropic';

  constructor(private readonly opts: AnthropicProviderOptions) {}

  async generateJSON(req: GenerateRequest): Promise<GenerateResponse> {
    const system = req.messages
      .filter((m) => m.role === 'system')
      .map((m) => m.content)
      .join('\n\n');
    const turns = req.messages.filter((m) => m.role !== 'system');
    if (turns[0]?.role !== 'user') throw new Error('conversation must start with a user message');

    const messages: Anthropic.Beta.BetaMessageParam[] = turns.map((m, i) => {
      if (i === 0 && req.files?.length)
        return {
          role: 'user',
          content: [...fileBlocks(req.files), { type: 'text', text: m.content }],
        };
      return { role: m.role as 'user' | 'assistant', content: m.content };
    });

    const format = req.schema
      ? (({ type, schema }) => ({ type, schema }))(zodOutputFormat(req.schema))
      : { type: 'json_schema' as const, schema: req.jsonSchema };

    const stream = this.opts.client.beta.messages.stream(
      {
        model: req.purpose === 'vision' ? this.opts.visionModel : this.opts.model,
        max_tokens: this.opts.maxTokens ?? 32_000,
        ...(system
          ? { system: [{ type: 'text', text: system, cache_control: { type: 'ephemeral' } }] }
          : {}),
        messages,
        output_config: { effort: req.effort ?? this.opts.effort, format },
        betas: [FALLBACK_BETA],
        fallbacks: 'default',
      },
      { signal: req.signal },
    );
    const msg = await stream.finalMessage();

    if (msg.stop_reason === 'refusal')
      throw new LLMRefusalError(msg.stop_details?.category ?? null);
    if (msg.stop_reason === 'max_tokens') throw new Error('model output was cut off at max_tokens');
    const raw = msg.content
      .filter((b): b is Anthropic.Beta.BetaTextBlock => b.type === 'text')
      .map((b) => b.text)
      .join('');
    return { raw, model: msg.model };
  }

  async embed(texts: string[], opts: { kind?: 'query' | 'document' } = {}): Promise<number[][]> {
    const e = this.opts.embeddings;
    if (!e) throw new Error('embeddings are not configured (set VOYAGE_API_KEY)');
    if (!texts.length) return [];
    const out: number[][] = [];
    for (let i = 0; i < texts.length; i += 128) {
      const res = await (e.fetch ?? fetch)('https://api.voyageai.com/v1/embeddings', {
        method: 'POST',
        headers: { authorization: `Bearer ${e.apiKey}`, 'content-type': 'application/json' },
        body: JSON.stringify({
          input: texts.slice(i, i + 128),
          model: e.model,
          input_type: opts.kind ?? 'document',
          output_dimension: e.dimensions,
        }),
      });
      if (!res.ok)
        throw new Error(`Voyage embeddings failed: HTTP ${res.status} ${await res.text()}`);
      const body = (await res.json()) as { data: { index: number; embedding: number[] }[] };
      out.push(...body.data.sort((a, b) => a.index - b.index).map((d) => d.embedding));
    }
    return out;
  }
}
