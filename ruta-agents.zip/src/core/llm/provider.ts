import type { z } from 'zod';

/**
 * Provider-neutral LLM interface. Implementations return the model's raw text; validation,
 * retries and audit logging live in generate.ts so every provider gets them for free.
 */
export type ChatRole = 'system' | 'user' | 'assistant';

export interface ChatMessage {
  role: ChatRole;
  content: string;
}

/** A document passed to a vision-capable model (PDF, image or plain text), already downloaded. */
export interface LLMFile {
  name: string;
  mimeType: string;
  data: Uint8Array;
}

export type Effort = 'low' | 'medium' | 'high' | 'xhigh' | 'max';

export interface GenerateRequest {
  /** Expected output, as a zod schema (providers with native structured output use this). */
  schema?: z.ZodType;
  /** JSON Schema of the expected output (derived from the zod schema). */
  jsonSchema: Record<string, unknown>;
  schemaName: string;
  messages: ChatMessage[];
  files?: LLMFile[];
  /** 'text' for reasoning/classification, 'vision' for document extraction. */
  purpose?: 'text' | 'vision';
  /** How much the model should think. Defaults to the provider's configured effort. */
  effort?: Effort;
  signal?: AbortSignal;
}

export interface GenerateResponse {
  raw: string;
  model: string;
}

export interface LLMProvider {
  readonly name: string;
  generateJSON(req: GenerateRequest): Promise<GenerateResponse>;
  /** `kind` lets retrieval-tuned embedding models encode queries and documents differently. */
  embed(texts: string[], opts?: { kind?: 'query' | 'document' }): Promise<number[][]>;
}
