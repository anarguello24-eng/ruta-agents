import type { GenerateRequest, GenerateResponse, LLMProvider } from './provider.js';

type Responder = string | object | ((req: GenerateRequest) => string | object);

/**
 * Deterministic provider for tests and offline evals: replays scripted responses in order.
 * Embeddings are a bag-of-words hash so similar texts get similar vectors.
 */
export class FakeLLMProvider implements LLMProvider {
  readonly name = 'fake';
  readonly calls: GenerateRequest[] = [];
  private queue: Responder[];

  constructor(
    responses: Responder[] = [],
    private readonly dims = 1024,
  ) {
    this.queue = [...responses];
  }

  push(...responses: Responder[]) {
    this.queue.push(...responses);
  }

  async generateJSON(req: GenerateRequest): Promise<GenerateResponse> {
    this.calls.push(req);
    const next = this.queue.shift();
    if (next === undefined) throw new Error('FakeLLMProvider: no scripted response left');
    const out = typeof next === 'function' ? next(req) : next;
    return { raw: typeof out === 'string' ? out : JSON.stringify(out), model: 'fake-model' };
  }

  async embed(texts: string[], _opts?: { kind?: 'query' | 'document' }): Promise<number[][]> {
    return texts.map((t) => {
      const v = new Array<number>(this.dims).fill(0);
      for (const tok of t
        .toLowerCase()
        .split(/[^\p{L}\p{N}]+/u)
        .filter(Boolean)) {
        let h = 2166136261;
        for (const ch of tok) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
        v[Math.abs(h) % this.dims]! += 1;
      }
      const norm = Math.hypot(...v) || 1;
      return v.map((x) => x / norm);
    });
  }
}
