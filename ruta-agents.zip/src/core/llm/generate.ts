import { z } from 'zod';
import { hashInput, type AuditEntry } from '../audit.js';
import { AppError } from '../errors.js';
import type { ChatMessage, Effort, LLMFile, LLMProvider } from './provider.js';

/** A versioned prompt. Bump `version` whenever the text changes (see src/prompts/). */
export interface PromptRef {
  id: string;
  version: string;
}

/** Where AI-call audit entries go (normally the agent's audit_log via writeAudit). */
export type AuditSink = (entry: AuditEntry) => Promise<number>;

export class AiOutputError extends AppError {
  constructor(message: string, details: unknown) {
    super(502, 'ai_invalid_output', message, details);
  }
}

export interface GenerateValidatedArgs<S extends z.ZodType> {
  provider: LLMProvider;
  schema: S;
  schemaName: string;
  prompt: PromptRef;
  messages: ChatMessage[];
  files?: LLMFile[];
  purpose?: 'text' | 'vision';
  effort?: Effort;
  timeoutMs?: number;
  audit: AuditSink;
  /** Fields copied into every audit entry (entity, ref, actor...). */
  auditContext: Pick<AuditEntry, 'entityType' | 'entityId' | 'refId' | 'country' | 'action'>;
}

export interface GenerateValidatedResult<T> {
  data: T;
  model: string;
  auditId: number;
  attempts: number;
}

/** Extracts the JSON value from a model reply, tolerating ```json fences and surrounding prose. */
export function parseJsonReply(raw: string): unknown {
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const text = (fenced ? fenced[1]! : raw).trim();
  try {
    return JSON.parse(text);
  } catch {
    const start = text.search(/[[{]/);
    const end = Math.max(text.lastIndexOf('}'), text.lastIndexOf(']'));
    if (start >= 0 && end > start) return JSON.parse(text.slice(start, end + 1));
    throw new Error('reply is not valid JSON');
  }
}

export function formatZodError(err: z.ZodError): string {
  return err.issues
    .map((i) => `${i.path.length ? i.path.join('.') : '(root)'}: ${i.message}`)
    .join('; ');
}

/**
 * Calls the model, validates the JSON against `schema`, retries once with the validation error,
 * then fails visibly. Every attempt (success or failure) is written to the audit log.
 */
export async function generateValidated<S extends z.ZodType>(
  args: GenerateValidatedArgs<S>,
): Promise<GenerateValidatedResult<z.infer<S>>> {
  const jsonSchema = z.toJSONSchema(args.schema, { unrepresentable: 'any' }) as Record<
    string,
    unknown
  >;
  const inputHash = hashInput({
    prompt: args.prompt,
    messages: args.messages,
    files: (args.files ?? []).map((f) => ({
      name: f.name,
      hash: hashInput(Buffer.from(f.data).toString('base64')),
    })),
  });
  const messages: ChatMessage[] = [...args.messages];
  let lastError = '';

  for (let attempt = 1; attempt <= 2; attempt++) {
    let raw = '';
    let model = 'unknown';
    try {
      const res = await args.provider.generateJSON({
        schema: args.schema,
        jsonSchema,
        schemaName: args.schemaName,
        messages,
        files: args.files,
        purpose: args.purpose ?? 'text',
        effort: args.effort,
        signal: args.timeoutMs ? AbortSignal.timeout(args.timeoutMs) : undefined,
      });
      raw = res.raw;
      model = res.model;
      const parsed = args.schema.safeParse(parseJsonReply(raw));
      if (parsed.success) {
        const auditId = await args.audit({
          ...args.auditContext,
          actorType: 'ai',
          promptVersion: `${args.prompt.id}@${args.prompt.version}`,
          model,
          inputHash,
          rawOutput: raw,
          validatedOutput: parsed.data,
        });
        return { data: parsed.data, model, auditId, attempts: attempt };
      }
      lastError = formatZodError(parsed.error);
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
    }

    await args.audit({
      ...args.auditContext,
      actorType: 'ai',
      promptVersion: `${args.prompt.id}@${args.prompt.version}`,
      model,
      inputHash,
      rawOutput: raw || null,
      error: `attempt ${attempt}: ${lastError}`,
    });

    if (raw) messages.push({ role: 'assistant', content: raw });
    messages.push({
      role: 'user',
      content: `Your previous reply was rejected: ${lastError}\nReturn only corrected JSON that matches the schema "${args.schemaName}".`,
    });
  }

  throw new AiOutputError(`model output failed validation twice: ${lastError}`, {
    schema: args.schemaName,
    prompt: args.prompt,
  });
}
