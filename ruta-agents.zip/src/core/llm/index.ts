import Anthropic from '@anthropic-ai/sdk';
import type { Config } from '../config.js';
import { AnthropicProvider } from './anthropic.js';
import type { LLMProvider } from './provider.js';

/** Builds the configured provider, or null when no API key is set (AI endpoints then return 503). */
export function createLLMProvider(config: Config): LLMProvider | null {
  if (!config.ANTHROPIC_API_KEY) return null;
  return new AnthropicProvider({
    client: new Anthropic({
      apiKey: config.ANTHROPIC_API_KEY,
      timeout: config.AGENT_STEP_TIMEOUT_MS,
    }),
    model: config.LLM_MODEL,
    visionModel: config.LLM_VISION_MODEL,
    effort: config.LLM_EFFORT,
    embeddings: config.VOYAGE_API_KEY
      ? {
          apiKey: config.VOYAGE_API_KEY,
          model: config.EMBEDDING_MODEL,
          dimensions: config.EMBEDDING_DIMENSIONS,
        }
      : undefined,
  });
}

export type { LLMProvider } from './provider.js';
