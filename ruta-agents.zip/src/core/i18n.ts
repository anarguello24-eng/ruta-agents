export type Lang = 'es' | 'en';
export const LANGS = ['es', 'en'] as const;

export type Bilingual = { es: string; en: string };

/** Replaces `{name}` placeholders. */
export function fmt(template: string, params: Record<string, string | number> = {}): string {
  return template.replace(/\{(\w+)\}/g, (_, k: string) =>
    params[k] === undefined ? `{${k}}` : String(params[k]),
  );
}

export function tr(lang: Lang, text: Bilingual, params?: Record<string, string | number>): string {
  return fmt(text[lang], params);
}

export type Severity = 'info' | 'warning' | 'error';

/** A machine-readable finding with a message in the caller's language. */
export interface Flag {
  code: string;
  severity: Severity;
  message: string;
  details?: Record<string, unknown>;
}

export function flag(
  lang: Lang,
  code: string,
  severity: Severity,
  text: Bilingual,
  params: Record<string, string | number> = {},
  details?: Record<string, unknown>,
): Flag {
  return { code, severity, message: tr(lang, text, params), ...(details ? { details } : {}) };
}
