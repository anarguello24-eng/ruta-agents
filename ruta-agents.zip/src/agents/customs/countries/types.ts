import type { Bilingual } from '../../../core/i18n.js';
import type { Dec } from '../../../core/money.js';

export interface LineTaxInput {
  cif: Dec;
  daiRate: Dec; // percent
  iscRate: Dec | null; // percent, null = not applicable
  vatRate: Dec; // percent
  /** Charges outside the customs value that are still part of the VAT base (allocated to the line). */
  otherVatTaxable: Dec;
}

export interface LineTaxResult {
  dai: Dec;
  iscBase: Dec;
  isc: Dec;
  vatBase: Dec;
  vat: Dec;
}

/**
 * Everything that differs between countries lives behind this interface, so CR, HN, SV, GT and PA
 * can be added as new folders under src/agents/customs/countries/<iso2>/.
 */
export interface CountryProfile {
  country: string;
  name: Bilingual;
  /** Local currency all duties are paid in. */
  currency: string;
  /** Name of the VAT row in customs.tax_rates. */
  vatTaxName: string;
  declarationFormat: 'DUCA-D';
  customsSystem: string;
  /** Number of digits of a complete national tariff code. */
  tariffCodeDigits: number[];
  /** Tax formula. Each amount is rounded half-up to 2 dp per line. */
  computeLineTaxes(input: LineTaxInput): LineTaxResult;
  /** Bases are documented so the calculation result can explain itself. */
  formulaDescription: Bilingual;
}
