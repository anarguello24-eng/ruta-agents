import { pct, round } from '../../../../core/money.js';
import type { CountryProfile } from '../types.js';

/**
 * Nicaragua. DAI on the CIF value; ISC (where the tariff row has a rate) on CIF + DAI;
 * IVA on CIF + DAI + ISC + other taxable charges. Verify bases with the broker before go-live.
 */
export const NI: CountryProfile = {
  country: 'NI',
  name: { es: 'Nicaragua', en: 'Nicaragua' },
  currency: 'NIO',
  vatTaxName: 'IVA',
  declarationFormat: 'DUCA-D',
  customsSystem: 'SIDUNEA World (DGA)',
  tariffCodeDigits: [8, 10],
  computeLineTaxes({ cif, daiRate, iscRate, vatRate, otherVatTaxable }) {
    const dai = round(pct(cif, daiRate));
    const iscBase = cif.plus(dai);
    const isc = iscRate ? round(pct(iscBase, iscRate)) : round(0);
    const vatBase = cif.plus(dai).plus(isc).plus(otherVatTaxable);
    const vat = round(pct(vatBase, vatRate));
    return { dai, iscBase, isc, vatBase, vat };
  },
  formulaDescription: {
    es: 'CIF = FOB + flete + seguro; DAI = CIF × tasa DAI; ISC = (CIF + DAI) × tasa ISC; IVA = (CIF + DAI + ISC + otros cargos gravables) × tasa IVA.',
    en: 'CIF = FOB + freight + insurance; DAI = CIF × DAI rate; ISC = (CIF + DAI) × ISC rate; IVA = (CIF + DAI + ISC + other taxable charges) × IVA rate.',
  },
};
