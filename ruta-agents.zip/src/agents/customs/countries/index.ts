import { AppError } from '../../../core/errors.js';
import { NI } from './ni/profile.js';
import type { CountryProfile } from './types.js';

const PROFILES: Record<string, CountryProfile> = { NI };

export const SUPPORTED_COUNTRIES = Object.keys(PROFILES);

export function getCountryProfile(country: string): CountryProfile {
  const p = PROFILES[country.toUpperCase()];
  if (!p) throw new AppError(422, 'unsupported_country', `country ${country} is not supported yet`);
  return p;
}

export type { CountryProfile } from './types.js';
