import { z } from 'zod';
import { flag, type Flag, type Lang } from '../../core/i18n.js';
import { allocate, D, money, pct, round, sum, type Dec } from '../../core/money.js';
import { selectEffective, type RateRef } from '../../core/rates.js';
import { cifAdjustments, IncotermSchema } from '../trade/incoterms.js';
import { getCountryProfile } from './countries/index.js';
import type { CustomsReference, TariffRow, TaxRateRow } from './rate-source.js';
import { normalizeCode } from './reference/csv.js';

/**
 * Duty and tax calculator. Pure TypeScript with exact decimals; the LLM never computes these.
 * Every amount references the reference-data row (and its effective date) it was computed from.
 */

const amount = z
  .union([z.number(), z.string()])
  .transform((v) => String(v).trim())
  .pipe(z.string().regex(/^\d+(\.\d+)?$/, 'expected a non-negative decimal amount'));

const positive = amount.refine((v) => D(v).greaterThan(0), 'must be greater than zero');

export const CalcInputSchema = z.object({
  country: z.string().length(2).toUpperCase().default('NI'),
  lang: z.enum(['es', 'en']).default('es'),
  calcDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  /** Invoice currency. */
  currency: z.string().length(3).toUpperCase(),
  /** Local currency units per 1 unit of the invoice currency (user-supplied, dated by calcDate). */
  exchangeRate: positive,
  incoterm: IncotermSchema,
  /** Charges in the invoice currency, totals for the whole shipment. */
  freight: amount.optional(),
  insurance: amount.optional(),
  /** EXW only: export clearance, pickup and loading at origin. */
  originCharges: amount.optional(),
  /** D-terms: costs after arrival included in the price (unloading, inland delivery, clearance). */
  destinationCharges: amount.optional(),
  /** DDP only: import duties and taxes included in the price. */
  dutiesIncluded: amount.optional(),
  otherCharges: z
    .array(
      z.object({
        name: z.string().min(1),
        amount,
        inCustomsValue: z.boolean().default(false),
        vatTaxable: z.boolean().default(true),
      }),
    )
    .default([]),
  prorateBy: z.enum(['value', 'weight']).default('value'),
  lines: z
    .array(
      z.object({
        ref: z.string().min(1),
        description: z.string().optional(),
        /** Line total in the invoice currency, at the invoice Incoterm. */
        value: amount,
        sacCode: z
          .string()
          .transform(normalizeCode)
          .pipe(z.string().regex(/^\d{4,12}$/)),
        netWeightKg: amount.optional(),
      }),
    )
    .min(1),
  /** Declaration-level fees in local currency or as a percentage of the total CIF. */
  fees: z
    .array(
      z.object({
        name: z.string().min(1),
        kind: z.enum(['percent_of_cif', 'fixed']),
        value: amount,
        vatTaxable: z.boolean().default(false),
      }),
    )
    .default([]),
});
export type CalcInput = z.input<typeof CalcInputSchema>;
type Parsed = z.output<typeof CalcInputSchema>;

export interface LineResult {
  ref: string;
  sacCode: string;
  description: string | null;
  valueInvoiceCurrency: string;
  valueLocal: string;
  additions: { freight: string; insurance: string; originCharges: string; other: string };
  deductions: { destinationCharges: string; duties: string };
  cif: string;
  dai: { rate: string; amount: string } | null;
  isc: { rate: string; base: string; amount: string } | null;
  vat: { rate: string; base: string; amount: string } | null;
  totalTaxes: string | null;
  rateRefs: { tariff: RateRef | null; vat: RateRef | null };
}

export interface CalcResult {
  country: string;
  calcDate: string;
  invoiceCurrency: string;
  localCurrency: string;
  exchangeRate: string;
  incoterm: string;
  formula: string;
  complete: boolean;
  /** True when any rate row is sample data or inputs were missing: numbers are not final. */
  isEstimate: boolean;
  lines: LineResult[];
  fees: { name: string; kind: string; value: string; amount: string; vatTaxable: boolean }[];
  totals: {
    valueLocal: string;
    cif: string;
    dai: string;
    isc: string;
    vat: string;
    fees: string;
    totalTaxes: string;
  };
  flags: Flag[];
}

const ref = (table: string, row: TariffRow | TaxRateRow): RateRef => ({
  table,
  id: row.id,
  effectiveFrom: row.effectiveFrom,
  isSample: row.isSample,
});

export async function calculateDuties(
  raw: CalcInput,
  refData: CustomsReference,
): Promise<CalcResult> {
  const input: Parsed = CalcInputSchema.parse(raw);
  const lang: Lang = input.lang;
  const profile = getCountryProfile(input.country);
  const fx = D(input.exchangeRate);
  const flags: Flag[] = [];
  let complete = true;

  if (input.currency === profile.currency && !fx.equals(1)) {
    flags.push(
      flag(
        lang,
        'FX_LOCAL_NOT_ONE',
        'error',
        {
          es: 'La factura está en {cur}; el tipo de cambio debe ser 1.',
          en: 'The invoice is in {cur}; the exchange rate must be 1.',
        },
        { cur: profile.currency },
      ),
    );
    complete = false;
  }

  // ---- 1. What must be added to / deducted from the invoice price to reach CIF -------------
  const adj = cifAdjustments(input.incoterm);
  const needs = {
    freight: adj.add.includes('mainCarriage'),
    insurance: adj.add.includes('insurance'),
    originCharges: adj.add.includes('originCharges') || adj.add.includes('exportClearance'),
    destinationCharges: adj.deduct.includes('destinationCharges'),
    dutiesIncluded: adj.deduct.includes('importDuties'),
  };

  const charge = (key: keyof typeof needs): Dec => {
    const v = input[key];
    if (needs[key]) return D(v ?? 0);
    if (v !== undefined && D(v).greaterThan(0))
      flags.push(
        flag(
          lang,
          'CHARGE_INCLUDED_IN_PRICE',
          'info',
          {
            es: '{charge} ya está incluido en el precio {term}; no se suma de nuevo.',
            en: '{charge} is already included in the {term} price; it is not added again.',
          },
          { charge: key, term: input.incoterm },
        ),
      );
    return D(0);
  };

  if (needs.freight && input.freight === undefined) {
    complete = false;
    flags.push(
      flag(
        lang,
        'MISSING_FREIGHT',
        'error',
        {
          es: 'Falta el flete: con {term} debe sumarse al valor para obtener el CIF.',
          en: 'Freight is missing: under {term} it must be added to reach the CIF value.',
        },
        { term: input.incoterm },
      ),
    );
  }
  if (needs.insurance && input.insurance === undefined) {
    complete = false;
    flags.push(
      flag(
        lang,
        'MISSING_INSURANCE',
        'warning',
        {
          es: 'Falta el seguro: con {term} debe sumarse al valor para obtener el CIF. Confirme con el agente aduanero el seguro a declarar.',
          en: 'Insurance is missing: under {term} it must be added to reach the CIF value. Confirm the insurance to declare with the broker.',
        },
        { term: input.incoterm },
      ),
    );
  }
  if (needs.originCharges && input.originCharges === undefined) {
    flags.push(
      flag(lang, 'MISSING_ORIGIN_CHARGES', 'warning', {
        es: 'Con EXW deben sumarse los gastos de exportación y carga en origen; no se indicaron.',
        en: 'Under EXW, export clearance and origin loading costs must be added; none were given.',
      }),
    );
  }
  if (needs.destinationCharges && input.destinationCharges === undefined) {
    complete = false;
    flags.push(
      flag(
        lang,
        'D_TERM_VALUE_ESTIMATED',
        'warning',
        {
          es: 'Con {term} el precio incluye costos posteriores a la llegada; sin su desglose el CIF queda sobreestimado.',
          en: 'Under {term} the price includes post-arrival costs; without a breakdown the CIF is overstated.',
        },
        { term: input.incoterm },
      ),
    );
  }
  if (needs.dutiesIncluded && input.dutiesIncluded === undefined) {
    complete = false;
    flags.push(
      flag(lang, 'DDP_DUTIES_UNKNOWN', 'warning', {
        es: 'Con DDP el precio incluye impuestos de importación; indique el monto para excluirlo del CIF.',
        en: 'Under DDP the price includes import duties; give the amount so it can be excluded from CIF.',
      }),
    );
  }

  // ---- 2. Convert to local currency and prorate shipment-level charges across lines ----------
  const toLocal = (v: Dec) => round(v.times(fx));
  const valuesLocal = input.lines.map((l) => D(l.value).times(fx));

  let weights: Dec[] = valuesLocal;
  if (input.prorateBy === 'weight') {
    if (input.lines.every((l) => l.netWeightKg !== undefined))
      weights = input.lines.map((l) => D(l.netWeightKg!));
    else
      flags.push(
        flag(lang, 'PRORATE_FALLBACK_VALUE', 'warning', {
          es: 'Faltan pesos netos en algunas líneas; los cargos se prorratean por valor.',
          en: 'Some lines have no net weight; charges are prorated by value.',
        }),
      );
  }

  const spread = (total: Dec) => allocate(toLocal(total), weights);
  const freightL = spread(charge('freight'));
  const insuranceL = spread(charge('insurance'));
  const originL = spread(charge('originCharges'));
  const destL = spread(charge('destinationCharges'));
  const dutiesL = spread(charge('dutiesIncluded'));
  const otherCv = spread(
    sum(input.otherCharges.filter((c) => c.inCustomsValue).map((c) => c.amount)),
  );
  const otherVatOnly = spread(
    sum(input.otherCharges.filter((c) => !c.inCustomsValue && c.vatTaxable).map((c) => c.amount)),
  );

  const cifs = input.lines.map((_, i) =>
    round(
      valuesLocal[i]!.plus(freightL[i]!)
        .plus(insuranceL[i]!)
        .plus(originL[i]!)
        .plus(otherCv[i]!)
        .minus(destL[i]!)
        .minus(dutiesL[i]!),
    ),
  );
  cifs.forEach((c, i) => {
    if (c.isNegative()) {
      complete = false;
      flags.push(
        flag(
          lang,
          'NEGATIVE_CIF',
          'error',
          {
            es: 'La línea {ref} queda con CIF negativo; revise las deducciones.',
            en: 'Line {ref} has a negative CIF; check the deductions.',
          },
          { ref: input.lines[i]!.ref },
        ),
      );
    }
  });
  const totalCif = sum(cifs);

  // ---- 3. Fees (declaration level) ---------------------------------------------------------
  const fees = input.fees.map((f) => {
    const amt = f.kind === 'percent_of_cif' ? round(pct(totalCif, f.value)) : round(f.value);
    return { name: f.name, kind: f.kind, value: f.value, amount: amt, vatTaxable: f.vatTaxable };
  });
  const feeVatL = allocate(sum(fees.filter((f) => f.vatTaxable).map((f) => f.amount)), cifs);

  // ---- 4. Rates ----------------------------------------------------------------------------
  const sampleSeen = new Set<string>();
  const noteSample = (table: string, row: { id: string; isSample: boolean }, label: string) => {
    if (!row.isSample || sampleSeen.has(row.id)) return;
    sampleSeen.add(row.id);
    flags.push(
      flag(
        lang,
        'SAMPLE_RATE',
        'warning',
        {
          es: 'La tasa {label} ({table}) es un dato de ejemplo; no use este resultado para una declaración real.',
          en: 'Rate {label} ({table}) is sample data; do not use this result for a real declaration.',
        },
        { label, table },
        { rowId: row.id },
      ),
    );
  };

  const vatPick = selectEffective(
    await refData.taxVersions(profile.country, profile.vatTaxName),
    input.calcDate,
  );
  if (!vatPick) {
    complete = false;
    flags.push(
      flag(
        lang,
        'VAT_RATE_NOT_FOUND',
        'error',
        {
          es: 'No hay tasa de {tax} vigente al {date}.',
          en: 'No {tax} rate in force on {date}.',
        },
        { tax: profile.vatTaxName, date: input.calcDate },
      ),
    );
  } else {
    noteSample('customs.tax_rates', vatPick.row, profile.vatTaxName);
    if (vatPick.ambiguous)
      flags.push(
        flag(
          lang,
          'AMBIGUOUS_RATE',
          'warning',
          {
            es: 'Hay más de una tasa {label} vigente al {date}; se usó la más reciente.',
            en: 'More than one {label} rate is in force on {date}; the latest was used.',
          },
          { label: profile.vatTaxName, date: input.calcDate },
        ),
      );
  }

  // ---- 5. Per-line taxes ------------------------------------------------------------------
  const lines: LineResult[] = [];
  for (const [i, line] of input.lines.entries()) {
    const tariffPick = selectEffective(
      await refData.tariffVersions(profile.country, line.sacCode),
      input.calcDate,
    );
    const base: Omit<LineResult, 'dai' | 'isc' | 'vat' | 'totalTaxes' | 'rateRefs'> = {
      ref: line.ref,
      sacCode: line.sacCode,
      description: line.description ?? null,
      valueInvoiceCurrency: money(line.value, 2),
      valueLocal: money(valuesLocal[i]!),
      additions: {
        freight: money(freightL[i]!),
        insurance: money(insuranceL[i]!),
        originCharges: money(originL[i]!),
        other: money(otherCv[i]!),
      },
      deductions: { destinationCharges: money(destL[i]!), duties: money(dutiesL[i]!) },
      cif: money(cifs[i]!),
    };

    if (!tariffPick) {
      complete = false;
      flags.push(
        flag(
          lang,
          'TARIFF_NOT_FOUND',
          'error',
          {
            es: 'El código {code} (línea {ref}) no existe en el arancel vigente al {date}.',
            en: 'Code {code} (line {ref}) is not in the tariff in force on {date}.',
          },
          { code: line.sacCode, ref: line.ref, date: input.calcDate },
        ),
      );
      lines.push({
        ...base,
        dai: null,
        isc: null,
        vat: null,
        totalTaxes: null,
        rateRefs: { tariff: null, vat: vatPick ? ref('customs.tax_rates', vatPick.row) : null },
      });
      continue;
    }

    const t = tariffPick.row;
    noteSample('customs.tariff_sac', t, line.sacCode);
    if (tariffPick.ambiguous)
      flags.push(
        flag(
          lang,
          'AMBIGUOUS_RATE',
          'warning',
          {
            es: 'Hay más de una tasa {label} vigente al {date}; se usó la más reciente.',
            en: 'More than one {label} rate is in force on {date}; the latest was used.',
          },
          { label: line.sacCode, date: input.calcDate },
        ),
      );

    const taxes = profile.computeLineTaxes({
      cif: cifs[i]!,
      daiRate: D(t.daiRate),
      iscRate: t.iscRate !== null && D(t.iscRate).greaterThan(0) ? D(t.iscRate) : null,
      vatRate: vatPick ? D(vatPick.row.rate) : D(0),
      otherVatTaxable: otherVatOnly[i]!.plus(feeVatL[i]!),
    });

    lines.push({
      ...base,
      dai: { rate: D(t.daiRate).toString(), amount: money(taxes.dai) },
      isc:
        t.iscRate !== null && D(t.iscRate).greaterThan(0)
          ? { rate: D(t.iscRate).toString(), base: money(taxes.iscBase), amount: money(taxes.isc) }
          : null,
      vat: vatPick
        ? {
            rate: D(vatPick.row.rate).toString(),
            base: money(taxes.vatBase),
            amount: money(taxes.vat),
          }
        : null,
      totalTaxes: money(taxes.dai.plus(taxes.isc).plus(vatPick ? taxes.vat : 0)),
      rateRefs: {
        tariff: ref('customs.tariff_sac', t),
        vat: vatPick ? ref('customs.tax_rates', vatPick.row) : null,
      },
    });
  }

  const tot = (pick: (l: LineResult) => string | undefined) =>
    sum(lines.map((l) => pick(l) ?? '0'));
  const dai = tot((l) => l.dai?.amount);
  const isc = tot((l) => l.isc?.amount);
  const vat = tot((l) => l.vat?.amount);
  const feeTotal = sum(fees.map((f) => f.amount));

  return {
    country: profile.country,
    calcDate: input.calcDate,
    invoiceCurrency: input.currency,
    localCurrency: profile.currency,
    exchangeRate: fx.toString(),
    incoterm: input.incoterm,
    formula: profile.formulaDescription[lang],
    complete,
    isEstimate: !complete || sampleSeen.size > 0,
    lines,
    fees: fees.map((f) => ({ ...f, amount: money(f.amount) })),
    totals: {
      valueLocal: money(sum(valuesLocal.map((v) => round(v)))),
      cif: money(totalCif),
      dai: money(dai),
      isc: money(isc),
      vat: money(vat),
      fees: money(feeTotal),
      totalTaxes: money(dai.plus(isc).plus(vat).plus(feeTotal)),
    },
    flags,
  };
}
