import {
  bigint,
  bigserial,
  boolean,
  char,
  customType,
  date,
  integer,
  jsonb,
  numeric,
  pgSchema,
  smallint,
  text,
  timestamp,
  uuid,
  vector,
} from 'drizzle-orm/pg-core';

/** Embedding size is fixed by migrations/0001_init.sql. */
export const EMBEDDING_DIMENSIONS = 1024;

export const customs = pgSchema('customs');

const tsvector = customType<{ data: string }>({ dataType: () => 'tsvector' });

const timestamps = {
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
};

export const CASE_STATUSES = ['draft', 'in_review', 'approved', 'filed', 'released'] as const;
export type CaseStatus = (typeof CASE_STATUSES)[number];

export const LINE_STATUSES = ['pending', 'suggested', 'accepted', 'approved'] as const;
export type LineStatus = (typeof LINE_STATUSES)[number];

export const DOC_TYPES = [
  'commercial_invoice',
  'packing_list',
  'bill_of_lading',
  'air_waybill',
  'certificate_of_origin',
  'other',
] as const;
export type DocType = (typeof DOC_TYPES)[number];

export const cases = customs.table('cases', {
  id: uuid('id').primaryKey().defaultRandom(),
  country: char('country', { length: 2 }).notNull().default('NI'),
  reference: text('reference'),
  shipmentId: text('shipment_id'),
  status: text('status', { enum: CASE_STATUSES }).notNull().default('draft'),
  lang: char('lang', { length: 2, enum: ['es', 'en'] })
    .notNull()
    .default('es'),
  currency: char('currency', { length: 3 }),
  exchangeRate: numeric('exchange_rate', { precision: 18, scale: 6 }),
  header: jsonb('header').notNull().default({}),
  flags: jsonb('flags').notNull().default([]),
  ducaNumber: text('duca_number'),
  createdBy: uuid('created_by'),
  approvedBy: uuid('approved_by'),
  approvedAt: timestamp('approved_at', { withTimezone: true }),
  filedBy: uuid('filed_by'),
  filedAt: timestamp('filed_at', { withTimezone: true }),
  releasedAt: timestamp('released_at', { withTimezone: true }),
  ...timestamps,
});

export const documents = customs.table('documents', {
  id: uuid('id').primaryKey().defaultRandom(),
  caseId: uuid('case_id')
    .notNull()
    .references(() => cases.id, { onDelete: 'cascade' }),
  country: char('country', { length: 2 }).notNull().default('NI'),
  docType: text('doc_type', { enum: DOC_TYPES }).notNull(),
  storagePath: text('storage_path').notNull(),
  fileName: text('file_name'),
  mimeType: text('mime_type'),
  extractionStatus: text('extraction_status', { enum: ['pending', 'done', 'failed'] })
    .notNull()
    .default('pending'),
  extraction: jsonb('extraction'),
  uploadedBy: uuid('uploaded_by'),
  ...timestamps,
});

export const lines = customs.table('lines', {
  id: uuid('id').primaryKey().defaultRandom(),
  caseId: uuid('case_id')
    .notNull()
    .references(() => cases.id, { onDelete: 'cascade' }),
  country: char('country', { length: 2 }).notNull().default('NI'),
  lineNo: integer('line_no').notNull(),
  description: text('description').notNull(),
  quantity: numeric('quantity', { precision: 18, scale: 4 }),
  unit: text('unit'),
  unitPrice: numeric('unit_price', { precision: 18, scale: 6 }),
  total: numeric('total', { precision: 18, scale: 2 }),
  grossWeightKg: numeric('gross_weight_kg', { precision: 18, scale: 3 }),
  netWeightKg: numeric('net_weight_kg', { precision: 18, scale: 3 }),
  originCountry: char('origin_country', { length: 2 }),
  sourceDocumentId: uuid('source_document_id').references(() => documents.id, {
    onDelete: 'set null',
  }),
  sacCode: text('sac_code'),
  status: text('status', { enum: LINE_STATUSES }).notNull().default('pending'),
  approvedBy: uuid('approved_by'),
  approvedAt: timestamp('approved_at', { withTimezone: true }),
  ...timestamps,
});

export const auditLog = customs.table('audit_log', {
  id: bigserial('id', { mode: 'number' }).primaryKey(),
  country: char('country', { length: 2 }).notNull().default('NI'),
  caseId: uuid('case_id').references(() => cases.id, { onDelete: 'set null' }),
  entityType: text('entity_type').notNull(),
  entityId: text('entity_id'),
  actorType: text('actor_type', { enum: ['ai', 'user', 'system'] }).notNull(),
  actorId: text('actor_id'),
  action: text('action').notNull(),
  promptVersion: text('prompt_version'),
  model: text('model'),
  inputHash: text('input_hash'),
  rawOutput: text('raw_output'),
  validatedOutput: jsonb('validated_output'),
  before: jsonb('before'),
  after: jsonb('after'),
  error: text('error'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const tariffSac = customs.table('tariff_sac', {
  id: uuid('id').primaryKey().defaultRandom(),
  country: char('country', { length: 2 }).notNull().default('NI'),
  code: text('code').notNull(),
  descriptionEs: text('description_es').notNull(),
  descriptionEn: text('description_en'),
  daiRate: numeric('dai_rate', { precision: 7, scale: 4 }).notNull(),
  iscRate: numeric('isc_rate', { precision: 7, scale: 4 }),
  notes: text('notes'),
  embedding: vector('embedding', { dimensions: EMBEDDING_DIMENSIONS }),
  searchTsv: tsvector('search_tsv'),
  effectiveFrom: date('effective_from').notNull(),
  effectiveTo: date('effective_to'),
  isSample: boolean('is_sample').notNull().default(false),
  sourceUrl: text('source_url'),
  ...timestamps,
});

export const taxRates = customs.table('tax_rates', {
  id: uuid('id').primaryKey().defaultRandom(),
  country: char('country', { length: 2 }).notNull().default('NI'),
  taxName: text('tax_name').notNull(),
  rate: numeric('rate', { precision: 7, scale: 4 }).notNull(),
  baseDescription: text('base_description'),
  effectiveFrom: date('effective_from').notNull(),
  effectiveTo: date('effective_to'),
  isSample: boolean('is_sample').notNull().default(false),
  sourceUrl: text('source_url'),
  ...timestamps,
});

export const permits = customs.table('permits', {
  id: uuid('id').primaryKey().defaultRandom(),
  country: char('country', { length: 2 }).notNull().default('NI'),
  sacPrefix: text('sac_prefix').notNull(),
  agency: text('agency').notNull(),
  permitName: text('permit_name').notNull(),
  notes: text('notes'),
  isSample: boolean('is_sample').notNull().default(false),
  sourceUrl: text('source_url'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const lineClassifications = customs.table('line_classifications', {
  id: uuid('id').primaryKey().defaultRandom(),
  lineId: uuid('line_id')
    .notNull()
    .references(() => lines.id, { onDelete: 'cascade' }),
  country: char('country', { length: 2 }).notNull().default('NI'),
  rank: smallint('rank').notNull(),
  sacCode: text('sac_code').notNull(),
  tariffId: uuid('tariff_id').references(() => tariffSac.id, { onDelete: 'restrict' }),
  griApplied: text('gri_applied').array().notNull().default([]),
  reasoning: text('reasoning'),
  confidence: smallint('confidence').notNull(),
  isSelected: boolean('is_selected').notNull().default(false),
  auditId: bigint('audit_id', { mode: 'number' }).references(() => auditLog.id),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const calculations = customs.table('calculations', {
  id: uuid('id').primaryKey().defaultRandom(),
  caseId: uuid('case_id')
    .notNull()
    .references(() => cases.id, { onDelete: 'cascade' }),
  country: char('country', { length: 2 }).notNull().default('NI'),
  calcDate: date('calc_date').notNull(),
  currency: char('currency', { length: 3 }).notNull(),
  exchangeRate: numeric('exchange_rate', { precision: 18, scale: 6 }).notNull(),
  input: jsonb('input').notNull(),
  result: jsonb('result').notNull(),
  warnings: jsonb('warnings').notNull().default([]),
  totalCif: numeric('total_cif', { precision: 18, scale: 2 }).notNull(),
  totalTaxes: numeric('total_taxes', { precision: 18, scale: 2 }).notNull(),
  createdBy: uuid('created_by'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const classificationHistory = customs.table('classification_history', {
  id: uuid('id').primaryKey().defaultRandom(),
  country: char('country', { length: 2 }).notNull().default('NI'),
  productDescription: text('product_description').notNull(),
  embedding: vector('embedding', { dimensions: EMBEDDING_DIMENSIONS }),
  acceptedCode: text('accepted_code').notNull(),
  caseId: uuid('case_id').references(() => cases.id, { onDelete: 'set null' }),
  lineId: uuid('line_id').references(() => lines.id, { onDelete: 'set null' }),
  approvedBy: uuid('approved_by').notNull(),
  approvedAt: timestamp('approved_at', { withTimezone: true }).notNull().defaultNow(),
});
