import type { Queryable } from '../../../core/db/client.js';
import type { PermitRow, TariffRow, TaxRateRow } from './csv.js';

/** Upserts tariff rows keyed by (country, code, effective_from). Embeddings are not touched. */
export async function upsertTariffRows(sql: Queryable, rows: TariffRow[]): Promise<number> {
  let n = 0;
  for (const r of rows) {
    await sql`
      INSERT INTO customs.tariff_sac
        (country, code, description_es, description_en, dai_rate, isc_rate, notes,
         effective_from, effective_to, is_sample, source_url)
      VALUES
        (${r.country}, ${r.code}, ${r.description_es}, ${r.description_en}, ${r.dai_rate},
         ${r.isc_rate}, ${r.notes}, ${r.effective_from}, ${r.effective_to}, ${r.is_sample},
         ${r.source_url})
      ON CONFLICT (country, code, effective_from) DO UPDATE SET
        description_es = EXCLUDED.description_es,
        description_en = EXCLUDED.description_en,
        dai_rate       = EXCLUDED.dai_rate,
        isc_rate       = EXCLUDED.isc_rate,
        notes          = EXCLUDED.notes,
        effective_to   = EXCLUDED.effective_to,
        is_sample      = EXCLUDED.is_sample,
        source_url     = EXCLUDED.source_url,
        -- description changed => embedding is stale
        embedding      = CASE
                           WHEN customs.tariff_sac.description_es IS DISTINCT FROM EXCLUDED.description_es
                             OR customs.tariff_sac.description_en IS DISTINCT FROM EXCLUDED.description_en
                           THEN NULL ELSE customs.tariff_sac.embedding END`;
    n++;
  }
  return n;
}

export async function upsertTaxRateRows(sql: Queryable, rows: TaxRateRow[]): Promise<number> {
  let n = 0;
  for (const r of rows) {
    await sql`
      INSERT INTO customs.tax_rates
        (country, tax_name, rate, base_description, effective_from, effective_to, is_sample, source_url)
      VALUES
        (${r.country}, ${r.tax_name}, ${r.rate}, ${r.base_description}, ${r.effective_from},
         ${r.effective_to}, ${r.is_sample}, ${r.source_url})
      ON CONFLICT (country, tax_name, effective_from) DO UPDATE SET
        rate             = EXCLUDED.rate,
        base_description = EXCLUDED.base_description,
        effective_to     = EXCLUDED.effective_to,
        is_sample        = EXCLUDED.is_sample,
        source_url       = EXCLUDED.source_url`;
    n++;
  }
  return n;
}

export async function upsertPermitRows(sql: Queryable, rows: PermitRow[]): Promise<number> {
  let n = 0;
  for (const r of rows) {
    await sql`
      INSERT INTO customs.permits (country, sac_prefix, agency, permit_name, notes, is_sample, source_url)
      VALUES (${r.country}, ${r.sac_prefix}, ${r.agency}, ${r.permit_name}, ${r.notes},
              ${r.is_sample}, ${r.source_url})
      ON CONFLICT (country, sac_prefix, agency, permit_name) DO UPDATE SET
        notes      = EXCLUDED.notes,
        is_sample  = EXCLUDED.is_sample,
        source_url = EXCLUDED.source_url`;
    n++;
  }
  return n;
}
