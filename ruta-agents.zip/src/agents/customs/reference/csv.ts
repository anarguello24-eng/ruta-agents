import { parse } from 'csv-parse/sync';
import { z } from 'zod';

const optionalText = z
  .string()
  .optional()
  .transform((v) => (v === undefined || v.trim() === '' ? null : v.trim()));

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'expected YYYY-MM-DD');
const optionalDate = z
  .string()
  .optional()
  .transform((v) => (v === undefined || v.trim() === '' ? null : v.trim()))
  .pipe(isoDate.nullable());

const percent = z.coerce.number().min(0).max(1000);
const optionalPercent = z
  .string()
  .optional()
  .transform((v) => (v === undefined || v.trim() === '' ? null : Number(v)))
  .pipe(z.number().min(0).max(1000).nullable());

const bool = z
  .string()
  .optional()
  .transform((v) => ['true', '1', 'yes', 'si', 'sí'].includes((v ?? '').trim().toLowerCase()));

const country = z
  .string()
  .optional()
  .transform((v) => (v && v.trim() ? v.trim().toUpperCase() : 'NI'))
  .pipe(z.string().regex(/^[A-Z]{2}$/));

/** Strips dots/spaces so "8471.30.00" and "84713000" are the same code. */
export function normalizeCode(code: string): string {
  return code.replace(/[^0-9]/g, '');
}

const digits = (min: number, what: string) =>
  z
    .string()
    .transform(normalizeCode)
    .pipe(z.string().regex(new RegExp(`^[0-9]{${min},12}$`), `${what} must have ${min}-12 digits`));

const sacCode = digits(4, 'tariff code');

export const TariffRowSchema = z.object({
  country,
  code: sacCode,
  description_es: z.string().trim().min(1),
  description_en: optionalText,
  dai_rate: percent,
  isc_rate: optionalPercent,
  notes: optionalText,
  effective_from: isoDate,
  effective_to: optionalDate,
  is_sample: bool,
  source_url: optionalText,
});
export type TariffRow = z.infer<typeof TariffRowSchema>;

export const TaxRateRowSchema = z.object({
  country,
  tax_name: z.string().trim().min(1).toUpperCase(),
  rate: percent,
  base_description: optionalText,
  effective_from: isoDate,
  effective_to: optionalDate,
  is_sample: bool,
  source_url: optionalText,
});
export type TaxRateRow = z.infer<typeof TaxRateRowSchema>;

export const PermitRowSchema = z.object({
  country,
  sac_prefix: digits(2, 'sac_prefix'),
  agency: z.string().trim().min(1),
  permit_name: z.string().trim().min(1),
  notes: optionalText,
  is_sample: bool,
  source_url: optionalText,
});
export type PermitRow = z.infer<typeof PermitRowSchema>;

export class CsvValidationError extends Error {
  constructor(public readonly errors: string[]) {
    super(`CSV validation failed:\n${errors.slice(0, 20).join('\n')}`);
  }
}

/** Parses a CSV with a header row and validates every row; throws with all row errors. */
export function parseCsv<S extends z.ZodType>(text: string, schema: S): z.infer<S>[] {
  const records = parse(text, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true,
  }) as Record<string, string>[];
  const rows: z.infer<S>[] = [];
  const errors: string[] = [];
  records.forEach((rec, i) => {
    const r = schema.safeParse(rec);
    if (r.success) rows.push(r.data);
    else
      errors.push(
        `row ${i + 2}: ${r.error.issues.map((x) => `${x.path.join('.')}: ${x.message}`).join('; ')}`,
      );
  });
  if (errors.length) throw new CsvValidationError(errors);
  return rows;
}
