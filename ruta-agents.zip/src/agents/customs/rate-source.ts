import type { Queryable } from '../../core/db/client.js';
import type { Versioned } from '../../core/rates.js';

export interface TariffRow extends Versioned {
  id: string;
  country: string;
  code: string;
  descriptionEs: string;
  descriptionEn: string | null;
  daiRate: string;
  iscRate: string | null;
  isSample: boolean;
}

export interface TaxRateRow extends Versioned {
  id: string;
  country: string;
  taxName: string;
  rate: string;
  isSample: boolean;
}

export interface PermitRow {
  id: string;
  country: string;
  sacPrefix: string;
  agency: string;
  permitName: string;
  notes: string | null;
  isSample: boolean;
}

/** Read access to customs reference tables. All versions are returned; callers pick by date. */
export interface CustomsReference {
  tariffVersions(country: string, code: string): Promise<TariffRow[]>;
  taxVersions(country: string, taxName: string): Promise<TaxRateRow[]>;
  permitsFor(country: string, code: string): Promise<PermitRow[]>;
}

const d = (v: unknown): string => (v instanceof Date ? v.toISOString().slice(0, 10) : String(v));
const dn = (v: unknown): string | null => (v === null || v === undefined ? null : d(v));

export class DbCustomsReference implements CustomsReference {
  constructor(private readonly sql: Queryable) {}

  async tariffVersions(country: string, code: string): Promise<TariffRow[]> {
    const rows = await this.sql<Record<string, unknown>[]>`
      SELECT id, country, code, description_es, description_en, dai_rate::text, isc_rate::text,
             effective_from, effective_to, is_sample
      FROM customs.tariff_sac WHERE country = ${country} AND code = ${code}`;
    return rows.map((r) => ({
      id: r.id as string,
      country: (r.country as string).trim(),
      code: r.code as string,
      descriptionEs: r.description_es as string,
      descriptionEn: (r.description_en as string) ?? null,
      daiRate: r.dai_rate as string,
      iscRate: (r.isc_rate as string) ?? null,
      effectiveFrom: d(r.effective_from),
      effectiveTo: dn(r.effective_to),
      isSample: r.is_sample as boolean,
    }));
  }

  async taxVersions(country: string, taxName: string): Promise<TaxRateRow[]> {
    const rows = await this.sql<Record<string, unknown>[]>`
      SELECT id, country, tax_name, rate::text, effective_from, effective_to, is_sample
      FROM customs.tax_rates WHERE country = ${country} AND tax_name = ${taxName}`;
    return rows.map((r) => ({
      id: r.id as string,
      country: (r.country as string).trim(),
      taxName: r.tax_name as string,
      rate: r.rate as string,
      effectiveFrom: d(r.effective_from),
      effectiveTo: dn(r.effective_to),
      isSample: r.is_sample as boolean,
    }));
  }

  async permitsFor(country: string, code: string): Promise<PermitRow[]> {
    const rows = await this.sql<Record<string, unknown>[]>`
      SELECT id, country, sac_prefix, agency, permit_name, notes, is_sample
      FROM customs.permits
      WHERE country = ${country} AND ${code} LIKE sac_prefix || '%'
      ORDER BY length(sac_prefix) DESC, agency`;
    return rows.map((r) => ({
      id: r.id as string,
      country: (r.country as string).trim(),
      sacPrefix: r.sac_prefix as string,
      agency: r.agency as string,
      permitName: r.permit_name as string,
      notes: (r.notes as string) ?? null,
      isSample: r.is_sample as boolean,
    }));
  }
}

/** In-memory reference data for tests and evals. */
export class MemoryCustomsReference implements CustomsReference {
  constructor(
    private readonly data: { tariff?: TariffRow[]; taxes?: TaxRateRow[]; permits?: PermitRow[] },
  ) {}
  async tariffVersions(country: string, code: string) {
    return (this.data.tariff ?? []).filter((r) => r.country === country && r.code === code);
  }
  async taxVersions(country: string, taxName: string) {
    return (this.data.taxes ?? []).filter((r) => r.country === country && r.taxName === taxName);
  }
  async permitsFor(country: string, code: string) {
    return (this.data.permits ?? [])
      .filter((r) => r.country === country && code.startsWith(r.sacPrefix))
      .sort((a, b) => b.sacPrefix.length - a.sacPrefix.length || a.agency.localeCompare(b.agency));
  }
}
