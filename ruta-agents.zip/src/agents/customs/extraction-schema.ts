import { z } from 'zod';
import { DOC_TYPES } from './schema.js';

/**
 * Structured output of `extract_documents` (one object per uploaded document). Shared by the
 * LLM extractor (milestone 4) and the deterministic cross-check rules. Unknown values are null,
 * never guessed.
 */
const num = z.number().nonnegative().nullable();

export const ExtractedLineSchema = z.object({
  description: z.string(),
  quantity: num,
  unit: z.string().nullable(),
  unitPrice: num,
  total: num,
  grossWeightKg: num,
  netWeightKg: num,
  originCountry: z
    .string()
    .regex(/^[A-Z]{2}$/)
    .nullable(),
});

export const PartySchema = z.object({
  name: z.string(),
  address: z.string().nullable(),
  taxId: z.string().nullable(),
});

export const ExtractedDocumentSchema = z.object({
  docType: z.enum(DOC_TYPES),
  documentNumber: z.string().nullable(),
  documentDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .nullable(),
  supplier: PartySchema.nullable(),
  consignee: PartySchema.nullable(),
  invoiceNumber: z.string().nullable(),
  incoterm: z.string().nullable(),
  currency: z
    .string()
    .regex(/^[A-Z]{3}$/)
    .nullable(),
  freight: num,
  insurance: num,
  totalAmount: num,
  grossWeightKg: num,
  netWeightKg: num,
  packages: z.number().int().nonnegative().nullable(),
  originCountry: z
    .string()
    .regex(/^[A-Z]{2}$/)
    .nullable(),
  lines: z.array(ExtractedLineSchema),
});
export type ExtractedDocument = z.infer<typeof ExtractedDocumentSchema>;
