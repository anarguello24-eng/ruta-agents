import { z } from 'zod';
import { auditSink, untrusted, type AiDeps } from '../../../core/ai/context.js';
import type { Flag, Lang } from '../../../core/i18n.js';
import { generateValidated } from '../../../core/llm/generate.js';
import type { LLMFile } from '../../../core/llm/provider.js';
import { D } from '../../../core/money.js';
import { EXTRACT_DOCUMENT_PROMPT } from '../../../prompts/customs/extract-document.v1.js';
import { crossCheck } from '../crosscheck.js';
import { ExtractedDocumentSchema, type ExtractedDocument } from '../extraction-schema.js';
import { DOC_TYPES } from '../schema.js';

/** What the model returns: weights keep their printed unit; the code converts to kg. */
const Weight = z
  .object({ value: z.number().nonnegative(), unit: z.enum(['kg', 'lb', 't']) })
  .nullable();
const Party = z
  .object({ name: z.string(), address: z.string().nullable(), taxId: z.string().nullable() })
  .nullable();
const iso2 = z.string().nullable();

export const ModelExtractionSchema = z.object({
  docType: z.enum(DOC_TYPES),
  documentNumber: z.string().nullable(),
  documentDate: z.string().nullable(),
  supplier: Party,
  consignee: Party,
  invoiceNumber: z.string().nullable(),
  incoterm: z.string().nullable(),
  currency: z.string().nullable(),
  freight: z.number().nonnegative().nullable(),
  insurance: z.number().nonnegative().nullable(),
  totalAmount: z.number().nonnegative().nullable(),
  grossWeight: Weight,
  netWeight: Weight,
  packages: z.number().int().nonnegative().nullable(),
  originCountry: iso2,
  lines: z.array(
    z.object({
      description: z.string(),
      quantity: z.number().nonnegative().nullable(),
      unit: z.string().nullable(),
      unitPrice: z.number().nonnegative().nullable(),
      total: z.number().nonnegative().nullable(),
      grossWeight: Weight,
      netWeight: Weight,
      originCountry: iso2,
    }),
  ),
  warnings: z.array(z.string()),
});
type ModelExtraction = z.infer<typeof ModelExtractionSchema>;

const KG: Record<'kg' | 'lb' | 't', string> = { kg: '1', lb: '0.45359237', t: '1000' };
export const toKg = (w: { value: number; unit: 'kg' | 'lb' | 't' } | null): number | null =>
  w === null ? null : D(w.value).times(KG[w.unit]).toDecimalPlaces(3).toNumber();

const clean = (v: string | null, re: RegExp) =>
  v && re.test(v.trim().toUpperCase()) ? v.trim().toUpperCase() : null;

/** Deterministic normalization of the model output into the cross-check schema. */
export function normalizeExtraction(m: ModelExtraction): ExtractedDocument {
  return ExtractedDocumentSchema.parse({
    docType: m.docType,
    documentNumber: m.documentNumber,
    documentDate:
      m.documentDate && /^\d{4}-\d{2}-\d{2}$/.test(m.documentDate) ? m.documentDate : null,
    supplier: m.supplier,
    consignee: m.consignee,
    invoiceNumber: m.invoiceNumber,
    incoterm: m.incoterm,
    currency: clean(m.currency, /^[A-Z]{3}$/),
    freight: m.freight,
    insurance: m.insurance,
    totalAmount: m.totalAmount,
    grossWeightKg: toKg(m.grossWeight),
    netWeightKg: toKg(m.netWeight),
    packages: m.packages,
    originCountry: clean(m.originCountry, /^[A-Z]{2}$/),
    lines: m.lines.map((l) => ({
      description: l.description,
      quantity: l.quantity,
      unit: l.unit,
      unitPrice: l.unitPrice,
      total: l.total,
      grossWeightKg: toKg(l.grossWeight),
      netWeightKg: toKg(l.netWeight),
      originCountry: clean(l.originCountry, /^[A-Z]{2}$/),
    })),
  });
}

export interface ExtractResult {
  documents: {
    fileName: string;
    document: ExtractedDocument;
    warnings: string[];
    auditId: number;
  }[];
  flags: Flag[];
}

/** Reads each uploaded file with the vision model, normalizes, then runs the cross-checks. */
export async function extractDocuments(
  deps: AiDeps,
  args: {
    files: LLMFile[];
    lang: Lang;
    caseId?: string | null;
    country?: string;
    preferentialOrigins?: string[];
  },
): Promise<ExtractResult> {
  const documents: ExtractResult['documents'] = [];
  for (const file of args.files) {
    const r = await generateValidated({
      provider: deps.provider,
      schema: ModelExtractionSchema,
      schemaName: 'extracted_document',
      prompt: EXTRACT_DOCUMENT_PROMPT,
      purpose: 'vision',
      files: [file],
      timeoutMs: deps.timeoutMs,
      messages: [
        { role: 'system', content: EXTRACT_DOCUMENT_PROMPT.system },
        {
          role: 'user',
          content: `${EXTRACT_DOCUMENT_PROMPT.render({ fileNames: [file.name] })}\n${untrusted('file_name', file.name)}`,
        },
      ],
      audit: auditSink(deps.sql, 'customs'),
      auditContext: {
        country: args.country ?? 'NI',
        refId: args.caseId ?? null,
        entityType: 'document',
        entityId: file.name,
        action: 'ai.extract_document',
      },
    });
    documents.push({
      fileName: file.name,
      document: normalizeExtraction(r.data),
      warnings: r.data.warnings,
      auditId: r.auditId,
    });
  }
  const flags = crossCheck(
    documents.map((d) => d.document),
    { lang: args.lang, preferentialOrigins: args.preferentialOrigins },
  );
  return { documents, flags };
}
