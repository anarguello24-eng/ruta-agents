import { z } from 'zod';
import { auditSink, untrusted, type AiDeps } from '../../../core/ai/context.js';
import { flag, type Flag, type Lang } from '../../../core/i18n.js';
import { generateValidated } from '../../../core/llm/generate.js';
import { CLASSIFY_LINE_PROMPT } from '../../../prompts/customs/classify-line.v1.js';
import { searchTariff, similarClassifications, type TariffCandidate } from '../tariff-search.js';

export const GRI = [
  'GRI1',
  'GRI2a',
  'GRI2b',
  'GRI3a',
  'GRI3b',
  'GRI3c',
  'GRI4',
  'GRI5a',
  'GRI5b',
  'GRI6',
] as const;

/** The output schema only accepts codes returned by the tariff search for this product. */
export function classificationSchema(codes: [string, ...string[]]) {
  return z.object({
    candidates: z
      .array(
        z.object({
          code: z.enum(codes),
          gri: z.array(z.enum(GRI)),
          reasoning: z.string(),
          confidence: z.number().int().min(0).max(100),
        }),
      )
      .min(1)
      .max(3),
    needsMoreInfo: z.string().nullable(),
  });
}

export interface ClassificationResult {
  description: string;
  suggestions: (Pick<
    TariffCandidate,
    | 'code'
    | 'descriptionEs'
    | 'descriptionEn'
    | 'daiRate'
    | 'iscRate'
    | 'effectiveFrom'
    | 'isSample'
  > & {
    tariffId: string;
    rank: number;
    gri: (typeof GRI)[number][];
    reasoning: string;
    confidence: number;
  })[];
  needsMoreInfo: string | null;
  searched: number;
  auditId: number | null;
  flags: Flag[];
}

export async function classifyProduct(
  deps: AiDeps,
  args: {
    country: string;
    lang: Lang;
    date: string;
    description: string;
    caseId?: string | null;
    lineId?: string | null;
  },
): Promise<ClassificationResult> {
  const flags: Flag[] = [];
  let queryEmbedding: number[] | null = null;
  try {
    [queryEmbedding] = (await deps.provider.embed([args.description], { kind: 'query' })) as [
      number[],
    ];
  } catch {
    flags.push(
      flag(args.lang, 'SEMANTIC_SEARCH_OFF', 'info', {
        es: 'Búsqueda semántica no disponible; se usó búsqueda por palabras.',
        en: 'Semantic search unavailable; keyword search was used.',
      }),
    );
  }
  const candidates = await searchTariff(deps.sql, {
    country: args.country,
    text: args.description,
    date: args.date,
    queryEmbedding,
  });
  if (!candidates.length) {
    flags.push(
      flag(args.lang, 'NO_TARIFF_CANDIDATES', 'warning', {
        es: 'No se encontraron partidas candidatas; amplíe la descripción del producto.',
        en: 'No candidate tariff codes found; give a fuller product description.',
      }),
    );
    return {
      description: args.description,
      suggestions: [],
      needsMoreInfo: null,
      searched: 0,
      auditId: null,
      flags,
    };
  }
  const examples = await similarClassifications(deps.sql, {
    country: args.country,
    text: args.description,
    queryEmbedding,
  });

  const byCode = new Map(candidates.map((c) => [c.code, c]));
  const schema = classificationSchema(candidates.map((c) => c.code) as [string, ...string[]]);
  const task = [
    `Language for reasoning: ${args.lang === 'es' ? 'Spanish' : 'English'}.`,
    'Product to classify:',
    untrusted('product_description', args.description),
    'Candidate codes from the official tariff table (choose only among these):',
    JSON.stringify(
      candidates.map((c) => ({
        code: c.code,
        description_es: c.descriptionEs,
        description_en: c.descriptionEn,
      })),
    ),
    examples.length
      ? `Past classifications approved by the broker:\n${JSON.stringify(examples)}`
      : 'No past classifications of similar products.',
  ].join('\n');

  const r = await generateValidated({
    provider: deps.provider,
    schema,
    schemaName: 'tariff_classification',
    prompt: CLASSIFY_LINE_PROMPT,
    effort: 'high',
    timeoutMs: deps.timeoutMs,
    messages: [
      { role: 'system', content: CLASSIFY_LINE_PROMPT.system },
      { role: 'user', content: task },
    ],
    audit: auditSink(deps.sql, 'customs'),
    auditContext: {
      country: args.country,
      refId: args.caseId ?? null,
      entityType: 'line',
      entityId: args.lineId ?? null,
      action: 'ai.classify',
    },
  });

  const seen = new Set<string>();
  const suggestions = r.data.candidates
    .filter((c) => !seen.has(c.code) && seen.add(c.code))
    .sort((a, b) => b.confidence - a.confidence)
    .map((c, i) => {
      const t = byCode.get(c.code)!;
      return {
        rank: i + 1,
        code: c.code,
        tariffId: t.id,
        descriptionEs: t.descriptionEs,
        descriptionEn: t.descriptionEn,
        daiRate: t.daiRate,
        iscRate: t.iscRate,
        effectiveFrom: t.effectiveFrom,
        isSample: t.isSample,
        gri: c.gri,
        reasoning: c.reasoning,
        confidence: c.confidence,
      };
    });

  if ((suggestions[0]?.confidence ?? 0) < 60)
    flags.push(
      flag(args.lang, 'LOW_CONFIDENCE', 'warning', {
        es: 'Clasificación con baja confianza; el agente aduanero debe revisarla con especial cuidado.',
        en: 'Low-confidence classification; the broker must review it carefully.',
      }),
    );
  if (suggestions.some((s) => s.isSample))
    flags.push(
      flag(args.lang, 'SAMPLE_TARIFF', 'warning', {
        es: 'El arancel cargado es de ejemplo; verifique el código y las tasas en el arancel oficial.',
        en: 'The loaded tariff is sample data; verify the code and rates against the official tariff.',
      }),
    );

  return {
    description: args.description,
    suggestions,
    needsMoreInfo: r.data.needsMoreInfo,
    searched: candidates.length,
    auditId: r.auditId,
    flags,
  };
}
