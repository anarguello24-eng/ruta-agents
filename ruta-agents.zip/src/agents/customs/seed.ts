import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import type { Queryable } from '../../core/db/client.js';
import { parseCsv, PermitRowSchema, TariffRowSchema, TaxRateRowSchema } from './reference/csv.js';
import { upsertPermitRows, upsertTariffRows, upsertTaxRateRows } from './reference/upsert.js';

export interface SeedResult {
  tariff: number;
  taxRates: number;
  permits: number;
}

/** Loads the sample Nicaragua reference data in `seed/`. Every row is `is_sample = true`. */
export async function seedSampleData(sql: Queryable, seedDir: string): Promise<SeedResult> {
  const read = (f: string) => readFile(join(seedDir, f), 'utf8');
  const tariff = parseCsv(await read('ni_tariff_sac.sample.csv'), TariffRowSchema);
  const taxRates = parseCsv(await read('ni_tax_rates.sample.csv'), TaxRateRowSchema);
  const permits = parseCsv(await read('ni_permits.sample.csv'), PermitRowSchema);

  return {
    tariff: await upsertTariffRows(sql, tariff),
    taxRates: await upsertTaxRateRows(sql, taxRates),
    permits: await upsertPermitRows(sql, permits),
  };
}
