import { flag, type Flag, type Lang } from '../../core/i18n.js';
import type { CustomsReference, PermitRow } from './rate-source.js';

export interface PermitCheckLine {
  ref: string;
  sacCode: string;
}

export interface PermitCheckResult {
  lines: { ref: string; sacCode: string; permits: PermitRow[] }[];
  /** Distinct permits needed by the shipment, grouped by agency. */
  required: {
    agency: string;
    permitName: string;
    sacPrefix: string;
    lineRefs: string[];
    isSample: boolean;
  }[];
  missing: { agency: string; permitName: string; lineRefs: string[] }[];
  flags: Flag[];
}

/**
 * Looks up required permits by tariff-code prefix and compares them with the permits the client
 * says it has (`provided`, matched on agency + permit name, case-insensitive).
 */
export async function checkPermits(
  refData: CustomsReference,
  args: {
    country: string;
    lang: Lang;
    lines: PermitCheckLine[];
    provided?: { agency: string; permitName?: string }[];
  },
): Promise<PermitCheckResult> {
  const lines = [];
  const byKey = new Map<string, PermitCheckResult['required'][number]>();
  for (const l of args.lines) {
    const permits = await refData.permitsFor(args.country, l.sacCode);
    lines.push({ ref: l.ref, sacCode: l.sacCode, permits });
    for (const p of permits) {
      const key = `${p.agency}|${p.permitName}`.toLowerCase();
      const entry = byKey.get(key) ?? {
        agency: p.agency,
        permitName: p.permitName,
        sacPrefix: p.sacPrefix,
        lineRefs: [],
        isSample: p.isSample,
      };
      entry.lineRefs.push(l.ref);
      byKey.set(key, entry);
    }
  }
  const required = [...byKey.values()];
  const provided = (args.provided ?? []).map((p) => ({
    agency: p.agency.toLowerCase(),
    permitName: p.permitName?.toLowerCase(),
  }));
  const missing = required
    .filter(
      (r) =>
        !provided.some(
          (p) =>
            p.agency === r.agency.toLowerCase() &&
            (!p.permitName || p.permitName === r.permitName.toLowerCase()),
        ),
    )
    .map(({ agency, permitName, lineRefs }) => ({ agency, permitName, lineRefs }));

  const flags: Flag[] = missing.map((m) =>
    flag(
      args.lang,
      'PERMIT_MISSING',
      'warning',
      {
        es: 'Falta {permit} ({agency}) para las líneas {lines}.',
        en: 'Missing {permit} ({agency}) for lines {lines}.',
      },
      { permit: m.permitName, agency: m.agency, lines: m.lineRefs.join(', ') },
    ),
  );
  if (required.some((r) => r.isSample))
    flags.push(
      flag(args.lang, 'SAMPLE_PERMIT_DATA', 'warning', {
        es: 'La tabla de permisos contiene datos de ejemplo; verifique los requisitos con la autoridad competente.',
        en: 'The permits table contains sample data; verify requirements with the competent authority.',
      }),
    );
  return { lines, required, missing, flags };
}
