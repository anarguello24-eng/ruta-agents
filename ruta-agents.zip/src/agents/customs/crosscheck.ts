import { flag, type Flag, type Lang } from '../../core/i18n.js';
import { D, round, sum } from '../../core/money.js';
import { INCOTERM_RULES, IncotermSchema, cifAdjustments } from '../trade/incoterms.js';
import type { ExtractedDocument } from './extraction-schema.js';

/**
 * Deterministic consistency rules across a shipment's documents. No LLM involved: these run on
 * the validated extraction output and produce flags for the broker.
 */

export interface CrossCheckOptions {
  lang: Lang;
  /** Origin countries for which a trade preference could be claimed (needs a certificate). */
  preferentialOrigins?: string[];
  /** Absolute tolerance in invoice currency for amount comparisons. */
  amountTolerance?: string;
  /** Weight tolerance: max(absKg, relPct % of the larger value). */
  weightToleranceKg?: string;
  weightTolerancePct?: string;
}

const LEGAL_SUFFIXES =
  /\b(s\.?\s?a\.?(\s?de\s?c\.?\s?v\.?)?|s\.?\s?r\.?\s?l\.?|ltda?\.?|inc\.?|llc|corp\.?|co\.?|company|limited|gmbh|sa|cia\.?)\b/g;

export function normalizeParty(name: string): string {
  return name
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase()
    .replace(LEGAL_SUFFIXES, ' ')
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Jaccard similarity of word sets after normalization (0..1). */
export function nameSimilarity(a: string, b: string): number {
  const A = new Set(normalizeParty(a).split(' ').filter(Boolean));
  const B = new Set(normalizeParty(b).split(' ').filter(Boolean));
  if (!A.size && !B.size) return 1;
  const inter = [...A].filter((x) => B.has(x)).length;
  return inter / (A.size + B.size - inter);
}

const LABEL: Record<ExtractedDocument['docType'], { es: string; en: string }> = {
  commercial_invoice: { es: 'factura comercial', en: 'commercial invoice' },
  packing_list: { es: 'lista de empaque', en: 'packing list' },
  bill_of_lading: { es: 'conocimiento de embarque (BL)', en: 'bill of lading' },
  air_waybill: { es: 'guía aérea (AWB)', en: 'air waybill' },
  certificate_of_origin: { es: 'certificado de origen', en: 'certificate of origin' },
  other: { es: 'otro documento', en: 'other document' },
};

export function crossCheck(docs: ExtractedDocument[], opts: CrossCheckOptions): Flag[] {
  const { lang } = opts;
  const tol = D(opts.amountTolerance ?? '0.02');
  const flags: Flag[] = [];
  const label = (d: ExtractedDocument) => LABEL[d.docType][lang];

  const invoice = docs.find((d) => d.docType === 'commercial_invoice');
  const packing = docs.find((d) => d.docType === 'packing_list');
  const transport = docs.find((d) => d.docType === 'bill_of_lading' || d.docType === 'air_waybill');
  const coo = docs.find((d) => d.docType === 'certificate_of_origin');

  if (!invoice)
    flags.push(
      flag(lang, 'MISSING_INVOICE', 'error', {
        es: 'Falta la factura comercial.',
        en: 'The commercial invoice is missing.',
      }),
    );
  if (!transport)
    flags.push(
      flag(lang, 'MISSING_TRANSPORT_DOC', 'warning', {
        es: 'Falta el documento de transporte (BL o guía aérea).',
        en: 'The transport document (BL or air waybill) is missing.',
      }),
    );

  if (invoice) {
    // Line arithmetic: qty × unit price = line total.
    invoice.lines.forEach((l, i) => {
      if (l.quantity === null || l.unitPrice === null || l.total === null) return;
      const expected = round(D(l.quantity).times(l.unitPrice));
      if (expected.minus(l.total).abs().greaterThan(tol))
        flags.push(
          flag(
            lang,
            'LINE_TOTAL_MISMATCH',
            'warning',
            {
              es: 'Línea {n}: cantidad × precio unitario = {expected}, pero el total dice {total}.',
              en: 'Line {n}: quantity × unit price = {expected}, but the total says {total}.',
            },
            { n: i + 1, expected: expected.toFixed(2), total: l.total },
          ),
        );
    });

    // Invoice total vs sum of lines (allowing for freight/insurance shown on the invoice).
    const lineTotals = invoice.lines.map((l) => l.total);
    if (invoice.totalAmount !== null && lineTotals.length && lineTotals.every((t) => t !== null)) {
      const linesSum = sum(lineTotals as number[]);
      const withCharges = linesSum.plus(invoice.freight ?? 0).plus(invoice.insurance ?? 0);
      const total = D(invoice.totalAmount);
      if (
        total.minus(linesSum).abs().greaterThan(tol) &&
        total.minus(withCharges).abs().greaterThan(tol)
      )
        flags.push(
          flag(
            lang,
            'INVOICE_TOTAL_MISMATCH',
            'error',
            {
              es: 'El total de la factura ({total}) no coincide con la suma de las líneas ({sum}).',
              en: 'The invoice total ({total}) does not match the sum of the lines ({sum}).',
            },
            { total: total.toFixed(2), sum: linesSum.toFixed(2) },
          ),
        );
    }

    // Incoterm vs charges needed to build the CIF value.
    const term = invoice.incoterm ? IncotermSchema.safeParse(invoice.incoterm) : null;
    if (!invoice.incoterm || !term?.success) {
      flags.push(
        flag(lang, 'MISSING_INCOTERM', 'warning', {
          es: 'La factura no indica un Incoterm válido; no se puede determinar cómo construir el CIF.',
          en: 'The invoice shows no valid Incoterm; the CIF value cannot be built reliably.',
        }),
      );
    } else {
      const t = term.data;
      if (INCOTERM_RULES[t].sellerMustInsure || t === 'CFR' || t === 'CPT') {
        if (invoice.freight === null)
          flags.push(
            flag(
              lang,
              'MISSING_FREIGHT_FOR_CIF',
              'warning',
              {
                es: 'Factura {term} sin desglose de flete; la aduana puede exigirlo para validar el valor.',
                en: '{term} invoice without a freight breakdown; customs may require it to validate the value.',
              },
              { term: t },
            ),
          );
        if (INCOTERM_RULES[t].sellerMustInsure && invoice.insurance === null)
          flags.push(
            flag(
              lang,
              'MISSING_INSURANCE_FOR_CIF',
              'warning',
              {
                es: 'Factura {term} sin desglose de seguro.',
                en: '{term} invoice without an insurance breakdown.',
              },
              { term: t },
            ),
          );
      }
      const adds = cifAdjustments(t).add;
      if (
        adds.includes('mainCarriage') &&
        invoice.freight === null &&
        (transport?.freight ?? null) === null
      )
        flags.push(
          flag(
            lang,
            'FREIGHT_NEEDED',
            'warning',
            {
              es: 'Con {term} el flete debe sumarse al CIF, pero ningún documento lo indica.',
              en: 'Under {term} freight must be added to CIF, but no document states it.',
            },
            { term: t },
          ),
        );
    }
  }

  // Currency consistency.
  const currencies = [
    ...new Set(docs.map((d) => d.currency).filter((c): c is string => Boolean(c))),
  ];
  if (currencies.length > 1)
    flags.push(
      flag(
        lang,
        'CURRENCY_MISMATCH',
        'warning',
        {
          es: 'Los documentos usan monedas distintas: {list}.',
          en: 'Documents use different currencies: {list}.',
        },
        { list: currencies.join(', ') },
      ),
    );

  // Invoice number referenced by other documents.
  if (invoice?.documentNumber) {
    for (const d of [packing, coo].filter((x): x is ExtractedDocument => Boolean(x))) {
      if (d.invoiceNumber && normalizeRef(d.invoiceNumber) !== normalizeRef(invoice.documentNumber))
        flags.push(
          flag(
            lang,
            'INVOICE_REFERENCE_MISMATCH',
            'warning',
            {
              es: 'La {doc} referencia la factura {ref}, pero la factura es {inv}.',
              en: 'The {doc} references invoice {ref}, but the invoice is {inv}.',
            },
            { doc: label(d), ref: d.invoiceNumber, inv: invoice.documentNumber },
          ),
        );
    }
  }

  // Weights across documents.
  const absKg = D(opts.weightToleranceKg ?? '0.5');
  const relPct = D(opts.weightTolerancePct ?? '1');
  const weighed = docs.filter(
    (d) => d.grossWeightKg !== null && d.docType !== 'certificate_of_origin',
  );
  for (let i = 0; i < weighed.length; i++)
    for (let j = i + 1; j < weighed.length; j++) {
      const a = D(weighed[i]!.grossWeightKg!);
      const b = D(weighed[j]!.grossWeightKg!);
      const limit = Dmax(absKg, Dmax(a, b).times(relPct).dividedBy(100));
      if (a.minus(b).abs().greaterThan(limit))
        flags.push(
          flag(
            lang,
            'WEIGHT_MISMATCH',
            'warning',
            {
              es: 'Peso bruto distinto: {docA} {a} kg vs {docB} {b} kg.',
              en: 'Gross weight differs: {docA} {a} kg vs {docB} {b} kg.',
            },
            {
              docA: label(weighed[i]!),
              a: a.toString(),
              docB: label(weighed[j]!),
              b: b.toString(),
            },
          ),
        );
    }
  for (const d of docs)
    if (
      d.grossWeightKg !== null &&
      d.netWeightKg !== null &&
      D(d.netWeightKg).greaterThan(d.grossWeightKg)
    )
      flags.push(
        flag(
          lang,
          'NET_EXCEEDS_GROSS',
          'error',
          {
            es: 'En la {doc} el peso neto ({net} kg) es mayor que el bruto ({gross} kg).',
            en: 'In the {doc} the net weight ({net} kg) exceeds the gross weight ({gross} kg).',
          },
          { doc: label(d), net: d.netWeightKg, gross: d.grossWeightKg },
        ),
      );

  // Consignee names.
  const withConsignee = docs.filter((d) => d.consignee?.name);
  const ref = invoice?.consignee?.name ? invoice : withConsignee[0];
  if (ref)
    for (const d of withConsignee) {
      if (d === ref) continue;
      if (nameSimilarity(ref.consignee!.name, d.consignee!.name) < 0.6)
        flags.push(
          flag(
            lang,
            'CONSIGNEE_MISMATCH',
            'warning',
            {
              es: 'Consignatario distinto: "{a}" ({docA}) vs "{b}" ({docB}).',
              en: 'Consignee differs: "{a}" ({docA}) vs "{b}" ({docB}).',
            },
            { a: ref.consignee!.name, docA: label(ref), b: d.consignee!.name, docB: label(d) },
          ),
        );
    }

  // Certificate of origin when a preference may apply.
  const preferential = new Set(opts.preferentialOrigins ?? []);
  const origins = new Set(
    docs
      .flatMap((d) => [d.originCountry, ...d.lines.map((l) => l.originCountry)])
      .filter((o): o is string => Boolean(o)),
  );
  const prefOrigins = [...origins].filter((o) => preferential.has(o));
  if (!coo && prefOrigins.length)
    flags.push(
      flag(
        lang,
        'MISSING_CERTIFICATE_OF_ORIGIN',
        'warning',
        {
          es: 'Hay mercancía originaria de {list}, que podría tener trato preferencial, pero falta el certificado/declaración de origen.',
          en: 'Goods originate in {list}, which may qualify for preferential treatment, but the certificate/declaration of origin is missing.',
        },
        { list: prefOrigins.join(', ') },
      ),
    );

  return flags;
}

const normalizeRef = (s: string) => s.replace(/[^a-z0-9]/gi, '').toUpperCase();
const Dmax = (a: ReturnType<typeof D>, b: ReturnType<typeof D>) => (a.greaterThan(b) ? a : b);
