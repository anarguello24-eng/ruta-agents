import type { Queryable } from '../../core/db/client.js';
import type { LLMProvider } from '../../core/llm/provider.js';

export interface TariffCandidate {
  id: string;
  code: string;
  descriptionEs: string;
  descriptionEn: string | null;
  daiRate: string;
  iscRate: string | null;
  effectiveFrom: string;
  isSample: boolean;
  score: number;
  matchedBy: string[];
}

const WORD = /[\p{L}\p{N}]{3,}/gu;
const vectorLiteral = (v: number[] | null) => (v ? `[${v.join(',')}]` : null);
const d = (v: unknown) => (v instanceof Date ? v.toISOString().slice(0, 10) : String(v));

/**
 * Hybrid tariff search over rows in force on `date`: code prefix, full-text (Spanish and English),
 * trigram similarity and (when embeddings exist) vector similarity, fused by reciprocal rank.
 * The classifier may only choose among these rows, so it can never invent a code.
 */
export async function searchTariff(
  sql: Queryable,
  q: {
    country: string;
    text: string;
    date: string;
    limit?: number;
    queryEmbedding?: number[] | null;
  },
): Promise<TariffCandidate[]> {
  const words = [...new Set((q.text.toLowerCase().match(WORD) ?? []).slice(0, 20))];
  const tsq = words.length ? words.join(' | ') : null;
  const digits =
    (q.text.match(/\b\d{4}(?:[.\s]?\d{2}){0,3}\b/) ?? [null])[0]?.replace(/\D/g, '') ?? null;
  const vec = vectorLiteral(q.queryEmbedding ?? null);
  const limit = q.limit ?? 12;

  const rows = await sql<Record<string, unknown>[]>`
    WITH eff AS (
      SELECT * FROM customs.tariff_sac
      WHERE country = ${q.country} AND effective_from <= ${q.date}
        AND (effective_to IS NULL OR effective_to >= ${q.date})
    ),
    code AS (
      SELECT id, 'code' AS src, row_number() OVER (ORDER BY code) AS r FROM eff
      WHERE ${digits}::text IS NOT NULL AND code LIKE ${digits} || '%'
      ORDER BY r LIMIT 20
    ),
    kw AS (
      SELECT id, 'keyword' AS src, row_number() OVER (ORDER BY ts_rank(search_tsv, qq) DESC) AS r
      FROM eff, (SELECT to_tsquery('spanish', ${tsq}) || to_tsquery('english', ${tsq}) AS qq) t
      WHERE ${tsq}::text IS NOT NULL AND search_tsv @@ qq
      ORDER BY r LIMIT 50
    ),
    tg AS (
      SELECT id, 'similar_text' AS src,
             row_number() OVER (ORDER BY greatest(word_similarity(${q.text}, description_es),
                                                  word_similarity(${q.text}, coalesce(description_en, ''))) DESC) AS r
      FROM eff
      WHERE greatest(word_similarity(${q.text}, description_es), word_similarity(${q.text}, coalesce(description_en, ''))) > 0.25
      ORDER BY r LIMIT 50
    ),
    vec AS (
      SELECT id, 'semantic' AS src, row_number() OVER (ORDER BY embedding <=> ${vec}::vector) AS r
      FROM eff WHERE ${vec}::text IS NOT NULL AND embedding IS NOT NULL
      ORDER BY r LIMIT 50
    ),
    hits AS (SELECT * FROM code UNION ALL SELECT * FROM kw UNION ALL SELECT * FROM tg UNION ALL SELECT * FROM vec)
    SELECT e.id, e.code, e.description_es, e.description_en, e.dai_rate::text, e.isc_rate::text,
           e.effective_from, e.is_sample,
           sum(1.0 / (60 + h.r))::float8 AS score, array_agg(DISTINCT h.src) AS matched_by
    FROM hits h JOIN eff e USING (id)
    GROUP BY e.id, e.code, e.description_es, e.description_en, e.dai_rate, e.isc_rate, e.effective_from, e.is_sample
    ORDER BY score DESC, e.code
    LIMIT ${limit}`;

  return rows.map((r) => ({
    id: r.id as string,
    code: r.code as string,
    descriptionEs: r.description_es as string,
    descriptionEn: (r.description_en as string) ?? null,
    daiRate: r.dai_rate as string,
    iscRate: (r.isc_rate as string) ?? null,
    effectiveFrom: d(r.effective_from),
    isSample: r.is_sample as boolean,
    score: Number(r.score),
    matchedBy: r.matched_by as string[],
  }));
}

/** Past broker-approved classifications of similar products (few-shot examples). */
export async function similarClassifications(
  sql: Queryable,
  q: { country: string; text: string; queryEmbedding?: number[] | null; limit?: number },
): Promise<{ productDescription: string; acceptedCode: string }[]> {
  const vec = vectorLiteral(q.queryEmbedding ?? null);
  const rows = await sql<{ product_description: string; accepted_code: string }[]>`
    SELECT product_description, accepted_code FROM customs.classification_history
    WHERE country = ${q.country}
      AND (( ${vec}::text IS NOT NULL AND embedding IS NOT NULL)
           OR word_similarity(${q.text}, product_description) > 0.3)
    ORDER BY CASE WHEN ${vec}::text IS NOT NULL AND embedding IS NOT NULL
                  THEN embedding <=> ${vec}::vector END NULLS LAST,
             word_similarity(${q.text}, product_description) DESC
    LIMIT ${q.limit ?? 5}`;
  return rows.map((r) => ({
    productDescription: r.product_description,
    acceptedCode: r.accepted_code,
  }));
}

/** Computes embeddings for tariff rows that have none (new rows or changed descriptions). */
export async function embedMissingTariffRows(
  sql: Queryable,
  provider: LLMProvider,
  opts: { country?: string; batchSize?: number } = {},
): Promise<number> {
  let total = 0;
  for (;;) {
    const rows = await sql<
      { id: string; code: string; description_es: string; description_en: string | null }[]
    >`
      SELECT id, code, description_es, description_en FROM customs.tariff_sac
      WHERE embedding IS NULL AND (${opts.country ?? null}::text IS NULL OR country = ${opts.country ?? null})
      ORDER BY code LIMIT ${opts.batchSize ?? 128}`;
    if (!rows.length) return total;
    const vectors = await provider.embed(
      rows.map(
        (r) => `${r.code} ${r.description_es}${r.description_en ? ` | ${r.description_en}` : ''}`,
      ),
      { kind: 'document' },
    );
    for (const [i, r] of rows.entries())
      await sql`UPDATE customs.tariff_sac SET embedding = ${vectorLiteral(vectors[i]!)}::vector WHERE id = ${r.id}`;
    total += rows.length;
  }
}
