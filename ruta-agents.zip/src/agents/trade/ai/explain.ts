import { z } from 'zod';
import { auditSink, type AiDeps } from '../../../core/ai/context.js';
import type { Lang } from '../../../core/i18n.js';
import { generateValidated } from '../../../core/llm/generate.js';
import { EXPLAIN_CHECKLIST_PROMPT } from '../../../prompts/trade/explain-checklist.v1.js';
import type { ChecklistResult } from '../checklist.js';

/** Plain-language explanation of a checklist built by the rules engine (codes are fixed). */
export async function explainChecklist(
  deps: AiDeps,
  args: { lang: Lang; checklist: ChecklistResult; operationId?: string | null },
) {
  const codes = args.checklist.documents.map((d) => d.code);
  if (!codes.length) return { summary: '', documents: [], cautions: [], auditId: null };
  const schema = z.object({
    summary: z.string(),
    documents: z.array(
      z.object({
        code: z.enum(codes as [string, ...string[]]),
        explanation: z.string(),
        whoProvides: z.string(),
      }),
    ),
    cautions: z.array(z.string()),
  });
  const r = await generateValidated({
    provider: deps.provider,
    schema,
    schemaName: 'checklist_explanation',
    prompt: EXPLAIN_CHECKLIST_PROMPT,
    effort: 'low',
    timeoutMs: deps.timeoutMs,
    messages: [
      { role: 'system', content: EXPLAIN_CHECKLIST_PROMPT.system },
      {
        role: 'user',
        content: `Language: ${args.lang}\nChecklist: ${JSON.stringify(args.checklist)}`,
      },
    ],
    audit: auditSink(deps.sql, 'trade'),
    auditContext: {
      refId: args.operationId ?? null,
      entityType: 'checklist',
      action: 'ai.explain_checklist',
    },
  });
  // Keep the engine's order and drop anything not in the checklist.
  const byCode = new Map(r.data.documents.map((d) => [d.code, d]));
  return {
    summary: r.data.summary,
    documents: codes.filter((c) => byCode.has(c)).map((c) => byCode.get(c)!),
    cautions: r.data.cautions,
    auditId: r.auditId,
  };
}
