import { z } from 'zod';
import { flag, type Flag, type Lang } from '../../core/i18n.js';
import type { CustomsReference } from '../customs/rate-source.js';
import { normalizeCode } from '../customs/reference/csv.js';
import { INCOTERM_RULES, IncotermSchema } from './incoterms.js';
import { agreementsBetween, type AgreementRow, type TradeReference } from './reference.js';

export const ChecklistInputSchema = z.object({
  country: z.string().length(2).toUpperCase().default('NI'),
  lang: z.enum(['es', 'en']).default('es'),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  direction: z.enum(['import', 'export']),
  partnerCountry: z.string().length(2).toUpperCase(),
  transportMode: z.enum(['sea', 'air', 'ground', 'courier']),
  hsCode: z
    .string()
    .transform(normalizeCode)
    .pipe(z.string().regex(/^\d{2,12}$/))
    .optional(),
  incoterm: IncotermSchema.optional(),
  wantsPreference: z.boolean().default(true),
});
export type ChecklistInput = z.input<typeof ChecklistInputSchema>;

export interface ChecklistDoc {
  code: string;
  name: string;
  issuer: string;
  requirement: 'required' | 'conditional';
  source: 'rule' | 'agreement' | 'permit';
  notes: string | null;
  isSample: boolean;
}

export interface ChecklistResult {
  direction: 'import' | 'export';
  partnerCountry: string;
  intraRegional: boolean;
  agreements: { code: string; name: string; proofOfOrigin: string; isSample: boolean }[];
  documents: ChecklistDoc[];
  flags: Flag[];
}

/**
 * Builds the document checklist for an import or export operation from reference tables:
 * general rules, product-specific rules (by HS prefix), trade agreements in force between the
 * two countries, and (for imports) the permits table of the customs agent.
 */
export async function buildChecklist(
  raw: ChecklistInput,
  tradeRef: TradeReference,
  customsRef?: CustomsReference,
): Promise<ChecklistResult> {
  const input = ChecklistInputSchema.parse(raw);
  const lang: Lang = input.lang;
  const flags: Flag[] = [];
  const allAgreements = await tradeRef.agreements();
  const inForce = agreementsBetween(allAgreements, input.country, input.partnerCountry, input.date);
  const intraRegional = inForce.some((a) => a.code === 'MCCA');
  const scopes = new Set(['any', intraRegional ? 'mcca' : 'non_mcca', input.partnerCountry]);

  const rules = (await tradeRef.docRequirements(input.country)).filter(
    (r) =>
      (r.direction === 'both' || r.direction === input.direction) &&
      scopes.has(r.partnerScope) &&
      (r.transportMode === 'any' || r.transportMode === input.transportMode),
  );

  const productRules = rules.filter((r) => r.hsPrefix);
  if (!input.hsCode && productRules.length)
    flags.push(
      flag(lang, 'HS_CODE_NEEDED', 'warning', {
        es: 'Sin código arancelario no se pueden determinar los certificados específicos del producto.',
        en: 'Without a tariff code, product-specific certificates cannot be determined.',
      }),
    );

  const docs = new Map<string, ChecklistDoc>();
  const add = (doc: ChecklistDoc) => {
    const prev = docs.get(doc.code);
    if (!prev) docs.set(doc.code, doc);
    else if (prev.requirement === 'conditional' && doc.requirement === 'required')
      docs.set(doc.code, doc);
  };

  for (const r of rules) {
    if (r.hsPrefix && !(input.hsCode && input.hsCode.startsWith(r.hsPrefix))) continue;
    if (r.docCode === 'IMPORT_PERMITS') continue; // resolved below
    add({
      code: r.docCode,
      name: lang === 'es' ? r.nameEs : r.nameEn,
      issuer: r.issuer,
      requirement: r.requirement,
      source: 'rule',
      notes: r.notes,
      isSample: r.isSample,
    });
  }

  // Import permits from the customs permits table.
  const permitRule = rules.find((r) => r.docCode === 'IMPORT_PERMITS');
  if (permitRule) {
    if (input.hsCode && customsRef) {
      for (const p of await customsRef.permitsFor(input.country, input.hsCode))
        add({
          code: `PERMIT:${p.agency}:${p.permitName}`,
          name: p.permitName,
          issuer: p.agency,
          requirement: 'required',
          source: 'permit',
          notes: p.notes,
          isSample: p.isSample,
        });
    } else {
      add({
        code: permitRule.docCode,
        name: lang === 'es' ? permitRule.nameEs : permitRule.nameEn,
        issuer: permitRule.issuer,
        requirement: 'conditional',
        source: 'rule',
        notes: permitRule.notes,
        isSample: permitRule.isSample,
      });
    }
  }

  // Proof of origin for each preferential agreement (MCCA's proof is the DUCA-F itself).
  if (input.wantsPreference)
    for (const a of inForce.filter((x) => x.code !== 'MCCA'))
      add(proofOfOrigin(a, input.direction, lang));

  // Incoterm sanity checks.
  if (input.incoterm) {
    const rule = INCOTERM_RULES[input.incoterm];
    if (rule.mode === 'sea' && input.transportMode !== 'sea')
      flags.push(
        flag(
          lang,
          'INCOTERM_MODE_MISMATCH',
          'warning',
          {
            es: '{term} es solo para transporte marítimo; para {mode} use {alt}.',
            en: '{term} is for sea transport only; for {mode} use {alt}.',
          },
          {
            term: input.incoterm,
            mode: input.transportMode,
            alt: SEA_TO_ANY[input.incoterm] ?? 'FCA',
          },
        ),
      );
    if (input.direction === 'export' && input.incoterm === 'EXW')
      flags.push(
        flag(lang, 'EXW_EXPORT_CLEARANCE', 'warning', {
          es: 'Con EXW el comprador extranjero debe hacer el despacho de exportación en Nicaragua, lo que suele ser impráctico; considere FCA.',
          en: 'Under EXW the foreign buyer must clear export in Nicaragua, which is usually impractical; consider FCA.',
        }),
      );
    if (input.direction === 'import' && input.incoterm === 'DDP')
      flags.push(
        flag(lang, 'DDP_IMPORT_CLEARANCE', 'warning', {
          es: 'Con DDP el vendedor extranjero debe despachar la importación y pagar impuestos en Nicaragua; confirme que tiene representación local o use DAP.',
          en: 'Under DDP the foreign seller must clear import and pay taxes in Nicaragua; confirm local representation or use DAP.',
        }),
      );
    if (input.direction === 'import' && rule.sellerMustInsure)
      add({
        code: 'INSURANCE_CERTIFICATE',
        name: lang === 'es' ? 'Certificado o póliza de seguro' : 'Insurance certificate or policy',
        issuer: lang === 'es' ? 'Vendedor / aseguradora' : 'Seller / insurer',
        requirement: 'conditional',
        source: 'rule',
        notes: input.incoterm,
        isSample: false,
      });
  }

  const documents = [...docs.values()];
  if (documents.some((x) => x.isSample) || inForce.some((a) => a.isSample))
    flags.push(
      flag(lang, 'SAMPLE_TRADE_DATA', 'warning', {
        es: 'La lista usa datos de ejemplo; verifique los requisitos con la autoridad competente.',
        en: 'This checklist uses sample data; verify requirements with the competent authority.',
      }),
    );

  return {
    direction: input.direction,
    partnerCountry: input.partnerCountry,
    intraRegional,
    agreements: inForce.map((a) => ({
      code: a.code,
      name: lang === 'es' ? a.nameEs : a.nameEn,
      proofOfOrigin: a.proofOfOrigin,
      isSample: a.isSample,
    })),
    documents,
    flags,
  };
}

const SEA_TO_ANY: Partial<Record<string, string>> = {
  FAS: 'FCA',
  FOB: 'FCA',
  CFR: 'CPT',
  CIF: 'CIP',
};

function proofOfOrigin(a: AgreementRow, direction: 'import' | 'export', lang: Lang): ChecklistDoc {
  return {
    code: `PROOF_OF_ORIGIN:${a.code}`,
    name:
      lang === 'es'
        ? `Prueba de origen ${a.code}: ${a.proofOfOrigin}`
        : `${a.code} proof of origin: ${a.proofOfOrigin}`,
    issuer:
      direction === 'import'
        ? lang === 'es'
          ? 'Exportador / productor extranjero'
          : 'Foreign exporter / producer'
        : lang === 'es'
          ? 'Exportador nicaragüense'
          : 'Nicaraguan exporter',
    requirement: 'conditional',
    source: 'agreement',
    notes:
      lang === 'es'
        ? 'Necesaria solo para aplicar el arancel preferencial; verifique las reglas de origen del producto.'
        : 'Needed only to claim the preferential rate; check the product-specific rules of origin.',
    isSample: a.isSample,
  };
}

/** Compares the checklist with documents already received for an operation. */
export function missingDocuments(
  checklist: ChecklistResult,
  received: { code: string; status: 'pending' | 'received' | 'verified' | 'not_applicable' }[],
) {
  const done = new Map(received.map((r) => [r.code, r.status]));
  return checklist.documents.filter(
    (d) =>
      d.requirement === 'required' &&
      !['received', 'verified', 'not_applicable'].includes(done.get(d.code) ?? 'pending'),
  );
}
