import type { Queryable } from '../../core/db/client.js';
import { isEffective } from '../../core/rates.js';

export interface AgreementRow {
  id: string;
  code: string;
  nameEs: string;
  nameEn: string;
  proofOfOrigin: string;
  isSample: boolean;
  members: { country: string; effectiveFrom: string; effectiveTo: string | null }[];
}

export interface DocRequirementRow {
  id: string;
  country: string;
  direction: 'import' | 'export' | 'both';
  partnerScope: string;
  transportMode: 'any' | 'sea' | 'air' | 'ground' | 'courier';
  hsPrefix: string | null;
  docCode: string;
  nameEs: string;
  nameEn: string;
  issuer: string;
  requirement: 'required' | 'conditional';
  notes: string | null;
  isSample: boolean;
}

export interface TradeReference {
  agreements(): Promise<AgreementRow[]>;
  docRequirements(country: string): Promise<DocRequirementRow[]>;
}

/** Agreements in force between two countries on a date (both must be members on that date). */
export function agreementsBetween(
  all: AgreementRow[],
  a: string,
  b: string,
  on: string,
): AgreementRow[] {
  const member = (ag: AgreementRow, c: string) =>
    ag.members.some((m) => m.country === c && isEffective(m, on));
  return all.filter((ag) => member(ag, a) && member(ag, b));
}

const d = (v: unknown) => (v instanceof Date ? v.toISOString().slice(0, 10) : String(v));

export class DbTradeReference implements TradeReference {
  constructor(private readonly sql: Queryable) {}

  async agreements(): Promise<AgreementRow[]> {
    const rows = await this.sql<Record<string, unknown>[]>`
      SELECT a.id, a.code, a.name_es, a.name_en, a.proof_of_origin, a.is_sample,
             coalesce(json_agg(json_build_object(
               'country', trim(m.country), 'effectiveFrom', m.effective_from, 'effectiveTo', m.effective_to
             )) FILTER (WHERE m.country IS NOT NULL), '[]') AS members
      FROM trade.agreements a LEFT JOIN trade.agreement_members m ON m.agreement_id = a.id
      GROUP BY a.id ORDER BY a.code`;
    return rows.map((r) => ({
      id: r.id as string,
      code: r.code as string,
      nameEs: r.name_es as string,
      nameEn: r.name_en as string,
      proofOfOrigin: r.proof_of_origin as string,
      isSample: r.is_sample as boolean,
      members: (
        r.members as { country: string; effectiveFrom: string; effectiveTo: string | null }[]
      ).map((m) => ({
        ...m,
        effectiveFrom: d(m.effectiveFrom),
        effectiveTo: m.effectiveTo ? d(m.effectiveTo) : null,
      })),
    }));
  }

  async docRequirements(country: string): Promise<DocRequirementRow[]> {
    const rows = await this.sql<Record<string, unknown>[]>`
      SELECT * FROM trade.doc_requirements WHERE country = ${country} ORDER BY doc_code, hs_prefix NULLS FIRST`;
    return rows.map((r) => ({
      id: r.id as string,
      country: (r.country as string).trim(),
      direction: r.direction as DocRequirementRow['direction'],
      partnerScope: r.partner_scope as string,
      transportMode: r.transport_mode as DocRequirementRow['transportMode'],
      hsPrefix: (r.hs_prefix as string) ?? null,
      docCode: r.doc_code as string,
      nameEs: r.name_es as string,
      nameEn: r.name_en as string,
      issuer: r.issuer as string,
      requirement: r.requirement as DocRequirementRow['requirement'],
      notes: (r.notes as string) ?? null,
      isSample: r.is_sample as boolean,
    }));
  }
}

export class MemoryTradeReference implements TradeReference {
  constructor(private readonly data: { agreements: AgreementRow[]; docs: DocRequirementRow[] }) {}
  async agreements() {
    return this.data.agreements;
  }
  async docRequirements(country: string) {
    return this.data.docs.filter((r) => r.country === country);
  }
}
