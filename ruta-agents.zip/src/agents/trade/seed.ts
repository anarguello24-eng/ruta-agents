import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { parse } from 'csv-parse/sync';
import type { Queryable } from '../../core/db/client.js';

const read = async (dir: string, f: string) =>
  parse(await readFile(join(dir, f), 'utf8'), {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true,
  }) as Record<string, string>[];
const nul = (v: string | undefined) => (v === undefined || v === '' ? null : v);
const bool = (v: string | undefined) => (v ?? '').toLowerCase() === 'true';

/** Loads sample trade reference data (agreements, members, document rules). */
export async function seedTrade(sql: Queryable, seedDir: string) {
  const dir = join(seedDir, 'trade');
  const agreements = await read(dir, 'agreements.sample.csv');
  const members = await read(dir, 'agreement_members.sample.csv');
  const docs = await read(dir, 'doc_requirements.sample.csv');

  for (const a of agreements)
    await sql`
      INSERT INTO trade.agreements (code, name_es, name_en, proof_of_origin, notes, is_sample, source_url)
      VALUES (${a.code!}, ${a.name_es!}, ${a.name_en!}, ${a.proof_of_origin!}, ${nul(a.notes)},
              ${bool(a.is_sample)}, ${nul(a.source_url)})
      ON CONFLICT (code) DO UPDATE SET name_es = EXCLUDED.name_es, name_en = EXCLUDED.name_en,
        proof_of_origin = EXCLUDED.proof_of_origin, notes = EXCLUDED.notes,
        is_sample = EXCLUDED.is_sample, source_url = EXCLUDED.source_url`;
  for (const m of members)
    await sql`
      INSERT INTO trade.agreement_members (agreement_id, country, effective_from, effective_to)
      SELECT id, ${m.country!}, ${m.effective_from!}, ${nul(m.effective_to)}
      FROM trade.agreements WHERE code = ${m.agreement_code!}
      ON CONFLICT (agreement_id, country, effective_from) DO UPDATE SET effective_to = EXCLUDED.effective_to`;
  for (const r of docs)
    await sql`
      INSERT INTO trade.doc_requirements
        (country, direction, partner_scope, transport_mode, hs_prefix, doc_code, name_es, name_en,
         issuer, requirement, notes, is_sample, source_url)
      VALUES (${r.country!}, ${r.direction!}, ${r.partner_scope!}, ${r.transport_mode!}, ${nul(r.hs_prefix)},
              ${r.doc_code!}, ${r.name_es!}, ${r.name_en!}, ${r.issuer!}, ${r.requirement!}, ${nul(r.notes)},
              ${bool(r.is_sample)}, ${nul(r.source_url)})
      ON CONFLICT (country, direction, partner_scope, transport_mode, hs_prefix, doc_code) DO UPDATE SET
        name_es = EXCLUDED.name_es, name_en = EXCLUDED.name_en, issuer = EXCLUDED.issuer,
        requirement = EXCLUDED.requirement, notes = EXCLUDED.notes, is_sample = EXCLUDED.is_sample`;
  return { agreements: agreements.length, members: members.length, docRequirements: docs.length };
}
