import { z } from 'zod';
import type { Bilingual } from '../../core/i18n.js';

/**
 * Incoterms® 2020 cost/risk allocation. Pure reference data used by customs (building the CIF
 * customs value), sourcing (landed cost) and trade (responsibility matrix for clients).
 */
export const INCOTERMS = [
  'EXW',
  'FCA',
  'FAS',
  'FOB',
  'CFR',
  'CIF',
  'CPT',
  'CIP',
  'DAP',
  'DPU',
  'DDP',
] as const;
export type Incoterm = (typeof INCOTERMS)[number];
export const IncotermSchema = z.string().trim().toUpperCase().pipe(z.enum(INCOTERMS));

/** Cost blocks along the door-to-door chain, in order. */
export const COST_COMPONENTS = [
  'exportClearance',
  'originCharges', // pickup, origin handling, loading at the place of shipment
  'mainCarriage',
  'insurance',
  'destinationCharges', // unloading, destination handling, on-carriage to the buyer
  'importClearance',
  'importDuties',
] as const;
export type CostComponent = (typeof COST_COMPONENTS)[number];

export interface IncotermRule {
  code: Incoterm;
  name: Bilingual;
  /** 'any' = any mode incl. multimodal; 'sea' = sea and inland waterway only. */
  mode: 'any' | 'sea';
  /** Cost blocks the seller pays (i.e. included in the seller's price). */
  sellerPays: CostComponent[];
  /** Seller must buy cargo insurance (CIF: ICC (C) minimum; CIP: ICC (A)). */
  sellerMustInsure: false | 'ICC_C' | 'ICC_A';
  riskTransfers: Bilingual;
}

const upTo = (last: CostComponent, extra: CostComponent[] = []): CostComponent[] => [
  ...COST_COMPONENTS.slice(0, COST_COMPONENTS.indexOf(last) + 1),
  ...extra,
];

export const INCOTERM_RULES: Record<Incoterm, IncotermRule> = {
  EXW: {
    code: 'EXW',
    name: { es: 'En fábrica', en: 'Ex Works' },
    mode: 'any',
    sellerPays: [],
    sellerMustInsure: false,
    riskTransfers: {
      es: 'Al poner la mercancía a disposición del comprador en las instalaciones del vendedor, sin cargar.',
      en: "When the goods are placed at the buyer's disposal at the seller's premises, not loaded.",
    },
  },
  FCA: {
    code: 'FCA',
    name: { es: 'Franco transportista', en: 'Free Carrier' },
    mode: 'any',
    sellerPays: upTo('originCharges'),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'Al entregar la mercancía al transportista designado por el comprador en el lugar convenido.',
      en: 'When the goods are handed to the carrier nominated by the buyer at the named place.',
    },
  },
  FAS: {
    code: 'FAS',
    name: { es: 'Franco al costado del buque', en: 'Free Alongside Ship' },
    mode: 'sea',
    sellerPays: upTo('originCharges'),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'Al colocar la mercancía al costado del buque en el puerto de embarque.',
      en: 'When the goods are placed alongside the vessel at the port of shipment.',
    },
  },
  FOB: {
    code: 'FOB',
    name: { es: 'Franco a bordo', en: 'Free On Board' },
    mode: 'sea',
    sellerPays: upTo('originCharges'),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'Cuando la mercancía está a bordo del buque en el puerto de embarque.',
      en: 'When the goods are on board the vessel at the port of shipment.',
    },
  },
  CFR: {
    code: 'CFR',
    name: { es: 'Costo y flete', en: 'Cost and Freight' },
    mode: 'sea',
    sellerPays: upTo('mainCarriage'),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'A bordo del buque en origen, aunque el vendedor paga el flete hasta destino.',
      en: 'On board the vessel at origin, although the seller pays freight to destination.',
    },
  },
  CIF: {
    code: 'CIF',
    name: { es: 'Costo, seguro y flete', en: 'Cost, Insurance and Freight' },
    mode: 'sea',
    sellerPays: upTo('insurance'),
    sellerMustInsure: 'ICC_C',
    riskTransfers: {
      es: 'A bordo del buque en origen; el vendedor contrata seguro mínimo (ICC C).',
      en: 'On board the vessel at origin; the seller buys minimum cover (ICC C).',
    },
  },
  CPT: {
    code: 'CPT',
    name: { es: 'Transporte pagado hasta', en: 'Carriage Paid To' },
    mode: 'any',
    sellerPays: upTo('mainCarriage'),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'Al entregar la mercancía al primer transportista; el vendedor paga el transporte hasta destino.',
      en: 'On handover to the first carrier; the seller pays carriage to destination.',
    },
  },
  CIP: {
    code: 'CIP',
    name: { es: 'Transporte y seguro pagados hasta', en: 'Carriage and Insurance Paid To' },
    mode: 'any',
    sellerPays: upTo('insurance'),
    sellerMustInsure: 'ICC_A',
    riskTransfers: {
      es: 'Al entregar al primer transportista; el vendedor contrata seguro de cobertura amplia (ICC A).',
      en: 'On handover to the first carrier; the seller buys all-risks cover (ICC A).',
    },
  },
  DAP: {
    code: 'DAP',
    name: { es: 'Entregada en lugar', en: 'Delivered At Place' },
    mode: 'any',
    sellerPays: upTo('insurance', ['destinationCharges']),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'En el lugar de destino convenido, lista para descarga.',
      en: 'At the named place of destination, ready for unloading.',
    },
  },
  DPU: {
    code: 'DPU',
    name: { es: 'Entregada en lugar descargada', en: 'Delivered at Place Unloaded' },
    mode: 'any',
    sellerPays: upTo('insurance', ['destinationCharges']),
    sellerMustInsure: false,
    riskTransfers: {
      es: 'En el lugar de destino convenido, una vez descargada.',
      en: 'At the named place of destination, once unloaded.',
    },
  },
  DDP: {
    code: 'DDP',
    name: { es: 'Entregada con derechos pagados', en: 'Delivered Duty Paid' },
    mode: 'any',
    sellerPays: [...COST_COMPONENTS],
    sellerMustInsure: false,
    riskTransfers: {
      es: 'En el lugar de destino, despachada para importación y con derechos pagados.',
      en: 'At the named place of destination, cleared for import with duties paid.',
    },
  },
};

export const sellerPays = (term: Incoterm, c: CostComponent): boolean =>
  INCOTERM_RULES[term].sellerPays.includes(c);

/** Components that make up the CIF customs value (goods + everything up to arrival). */
export const CIF_COMPONENTS: CostComponent[] = [
  'exportClearance',
  'originCharges',
  'mainCarriage',
  'insurance',
];

/**
 * For building the CIF value from an invoice price under `term`:
 * `add` = cost blocks the buyer must add on top of the price;
 * `deduct` = blocks included in the price that are not part of the customs value.
 */
export function cifAdjustments(term: Incoterm): { add: CostComponent[]; deduct: CostComponent[] } {
  return {
    add: CIF_COMPONENTS.filter((c) => !sellerPays(term, c)),
    deduct: (['destinationCharges', 'importClearance', 'importDuties'] as CostComponent[]).filter(
      (c) => sellerPays(term, c),
    ),
  };
}

/** Responsibility matrix row for client-facing explanations. */
export function responsibilityMatrix(term: Incoterm, lang: 'es' | 'en') {
  const r = INCOTERM_RULES[term];
  return {
    code: r.code,
    name: r.name[lang],
    mode: r.mode,
    riskTransfers: r.riskTransfers[lang],
    sellerMustInsure: r.sellerMustInsure,
    costs: Object.fromEntries(
      COST_COMPONENTS.map((c) => [c, r.sellerPays.includes(c) ? 'seller' : 'buyer']),
    ) as Record<CostComponent, 'seller' | 'buyer'>,
  };
}
