import { z } from 'zod';
import { flag, type Flag, type Lang } from '../../core/i18n.js';
import { D, max, money, round, roundUp, sum, type Dec } from '../../core/money.js';
import { isEffective, type RateRef } from '../../core/rates.js';
import { MODES, type LogisticsReference, type Mode, type RateCard } from './reference.js';

/**
 * Freight quote engine. Deterministic: chargeable weight / W/M, weight-break selection
 * (including the "next break is cheaper" rule), minimum charges and surcharges.
 */

const dec = z
  .union([z.number(), z.string()])
  .transform((v) => String(v).trim())
  .pipe(z.string().regex(/^\d+(\.\d+)?$/))
  .refine((v) => D(v).greaterThan(0), 'must be greater than zero');

const locode = z
  .string()
  .trim()
  .toUpperCase()
  .regex(/^[A-Z]{2}[A-Z0-9]{3}$/, 'expected a UN/LOCODE such as USMIA');

export const QuoteInputSchema = z
  .object({
    country: z.string().length(2).toUpperCase().default('NI'),
    lang: z.enum(['es', 'en']).default('es'),
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    mode: z.enum(MODES as [Mode, ...Mode[]]),
    origin: locode,
    destination: locode,
    packages: z
      .array(
        z.object({
          qty: z.number().int().positive(),
          lengthCm: dec,
          widthCm: dec,
          heightCm: dec,
          weightKg: dec, // per package
        }),
      )
      .default([]),
    containers: z
      .array(
        z.object({
          type: z.enum(['20GP', '40GP', '40HC', '40RF']),
          qty: z.number().int().positive(),
        }),
      )
      .default([]),
  })
  .superRefine((v, ctx) => {
    if (v.mode === 'sea_fcl' && !v.containers.length)
      ctx.addIssue({ code: 'custom', path: ['containers'], message: 'FCL quotes need containers' });
    if (v.mode !== 'sea_fcl' && !v.packages.length)
      ctx.addIssue({
        code: 'custom',
        path: ['packages'],
        message: 'quotes need at least one package',
      });
  });
export type QuoteInput = z.input<typeof QuoteInputSchema>;

export interface QuoteLine {
  code: string;
  name: string;
  basis: string;
  qty: string;
  rate: string;
  amount: string;
}

export interface QuoteOption {
  carrier: string;
  rateCard: RateRef & { code: string };
  containerType: string | null;
  currency: string;
  transitDays: { min: number | null; max: number | null };
  chargeable: { qty: string; unit: string };
  lines: QuoteLine[];
  total: string;
}

export interface QuoteResult {
  mode: Mode;
  origin: string;
  destination: string;
  measures: { pieces: number; actualKg: string; volumeM3: string };
  options: QuoteOption[];
  isEstimate: boolean;
  flags: Flag[];
}

export function measure(packages: z.output<typeof QuoteInputSchema>['packages']) {
  const actualKg = sum(packages.map((p) => D(p.weightKg).times(p.qty)));
  const volumeCm3 = sum(
    packages.map((p) => D(p.lengthCm).times(p.widthCm).times(p.heightCm).times(p.qty)),
  );
  return {
    pieces: packages.reduce((a, p) => a + p.qty, 0),
    actualKg,
    volumeCm3,
    volumeM3: volumeCm3.dividedBy(1_000_000),
  };
}

/** Chargeable weight for air/courier/ground: max(actual, volume/divisor), rounded up to 0.5 kg. */
export function chargeableKg(actualKg: Dec, volumeCm3: Dec, divisor: number | null): Dec {
  const volumetric = divisor ? volumeCm3.dividedBy(divisor) : D(0);
  return roundUp(max(actualKg, volumetric).times(2), 0).dividedBy(2);
}

/** Sea LCL revenue tons: max(m3, metric tons), billed to 2 decimals (rounded up). */
export function revenueTons(actualKg: Dec, volumeM3: Dec): Dec {
  return roundUp(max(volumeM3, actualKg.dividedBy(1000)), 2);
}

/**
 * Freight for `qty` against weight breaks. Charges at the applicable break, but if a higher
 * break's minimum quantity × its rate is cheaper, charges that instead (standard air practice).
 */
export function freightForBreaks(qty: Dec, breaks: { fromQty: string; rate: string }[]) {
  const sorted = [...breaks].sort((a, b) => D(a.fromQty).comparedTo(D(b.fromQty)));
  const applicable = [...sorted].reverse().find((b) => D(b.fromQty).lessThanOrEqualTo(qty));
  if (!applicable) throw new Error('no applicable rate break');
  let best = { qty, rate: D(applicable.rate), amount: round(qty.times(applicable.rate)) };
  for (const b of sorted.filter((x) => D(x.fromQty).greaterThan(qty))) {
    const amount = round(D(b.fromQty).times(b.rate));
    if (amount.lessThan(best.amount)) best = { qty: D(b.fromQty), rate: D(b.rate), amount };
  }
  return best;
}

export async function quoteFreight(
  raw: QuoteInput,
  refData: LogisticsReference,
): Promise<QuoteResult> {
  const input = QuoteInputSchema.parse(raw);
  const lang: Lang = input.lang;
  const flags: Flag[] = [];
  const m = measure(input.packages);
  const cards = (await refData.rateCards(input)).filter((c) => isEffective(c, input.date));

  const options: QuoteOption[] = [];
  const containerQty = new Map(input.containers.map((c) => [c.type, c.qty]));

  if (input.mode === 'sea_fcl') {
    for (const c of input.containers)
      if (!cards.some((k) => k.containerType === c.type))
        flags.push(
          flag(
            lang,
            'NO_RATE_FOR_CONTAINER',
            'error',
            {
              es: 'No hay tarifa vigente para contenedor {type} en esta ruta.',
              en: 'No rate in force for a {type} container on this lane.',
            },
            { type: c.type },
          ),
        );
  }

  // FCL: one option per carrier summing all requested container types.
  const groups = new Map<string, RateCard[]>();
  for (const c of cards) {
    if (input.mode === 'sea_fcl' && !containerQty.has(c.containerType!)) continue;
    const key = input.mode === 'sea_fcl' ? c.carrier : c.id;
    groups.set(key, [...(groups.get(key) ?? []), c]);
  }

  for (const group of groups.values()) {
    if (input.mode === 'sea_fcl' && group.length !== input.containers.length) continue; // carrier lacks a type
    const lines: QuoteLine[] = [];
    let chargeable = D(0);
    let unitLabel = '';
    for (const card of group) {
      const name = (s: { nameEs: string; nameEn: string }) => (lang === 'es' ? s.nameEs : s.nameEn);
      let qty: Dec;
      if (card.unit === 'container') {
        qty = D(containerQty.get(card.containerType!) ?? 0);
        unitLabel = 'container';
      } else if (card.unit === 'wm') {
        qty = revenueTons(m.actualKg, m.volumeM3);
        unitLabel = 'wm';
      } else {
        qty = chargeableKg(m.actualKg, m.volumeCm3, card.volumetricDivisor);
        unitLabel = 'kg';
      }
      chargeable = chargeable.plus(qty);

      const f = freightForBreaks(qty, card.breaks);
      let freight = card.unit === 'container' ? round(qty.times(f.rate)) : f.amount;
      let freightLine: QuoteLine = {
        code: 'FREIGHT',
        name:
          (lang === 'es' ? 'Flete' : 'Freight') +
          (card.containerType ? ` ${card.containerType}` : ''),
        basis: unitLabel,
        qty: (card.unit === 'container' ? qty : f.qty).toString(),
        rate: f.rate.toString(),
        amount: money(freight),
      };
      if (freight.lessThan(card.minCharge)) {
        freight = round(card.minCharge);
        freightLine = {
          ...freightLine,
          code: 'FREIGHT_MIN',
          basis: 'minimum',
          qty: '1',
          rate: money(freight),
          amount: money(freight),
        };
      }
      lines.push(freightLine);

      for (const s of card.surcharges) {
        if (s.basis === 'per_shipment' && lines.some((l) => l.code === s.code)) continue; // once per shipment
        let q: Dec;
        let amount: Dec;
        if (s.basis === 'percent_of_freight') {
          q = freight;
          amount = round(freight.times(s.amount).dividedBy(100));
        } else if (s.basis === 'per_unit' || s.basis === 'per_container') {
          // Per chargeable kg / W/M / container actually shipped (not the break quantity).
          q = qty;
          amount = round(q.times(s.amount));
        } else {
          q = D(1);
          amount = round(s.amount);
        }
        if (s.minAmount !== null) amount = max(amount, round(s.minAmount));
        lines.push({
          code: s.code,
          name: name(s),
          basis: s.basis,
          qty: q.toString(),
          rate: D(s.amount).toString(),
          amount: money(amount),
        });
      }
    }

    const first = group[0]!;
    options.push({
      carrier: first.carrier,
      rateCard: {
        table: 'logistics.rate_cards',
        id: group.map((g) => g.id).join(','),
        code: group.map((g) => g.code).join(','),
        effectiveFrom: group
          .map((g) => g.effectiveFrom)
          .sort()
          .at(-1)!,
        isSample: group.some((g) => g.isSample),
      },
      containerType: input.mode === 'sea_fcl' ? group.map((g) => g.containerType).join('+') : null,
      currency: first.currency,
      transitDays: {
        min: group
          .map((g) => g.transitDaysMin)
          .reduce((a, b) => (a === null || b === null ? null : Math.max(a, b))),
        max: group
          .map((g) => g.transitDaysMax)
          .reduce((a, b) => (a === null || b === null ? null : Math.max(a, b))),
      },
      chargeable: { qty: chargeable.toString(), unit: unitLabel },
      lines,
      total: money(sum(lines.map((l) => l.amount))),
    });
  }

  const currencies = new Set(options.map((o) => o.currency));
  options.sort((a, b) =>
    currencies.size === 1 ? D(a.total).comparedTo(D(b.total)) : a.carrier.localeCompare(b.carrier),
  );
  if (currencies.size > 1)
    flags.push(
      flag(lang, 'MIXED_CURRENCIES', 'info', {
        es: 'Las opciones están en monedas distintas; no se ordenaron por precio.',
        en: 'Options are in different currencies; they were not sorted by price.',
      }),
    );
  if (!options.length && input.mode !== 'sea_fcl')
    flags.push(
      flag(
        lang,
        'NO_RATE',
        'error',
        {
          es: 'No hay tarifa vigente para {mode} {origin} → {destination}.',
          en: 'No rate in force for {mode} {origin} → {destination}.',
        },
        { mode: input.mode, origin: input.origin, destination: input.destination },
      ),
    );
  const isEstimate = options.some((o) => o.rateCard.isSample);
  if (isEstimate)
    flags.push(
      flag(lang, 'SAMPLE_RATE', 'warning', {
        es: 'Cotización con tarifas de ejemplo; no la envíe a un cliente.',
        en: 'Quote uses sample rates; do not send it to a client.',
      }),
    );

  return {
    mode: input.mode,
    origin: input.origin,
    destination: input.destination,
    measures: {
      pieces: m.pieces,
      actualKg: m.actualKg.toString(),
      volumeM3: round(m.volumeM3, 3).toString(),
    },
    options,
    isEstimate,
    flags,
  };
}

/** Lowest-total option, for other agents (sourcing landed cost). */
export const cheapest = (r: QuoteResult) =>
  r.options.reduce<QuoteOption | null>(
    (a, o) => (a && D(a.total).lessThanOrEqualTo(o.total) ? a : o),
    null,
  );
