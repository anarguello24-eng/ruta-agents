import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { parse } from 'csv-parse/sync';
import type { Queryable } from '../../core/db/client.js';
import type { Versioned } from '../../core/rates.js';

export type Mode = 'air' | 'courier' | 'sea_lcl' | 'sea_fcl' | 'ground';
export const MODES: Mode[] = ['air', 'courier', 'sea_lcl', 'sea_fcl', 'ground'];
export type ContainerType = '20GP' | '40GP' | '40HC' | '40RF';

export interface Surcharge {
  code: string;
  nameEs: string;
  nameEn: string;
  basis: 'per_unit' | 'per_shipment' | 'per_container' | 'percent_of_freight';
  amount: string;
  minAmount: string | null;
}

export interface RateCard extends Versioned {
  id: string;
  code: string;
  country: string;
  carrier: string;
  mode: Mode;
  origin: string;
  destination: string;
  containerType: ContainerType | null;
  unit: 'kg' | 'wm' | 'container';
  volumetricDivisor: number | null;
  minCharge: string;
  currency: string;
  transitDaysMin: number | null;
  transitDaysMax: number | null;
  isSample: boolean;
  breaks: { fromQty: string; rate: string }[];
  surcharges: Surcharge[];
}

export interface LogisticsReference {
  rateCards(q: {
    country: string;
    mode: Mode;
    origin: string;
    destination: string;
  }): Promise<RateCard[]>;
}

const d = (v: unknown) => (v instanceof Date ? v.toISOString().slice(0, 10) : String(v));

export class DbLogisticsReference implements LogisticsReference {
  constructor(private readonly sql: Queryable) {}

  async rateCards(q: { country: string; mode: Mode; origin: string; destination: string }) {
    const rows = await this.sql<Record<string, unknown>[]>`
      SELECT c.*, c.min_charge::text AS min_charge_t,
        (SELECT coalesce(json_agg(json_build_object('fromQty', b.from_qty::text, 'rate', b.rate::text)
                 ORDER BY b.from_qty), '[]') FROM logistics.rate_breaks b WHERE b.rate_card_id = c.id) AS breaks,
        (SELECT coalesce(json_agg(json_build_object('code', s.code, 'nameEs', s.name_es, 'nameEn', s.name_en,
                 'basis', s.basis, 'amount', s.amount::text, 'minAmount', s.min_amount::text) ORDER BY s.code), '[]')
           FROM logistics.surcharges s WHERE s.rate_card_id = c.id) AS surcharges
      FROM logistics.rate_cards c
      WHERE c.country = ${q.country} AND c.mode = ${q.mode}
        AND c.origin = ${q.origin} AND c.destination = ${q.destination}`;
    return rows.map((r) => ({
      id: r.id as string,
      code: r.code as string,
      country: (r.country as string).trim(),
      carrier: r.carrier as string,
      mode: r.mode as Mode,
      origin: r.origin as string,
      destination: r.destination as string,
      containerType: (r.container_type as ContainerType) ?? null,
      unit: r.unit as RateCard['unit'],
      volumetricDivisor: (r.volumetric_divisor as number) ?? null,
      minCharge: r.min_charge_t as string,
      currency: (r.currency as string).trim(),
      transitDaysMin: (r.transit_days_min as number) ?? null,
      transitDaysMax: (r.transit_days_max as number) ?? null,
      effectiveFrom: d(r.effective_from),
      effectiveTo: r.effective_to ? d(r.effective_to) : null,
      isSample: r.is_sample as boolean,
      breaks: r.breaks as RateCard['breaks'],
      surcharges: r.surcharges as Surcharge[],
    }));
  }
}

export class MemoryLogisticsReference implements LogisticsReference {
  constructor(private readonly cards: RateCard[]) {}
  async rateCards(q: { country: string; mode: Mode; origin: string; destination: string }) {
    return this.cards.filter(
      (c) =>
        c.country === q.country &&
        c.mode === q.mode &&
        c.origin === q.origin &&
        c.destination === q.destination,
    );
  }
}

const csv = async (dir: string, f: string) =>
  parse(await readFile(join(dir, f), 'utf8'), {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true,
  }) as Record<string, string>[];
const nul = (v: string | undefined) => (v === undefined || v === '' ? null : v);

/** Upserts sample rate cards, breaks and surcharges (rate card `code` is the natural key). */
export async function seedLogistics(sql: Queryable, seedDir: string) {
  const dir = join(seedDir, 'logistics');
  const cards = await csv(dir, 'rate_cards.sample.csv');
  const breaks = await csv(dir, 'rate_breaks.sample.csv');
  const surcharges = await csv(dir, 'surcharges.sample.csv');
  for (const c of cards)
    await sql`
      INSERT INTO logistics.rate_cards (code, country, carrier, mode, origin, destination, container_type, unit,
        volumetric_divisor, min_charge, currency, transit_days_min, transit_days_max, effective_from,
        effective_to, is_sample, notes)
      VALUES (${c.code!}, ${c.country!}, ${c.carrier!}, ${c.mode!}, ${c.origin!}, ${c.destination!},
        ${nul(c.container_type)}, ${c.unit!}, ${nul(c.volumetric_divisor)}, ${c.min_charge!}, ${c.currency!},
        ${nul(c.transit_days_min)}, ${nul(c.transit_days_max)}, ${c.effective_from!}, ${nul(c.effective_to)},
        ${c.is_sample === 'true'}, ${nul(c.notes)})
      ON CONFLICT (code) DO UPDATE SET carrier = EXCLUDED.carrier, min_charge = EXCLUDED.min_charge,
        currency = EXCLUDED.currency, volumetric_divisor = EXCLUDED.volumetric_divisor,
        transit_days_min = EXCLUDED.transit_days_min, transit_days_max = EXCLUDED.transit_days_max,
        effective_from = EXCLUDED.effective_from, effective_to = EXCLUDED.effective_to,
        is_sample = EXCLUDED.is_sample, notes = EXCLUDED.notes`;
  for (const b of breaks)
    await sql`
      INSERT INTO logistics.rate_breaks (rate_card_id, from_qty, rate)
      SELECT id, ${b.from_qty!}, ${b.rate!} FROM logistics.rate_cards WHERE code = ${b.card_code!}
      ON CONFLICT (rate_card_id, from_qty) DO UPDATE SET rate = EXCLUDED.rate`;
  for (const s of surcharges)
    await sql`
      INSERT INTO logistics.surcharges (rate_card_id, code, name_es, name_en, basis, amount, min_amount)
      SELECT id, ${s.code!}, ${s.name_es!}, ${s.name_en!}, ${s.basis!}, ${s.amount!}, ${nul(s.min_amount)}
      FROM logistics.rate_cards WHERE code = ${s.card_code!}
      ON CONFLICT (rate_card_id, code) DO UPDATE SET name_es = EXCLUDED.name_es, name_en = EXCLUDED.name_en,
        basis = EXCLUDED.basis, amount = EXCLUDED.amount, min_amount = EXCLUDED.min_amount`;
  return { rateCards: cards.length, breaks: breaks.length, surcharges: surcharges.length };
}
