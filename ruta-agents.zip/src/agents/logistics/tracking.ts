import { flag, type Flag, type Lang } from '../../core/i18n.js';
import type { Mode } from './reference.js';

/** Main shipment milestones in order. `customs_hold` and `cancelled` are side states. */
export const MILESTONES = [
  'booked',
  'picked_up',
  'at_origin_hub',
  'departed',
  'arrived',
  'in_customs',
  'released',
  'out_for_delivery',
  'delivered',
] as const;
export const SHIPMENT_STATUSES = [...MILESTONES, 'customs_hold', 'cancelled'] as const;
export type ShipmentStatus = (typeof SHIPMENT_STATUSES)[number];

const idx = (s: ShipmentStatus) => MILESTONES.indexOf(s as (typeof MILESTONES)[number]);

/**
 * Carriers often skip events, so forward jumps along the main sequence are allowed; going back
 * is not. A customs hold can only happen while in customs and returns to in_customs or released.
 * Cancellation is only possible before departure.
 */
export function canTransition(from: ShipmentStatus, to: ShipmentStatus): boolean {
  if (from === to) return false;
  if (from === 'delivered' || from === 'cancelled') return false;
  if (to === 'cancelled') return idx(from) >= 0 && idx(from) < idx('departed');
  if (to === 'customs_hold') return from === 'in_customs' || from === 'arrived';
  if (from === 'customs_hold') return to === 'in_customs' || to === 'released';
  return idx(to) > idx(from);
}

export interface ShipmentSnapshot {
  mode: Mode;
  status: ShipmentStatus;
  etaPromised: string | null; // YYYY-MM-DD
  etaCurrent: string | null;
  statusSince: Date;
  lastEventAt: Date | null;
  arrivedAt: Date | null;
  freeDays: number | null;
}

export interface ExceptionRules {
  etaSlipWarnDays: number;
  etaSlipErrorDays: number;
  staleHours: Record<Mode, number>;
  customsDwellDays: number;
}

export const DEFAULT_EXCEPTION_RULES: ExceptionRules = {
  etaSlipWarnDays: 2,
  etaSlipErrorDays: 5,
  staleHours: { air: 24, courier: 24, ground: 48, sea_lcl: 96, sea_fcl: 96 },
  customsDwellDays: 3,
};

const DAY = 86_400_000;
const daysBetween = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / DAY);
const IN_MOTION: ShipmentStatus[] = ['picked_up', 'at_origin_hub', 'departed', 'out_for_delivery'];

/** Deterministic exception detection; the agent turns these flags into client/ops messages. */
export function detectExceptions(
  s: ShipmentSnapshot,
  now: Date,
  lang: Lang,
  rules: ExceptionRules = DEFAULT_EXCEPTION_RULES,
): Flag[] {
  const flags: Flag[] = [];
  if (s.status === 'delivered' || s.status === 'cancelled') return flags;
  const today = now.toISOString().slice(0, 10);

  if (s.etaPromised && s.etaCurrent) {
    const slip = daysBetween(s.etaPromised, s.etaCurrent);
    if (slip >= rules.etaSlipWarnDays)
      flags.push(
        flag(
          lang,
          'ETA_SLIP',
          slip >= rules.etaSlipErrorDays ? 'error' : 'warning',
          {
            es: 'La llegada se retrasó {days} días (prometida {promised}, actual {current}).',
            en: 'Arrival slipped {days} days (promised {promised}, now {current}).',
          },
          { days: slip, promised: s.etaPromised, current: s.etaCurrent },
        ),
      );
  }

  const eta = s.etaCurrent ?? s.etaPromised;
  if (eta && today > eta && idx(s.status) < idx('arrived') && s.status !== 'customs_hold')
    flags.push(
      flag(
        lang,
        'OVERDUE_ARRIVAL',
        'error',
        {
          es: 'La fecha estimada de llegada ({eta}) ya pasó y el envío no ha llegado.',
          en: 'The estimated arrival date ({eta}) has passed and the shipment has not arrived.',
        },
        { eta },
      ),
    );

  if (IN_MOTION.includes(s.status)) {
    const last = s.lastEventAt ?? s.statusSince;
    const hours = (now.getTime() - last.getTime()) / 3_600_000;
    if (hours > rules.staleHours[s.mode])
      flags.push(
        flag(
          lang,
          'STALE_TRACKING',
          'warning',
          {
            es: 'Sin actualizaciones de rastreo desde hace {hours} horas.',
            en: 'No tracking updates for {hours} hours.',
          },
          { hours: Math.floor(hours) },
        ),
      );
  }

  if (s.status === 'customs_hold')
    flags.push(
      flag(lang, 'CUSTOMS_HOLD', 'error', {
        es: 'El envío está retenido en aduana.',
        en: 'The shipment is held by customs.',
      }),
    );
  if (s.status === 'in_customs' || s.status === 'customs_hold') {
    const dwell = Math.floor((now.getTime() - s.statusSince.getTime()) / DAY);
    if (dwell >= rules.customsDwellDays)
      flags.push(
        flag(
          lang,
          'CUSTOMS_DWELL',
          'warning',
          {
            es: 'Lleva {days} días en aduana.',
            en: 'It has been in customs for {days} days.',
          },
          { days: dwell },
        ),
      );
  }

  if (
    s.mode === 'sea_fcl' &&
    s.arrivedAt &&
    s.freeDays !== null &&
    idx(s.status) < idx('released')
  ) {
    const used = Math.floor((now.getTime() - s.arrivedAt.getTime()) / DAY);
    const left = s.freeDays - used;
    if (left < 0)
      flags.push(
        flag(
          lang,
          'DEMURRAGE',
          'error',
          {
            es: 'El contenedor excedió sus días libres por {days} días; se están generando cargos de demora.',
            en: 'The container is {days} days past its free time; demurrage is accruing.',
          },
          { days: -left },
        ),
      );
    else if (left <= 1)
      flags.push(
        flag(
          lang,
          'DEMURRAGE_RISK',
          'warning',
          {
            es: 'Quedan {days} días libres para el contenedor.',
            en: '{days} free days left for the container.',
          },
          { days: left },
        ),
      );
  }
  return flags;
}
