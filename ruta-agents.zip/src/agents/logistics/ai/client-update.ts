import { z } from 'zod';
import { auditSink, untrusted, type AiDeps } from '../../../core/ai/context.js';
import { requestApproval } from '../../../core/approvals.js';
import type { Flag, Lang } from '../../../core/i18n.js';
import { generateValidated } from '../../../core/llm/generate.js';
import { CLIENT_UPDATE_PROMPT } from '../../../prompts/logistics/client-update.v1.js';

export const ClientUpdateSchema = z.object({
  subject: z.string().min(3),
  body: z.string().min(10),
  internalNote: z.string(),
});

/** Drafts a client notice about a shipment (e.g. from detected exceptions) and queues it for ops. */
export async function draftClientUpdate(
  deps: AiDeps,
  args: {
    lang: Lang;
    shipmentId?: string | null;
    clientEmail: string;
    clientName: string;
    shipment: {
      reference: string;
      mode: string;
      origin: string;
      destination: string;
      status: string;
      etaPromised: string | null;
      etaCurrent: string | null;
    };
    flags: Flag[];
    requestedBy: string;
  },
) {
  const r = await generateValidated({
    provider: deps.provider,
    schema: ClientUpdateSchema,
    schemaName: 'client_update',
    prompt: CLIENT_UPDATE_PROMPT,
    effort: 'low',
    timeoutMs: deps.timeoutMs,
    messages: [
      { role: 'system', content: CLIENT_UPDATE_PROMPT.system },
      {
        role: 'user',
        content: [
          `Language: ${args.lang}`,
          `Client: ${untrusted('client_name', args.clientName)}`,
          `Shipment facts: ${JSON.stringify(args.shipment)}`,
          `Detected issues: ${JSON.stringify(args.flags.map((f) => ({ code: f.code, severity: f.severity, message: f.message })))}`,
        ].join('\n'),
      },
    ],
    audit: auditSink(deps.sql, 'logistics'),
    auditContext: {
      refId: args.shipmentId ?? null,
      entityType: 'shipment',
      entityId: args.shipment.reference,
      action: 'ai.client_update',
    },
  });
  const approval = await requestApproval(deps.sql, {
    agent: 'logistics',
    kind: 'email.send',
    title: `Update ${args.shipment.reference} → ${args.clientName}`,
    refId: args.shipmentId ?? null,
    requiredRole: 'ops',
    requestedByType: 'ai',
    requestedBy: args.requestedBy,
    payload: {
      to: args.clientEmail,
      subject: r.data.subject,
      body: r.data.body,
      internalNote: r.data.internalNote,
    },
  });
  return { approval, auditId: r.auditId };
}
