import { z } from 'zod';
import { flag, type Flag, type Lang } from '../../core/i18n.js';
import { allocate, D, max, money, pct, round, sum, type Dec } from '../../core/money.js';
import { calculateDuties } from '../customs/calculator.js';
import { getCountryProfile } from '../customs/countries/index.js';
import type { CustomsReference } from '../customs/rate-source.js';
import { normalizeCode } from '../customs/reference/csv.js';
import { cheapest, QuoteInputSchema, quoteFreight } from '../logistics/quote.js';
import type { LogisticsReference } from '../logistics/reference.js';
import { IncotermSchema, sellerPays } from '../trade/incoterms.js';

/**
 * Landed-cost comparison of supplier quotes. Pure TypeScript: freight comes from the logistics
 * quote engine (or an explicit freight quote), duties from the customs calculator. Scores are a
 * weighted sum of normalized components; weights are set by the buyer.
 */

const amount = z
  .union([z.number(), z.string()])
  .transform((v) => String(v).trim())
  .pipe(z.string().regex(/^\d+(\.\d+)?$/));
const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

export const WeightsSchema = z
  .object({
    landedCost: z.number().min(0).default(50),
    leadTime: z.number().min(0).default(20),
    onTime: z.number().min(0).default(10),
    rating: z.number().min(0).default(10),
    completeness: z.number().min(0).default(5),
    moq: z.number().min(0).default(5),
  })
  .refine((w) => Object.values(w).some((x) => x > 0), 'at least one weight must be positive');

const shipmentSpec = z.object({
  mode: QuoteInputSchema.shape.mode,
  origin: z.string(),
  packages: QuoteInputSchema.shape.packages,
  containers: QuoteInputSchema.shape.containers,
});

export const CompareInputSchema = z.object({
  country: z.string().length(2).toUpperCase().default('NI'),
  lang: z.enum(['es', 'en']).default('es'),
  date: dateStr,
  destination: z.string().toUpperCase().default('NIMGA'),
  /** Local-currency units per 1 unit of each foreign currency, e.g. { "USD": "36.6243" }. */
  exchangeRates: z.record(z.string().length(3).toUpperCase(), amount),
  /** Cargo insurance as % of goods + freight, used when the Incoterm leaves insurance to the buyer. */
  insuranceRatePct: amount.optional(),
  /** Include IVA in landed cost (only when the importer cannot credit it). */
  includeVat: z.boolean().default(false),
  weights: WeightsSchema.default({
    landedCost: 50,
    leadTime: 20,
    onTime: 10,
    rating: 10,
    completeness: 5,
    moq: 5,
  }),
  items: z
    .array(
      z.object({
        ref: z.string().min(1),
        description: z.string().min(1),
        quantity: amount.refine((v) => D(v).greaterThan(0)),
        unit: z.string().default('pcs'),
        sacCode: z
          .string()
          .transform(normalizeCode)
          .pipe(z.string().regex(/^\d{4,12}$/))
          .optional(),
        requiredBy: dateStr.optional(),
      }),
    )
    .min(1),
  quotes: z
    .array(
      z.object({
        quoteId: z.string().min(1),
        supplier: z.object({
          id: z.string(),
          name: z.string(),
          onTimeRate: z.number().min(0).max(1).nullable().default(null),
          rating: z.number().min(0).max(5).nullable().default(null),
        }),
        currency: z.string().length(3).toUpperCase(),
        incoterm: IncotermSchema,
        validUntil: dateStr.nullable().default(null),
        paymentTerms: z.string().nullable().default(null),
        lines: z
          .array(
            z.object({
              itemRef: z.string(),
              unitPrice: amount,
              moq: amount.nullable().default(null),
              leadTimeDays: z.number().int().nonnegative().nullable().default(null),
            }),
          )
          .min(1),
        /** Explicit freight quote for this supplier's shipment (e.g. from a forwarder). */
        freight: z.object({ amount, currency: z.string().length(3).toUpperCase() }).optional(),
        /** Or let the logistics agent quote it from rate cards. */
        shipment: shipmentSpec.optional(),
      }),
    )
    .min(1),
});
export type CompareInput = z.input<typeof CompareInputSchema>;

export interface RankedOffer {
  quoteId: string;
  supplierId: string;
  supplierName: string;
  eligible: boolean;
  purchaseQty: string;
  leadTimeDays: number | null;
  landed: {
    goods: string;
    freight: string;
    insurance: string;
    duties: string;
    vat: string;
    total: string;
    perRequiredUnit: string;
  };
  complete: boolean;
  score: number;
  components: Record<
    'landedCost' | 'leadTime' | 'onTime' | 'rating' | 'completeness' | 'moq',
    number
  >;
  flags: Flag[];
}

export interface CompareResult {
  localCurrency: string;
  isEstimate: boolean;
  items: { ref: string; description: string; recommended: string | null; offers: RankedOffer[] }[];
  flags: Flag[];
}

export interface CompareDeps {
  customs: CustomsReference;
  logistics: LogisticsReference;
}

const r1 = (n: number) => Math.round(n * 10) / 10;

type Parsed = z.output<typeof CompareInputSchema>;
type Draft = Omit<RankedOffer, 'score' | 'components'> & {
  perUnit: Dec;
  quote: Parsed['quotes'][number];
  line: Parsed['quotes'][number]['lines'][number];
};

export async function compareQuotes(raw: CompareInput, deps: CompareDeps): Promise<CompareResult> {
  const input = CompareInputSchema.parse(raw);
  const lang: Lang = input.lang;
  const profile = getCountryProfile(input.country);
  const flags: Flag[] = [];
  let isEstimate = false;

  const fx = (cur: string): Dec | null => {
    if (cur === profile.currency) return D(1);
    const r = input.exchangeRates[cur];
    return r ? D(r) : null;
  };
  const items = new Map(input.items.map((i) => [i.ref, i]));

  // Per quote → per item computed offer (before scoring).
  const offersByItem = new Map<string, Draft[]>();

  for (const q of input.quotes) {
    const qFlags: Flag[] = [];
    const rate = fx(q.currency);
    if (!rate) {
      flags.push(
        flag(
          lang,
          'MISSING_EXCHANGE_RATE',
          'error',
          {
            es: 'Falta el tipo de cambio para {cur} (cotización {quote}).',
            en: 'Missing exchange rate for {cur} (quote {quote}).',
          },
          { cur: q.currency, quote: q.quoteId },
        ),
      );
      continue;
    }
    const expired = q.validUntil !== null && q.validUntil < input.date;
    if (expired)
      qFlags.push(
        flag(
          lang,
          'QUOTE_EXPIRED',
          'warning',
          {
            es: 'La cotización venció el {date}.',
            en: 'The quote expired on {date}.',
          },
          { date: q.validUntil! },
        ),
      );

    const lines = q.lines.filter((l) => {
      if (items.has(l.itemRef)) return true;
      qFlags.push(
        flag(
          lang,
          'UNKNOWN_ITEM',
          'warning',
          {
            es: 'La cotización incluye un artículo que no está en la solicitud: {ref}.',
            en: 'The quote includes an item not in the RFQ: {ref}.',
          },
          { ref: l.itemRef },
        ),
      );
      return false;
    });
    if (!lines.length) continue;

    // Goods value in local currency, buying at least the MOQ.
    const purchase = lines.map((l) => {
      const item = items.get(l.itemRef)!;
      const qty = l.moq ? max(item.quantity, l.moq) : D(item.quantity);
      return { line: l, item, qty, goodsLocal: round(qty.times(l.unitPrice).times(rate)) };
    });
    const goodsWeights = purchase.map((p) => p.goodsLocal);

    // Freight to destination.
    let freightLocal = D(0);
    let freightKnown = true;
    if (!sellerPays(q.incoterm, 'mainCarriage')) {
      if (q.freight) {
        const fr = fx(q.freight.currency);
        if (fr) freightLocal = round(D(q.freight.amount).times(fr));
        else freightKnown = false;
      } else if (q.shipment) {
        const quote = await quoteFreight(
          {
            country: input.country,
            lang,
            date: input.date,
            mode: q.shipment.mode,
            origin: q.shipment.origin,
            destination: input.destination,
            packages: q.shipment.packages,
            containers: q.shipment.containers,
          },
          deps.logistics,
        );
        const best = cheapest(quote);
        const fr = best ? fx(best.currency) : null;
        if (best && fr) {
          freightLocal = round(D(best.total).times(fr));
          if (quote.isEstimate) isEstimate = true;
        } else freightKnown = false;
      } else freightKnown = false;
      if (!freightKnown)
        qFlags.push(
          flag(
            lang,
            'FREIGHT_UNKNOWN',
            'warning',
            {
              es: 'Con {term} el flete corre por cuenta del comprador y no se pudo estimar.',
              en: 'Under {term} freight is paid by the buyer and could not be estimated.',
            },
            { term: q.incoterm },
          ),
        );
    }

    // Insurance when the buyer must arrange it.
    let insuranceLocal = D(0);
    if (!sellerPays(q.incoterm, 'insurance')) {
      if (input.insuranceRatePct !== undefined)
        insuranceLocal = round(pct(sum(goodsWeights).plus(freightLocal), input.insuranceRatePct));
      else
        qFlags.push(
          flag(lang, 'INSURANCE_NOT_ESTIMATED', 'info', {
            es: 'No se indicó tasa de seguro; el costo puesto en destino no incluye seguro.',
            en: 'No insurance rate was given; landed cost excludes insurance.',
          }),
        );
    }
    if (q.incoterm === 'EXW')
      qFlags.push(
        flag(lang, 'EXW_ORIGIN_COSTS', 'info', {
          es: 'Precio EXW: no incluye despacho de exportación ni carga en origen.',
          en: 'EXW price: excludes export clearance and loading at origin.',
        }),
      );

    // Duties via the customs calculator, on the CIF built in local currency.
    const dutyLines = purchase.filter((p) => p.item.sacCode);
    const dutyByRef = new Map<string, { duties: Dec; vat: Dec }>();
    const buyerPaysDuties = !sellerPays(q.incoterm, 'importDuties');
    if (buyerPaysDuties && dutyLines.length) {
      const freightAlloc = allocate(freightLocal, goodsWeights);
      const insAlloc = allocate(insuranceLocal, goodsWeights);
      const idx = (p: (typeof purchase)[number]) => purchase.indexOf(p);
      const calc = await calculateDuties(
        {
          country: input.country,
          lang,
          calcDate: input.date,
          currency: profile.currency,
          exchangeRate: 1,
          incoterm: q.incoterm,
          freight: sum(dutyLines.map((p) => freightAlloc[idx(p)]!)).toString(),
          insurance: sum(dutyLines.map((p) => insAlloc[idx(p)]!)).toString(),
          lines: dutyLines.map((p) => ({
            ref: p.item.ref,
            value: p.goodsLocal.toString(),
            sacCode: p.item.sacCode!,
          })),
        },
        deps.customs,
      );
      if (calc.isEstimate) isEstimate = true;
      for (const l of calc.lines)
        dutyByRef.set(l.ref, {
          duties: D(l.dai?.amount ?? 0).plus(l.isc?.amount ?? 0),
          vat: D(l.vat?.amount ?? 0),
        });
      for (const f of calc.flags.filter(
        (x) => x.severity === 'error' && x.code === 'TARIFF_NOT_FOUND',
      ))
        qFlags.push(f);
    }

    const freightAlloc = allocate(freightLocal, goodsWeights);
    const insAlloc = allocate(insuranceLocal, goodsWeights);
    purchase.forEach((p, i) => {
      const itemFlags = [...qFlags];
      let complete = freightKnown;
      const duty = dutyByRef.get(p.item.ref);
      if (buyerPaysDuties && !duty) {
        complete = false;
        itemFlags.push(
          flag(
            lang,
            'DUTIES_UNKNOWN',
            'warning',
            {
              es: 'Sin código arancelario válido no se estimaron impuestos para {ref}.',
              en: 'Without a valid tariff code, duties were not estimated for {ref}.',
            },
            { ref: p.item.ref },
          ),
        );
      }
      if (p.line.moq && D(p.line.moq).greaterThan(p.item.quantity))
        itemFlags.push(
          flag(
            lang,
            'MOQ_ABOVE_QTY',
            'warning',
            {
              es: 'El mínimo de compra ({moq}) supera la cantidad pedida ({qty}).',
              en: 'The minimum order ({moq}) exceeds the requested quantity ({qty}).',
            },
            { moq: p.line.moq, qty: p.item.quantity },
          ),
        );
      const duties = duty?.duties ?? D(0);
      const vat = input.includeVat ? (duty?.vat ?? D(0)) : D(0);
      const total = p.goodsLocal.plus(freightAlloc[i]!).plus(insAlloc[i]!).plus(duties).plus(vat);
      const list = offersByItem.get(p.item.ref) ?? [];
      list.push({
        quoteId: q.quoteId,
        supplierId: q.supplier.id,
        supplierName: q.supplier.name,
        eligible: !expired,
        purchaseQty: p.qty.toString(),
        leadTimeDays: p.line.leadTimeDays,
        landed: {
          goods: money(p.goodsLocal),
          freight: money(freightAlloc[i]!),
          insurance: money(insAlloc[i]!),
          duties: money(duties),
          vat: money(vat),
          total: money(total),
          perRequiredUnit: money(total.dividedBy(p.item.quantity), 4),
        },
        complete,
        flags: itemFlags,
        perUnit: total.dividedBy(p.item.quantity),
        quote: q,
        line: p.line,
      });
      offersByItem.set(p.item.ref, list);
    });
  }

  // Score per item.
  const w = input.weights;
  const wSum = Object.values(w).reduce((a, b) => a + b, 0);
  const result: CompareResult['items'] = [];
  for (const item of input.items) {
    const raw = offersByItem.get(item.ref) ?? [];
    const minLanded = raw.length ? Dec_min(raw.map((o) => o.perUnit)) : D(0);
    const leads = raw.map((o) => o.leadTimeDays).filter((x): x is number => x !== null);
    const minLead = leads.length ? Math.min(...leads) : null;

    const offers: RankedOffer[] = raw.map(({ perUnit, quote, line, ...o }) => {
      const lead = o.leadTimeDays;
      let leadScore = 0;
      if (lead !== null) {
        if (item.requiredBy) {
          const arrival = new Date(Date.parse(input.date) + lead * 86_400_000)
            .toISOString()
            .slice(0, 10);
          const late = Math.max(
            0,
            Math.round((Date.parse(arrival) - Date.parse(item.requiredBy)) / 86_400_000),
          );
          leadScore = Math.max(0, 100 - 10 * late);
          if (late > 0)
            o.flags.push(
              flag(
                lang,
                'LATE_FOR_REQUIRED_DATE',
                'warning',
                {
                  es: 'Con {days} días de entrega llegaría {late} días tarde.',
                  en: 'With {days} days lead time it would arrive {late} days late.',
                },
                { days: lead, late },
              ),
            );
        } else leadScore = minLead !== null && lead > 0 ? (minLead / lead) * 100 : 100;
      }
      const fields = [line.leadTimeDays, line.moq, quote.validUntil, quote.paymentTerms];
      const components = {
        landedCost: perUnit.isZero() ? 100 : minLanded.dividedBy(perUnit).times(100).toNumber(),
        leadTime: leadScore,
        onTime: quote.supplier.onTimeRate === null ? 50 : quote.supplier.onTimeRate * 100,
        rating: quote.supplier.rating === null ? 50 : (quote.supplier.rating / 5) * 100,
        completeness:
          ((fields.filter((x) => x !== null).length + (o.complete ? 1 : 0)) / (fields.length + 1)) *
          100,
        moq:
          line.moq && D(line.moq).greaterThan(item.quantity)
            ? D(item.quantity).dividedBy(line.moq).times(100).toNumber()
            : 100,
      };
      const score = (Object.keys(components) as (keyof typeof components)[]).reduce(
        (a, k) => a + components[k] * w[k],
        0,
      );
      return {
        ...o,
        score: r1(score / wSum),
        components: Object.fromEntries(
          Object.entries(components).map(([k, v]) => [k, r1(v)]),
        ) as RankedOffer['components'],
      };
    });

    offers.sort(
      (a, b) =>
        Number(b.eligible) - Number(a.eligible) ||
        b.score - a.score ||
        D(a.landed.perRequiredUnit).comparedTo(D(b.landed.perRequiredUnit)) ||
        (a.leadTimeDays ?? Infinity) - (b.leadTimeDays ?? Infinity),
    );
    const top = offers.find((o) => o.eligible);
    if (!offers.length)
      flags.push(
        flag(
          lang,
          'NO_QUOTES_FOR_ITEM',
          'warning',
          {
            es: 'No hay cotizaciones para {ref}.',
            en: 'No quotes for {ref}.',
          },
          { ref: item.ref },
        ),
      );
    result.push({
      ref: item.ref,
      description: item.description,
      recommended: top?.quoteId ?? null,
      offers,
    });
  }

  if (isEstimate)
    flags.push(
      flag(lang, 'SAMPLE_RATE', 'warning', {
        es: 'La comparación usa tarifas de flete o aranceles de ejemplo; los totales son estimados.',
        en: 'The comparison uses sample freight or tariff rates; totals are estimates.',
      }),
    );

  return { localCurrency: profile.currency, isEstimate, items: result, flags };
}

const Dec_min = (xs: Dec[]) => xs.reduce((a, b) => (b.lessThan(a) ? b : a));
