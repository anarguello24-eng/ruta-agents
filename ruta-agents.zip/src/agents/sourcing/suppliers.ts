import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { parse } from 'csv-parse/sync';
import type { Queryable } from '../../core/db/client.js';

export interface SupplierHit {
  id: string;
  code: string | null;
  name: string;
  country: string;
  categories: string[];
  rating: number | null;
  onTimeRate: number | null;
  status: 'approved' | 'unvetted' | 'blocked';
  isSample: boolean;
  matchedOn: string[];
}

/**
 * Keyword/category supplier search over the approved supplier base (vector search is added with
 * the embeddings milestone). Blocked suppliers are never returned; unvetted only on request.
 */
export async function searchSuppliers(
  sql: Queryable,
  q: {
    text?: string;
    categories?: string[];
    countries?: string[];
    includeUnvetted?: boolean;
    limit?: number;
  },
): Promise<SupplierHit[]> {
  const words = (q.text ?? '')
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter((w) => w.length > 2);
  const cats = (q.categories ?? []).map((c) => c.toLowerCase());
  const statuses = q.includeUnvetted ? ['approved', 'unvetted'] : ['approved'];
  const rows = await sql<Record<string, unknown>[]>`
    SELECT id, code, name, trim(country) AS country, categories, rating::float8 AS rating,
           on_time_rate::float8 AS on_time_rate, status, is_sample,
           (SELECT count(*) FROM unnest(categories) c WHERE c = ANY(${cats}::text[])) AS cat_hits,
           (SELECT count(*) FROM unnest(${words}::text[]) w
             WHERE lower(name || ' ' || array_to_string(categories, ' ') || ' ' || coalesce(notes, '')) LIKE '%' || w || '%') AS word_hits
    FROM sourcing.suppliers
    WHERE status = ANY(${statuses}::text[])
      AND (${q.countries ?? null}::text[] IS NULL OR trim(country) = ANY(${q.countries ?? null}::text[]))
    ORDER BY cat_hits DESC, word_hits DESC, rating DESC NULLS LAST, name
    LIMIT ${q.limit ?? 20}`;
  return rows
    .filter(
      (r) => (!cats.length && !words.length) || Number(r.cat_hits) > 0 || Number(r.word_hits) > 0,
    )
    .map((r) => ({
      id: r.id as string,
      code: (r.code as string) ?? null,
      name: r.name as string,
      country: r.country as string,
      categories: r.categories as string[],
      rating: (r.rating as number) ?? null,
      onTimeRate: (r.on_time_rate as number) ?? null,
      status: r.status as SupplierHit['status'],
      isSample: r.is_sample as boolean,
      matchedOn: (r.categories as string[]).filter((c) => cats.includes(c)),
    }));
}

/** Loads sample suppliers and their primary contact. */
export async function seedSourcing(sql: Queryable, seedDir: string) {
  const rows = parse(await readFile(join(seedDir, 'sourcing', 'suppliers.sample.csv'), 'utf8'), {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true,
  }) as Record<string, string>[];
  for (const r of rows) {
    const [s] = await sql<{ id: string }[]>`
      INSERT INTO sourcing.suppliers (code, name, country, categories, languages, rating, on_time_rate, status, notes, is_sample)
      VALUES (${r.code!}, ${r.name!}, ${r.country!}, ${r.categories!.split(';')}, ${r.languages!.split(';')},
              ${r.rating || null}, ${r.on_time_rate || null}, ${r.status!}, ${r.notes || null}, true)
      ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name, categories = EXCLUDED.categories,
        languages = EXCLUDED.languages, rating = EXCLUDED.rating, on_time_rate = EXCLUDED.on_time_rate,
        status = EXCLUDED.status, notes = EXCLUDED.notes
      RETURNING id`;
    await sql`
      INSERT INTO sourcing.supplier_contacts (supplier_id, name, email, language, is_primary)
      VALUES (${s!.id}, ${r.contact_name || null}, ${r.email!}, ${r.languages!.split(';')[0]!}, true)
      ON CONFLICT (supplier_id, email) DO NOTHING`;
  }
  return { suppliers: rows.length };
}
