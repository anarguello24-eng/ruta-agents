export const RFQ_STATUSES = [
  'draft',
  'sourcing',
  'quoting',
  'evaluating',
  'negotiating',
  'awarded',
  'po_issued',
  'closed',
  'cancelled',
] as const;
export type RfqStatus = (typeof RFQ_STATUSES)[number];

const NEXT: Record<RfqStatus, RfqStatus[]> = {
  draft: ['sourcing', 'cancelled'],
  sourcing: ['quoting', 'cancelled'],
  quoting: ['evaluating', 'cancelled'],
  evaluating: ['negotiating', 'awarded', 'quoting', 'cancelled'],
  negotiating: ['evaluating', 'awarded', 'cancelled'],
  awarded: ['po_issued'],
  po_issued: ['closed'],
  closed: [],
  cancelled: [],
};

/** Statuses that require a human buyer to perform the transition. */
export const BUYER_ONLY: RfqStatus[] = ['awarded', 'po_issued', 'cancelled'];

export const canTransitionRfq = (from: RfqStatus, to: RfqStatus) => NEXT[from].includes(to);
