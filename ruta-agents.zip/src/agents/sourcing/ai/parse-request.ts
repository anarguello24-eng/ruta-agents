import { z } from 'zod';
import { auditSink, untrusted, type AiDeps } from '../../../core/ai/context.js';
import type { Lang } from '../../../core/i18n.js';
import { generateValidated } from '../../../core/llm/generate.js';
import type { LLMFile } from '../../../core/llm/provider.js';
import { PARSE_REQUEST_PROMPT } from '../../../prompts/sourcing/parse-request.v1.js';

export const ParsedRequestSchema = z.object({
  title: z.string(),
  items: z.array(
    z.object({
      description: z.string(),
      specs: z.string().nullable(),
      quantity: z.number().positive().nullable(),
      unit: z.string().nullable(),
      targetPrice: z.number().nonnegative().nullable(),
      targetCurrency: z.string().nullable(),
    }),
  ),
  requiredBy: z.string().nullable(),
  destination: z.string().nullable(),
  preferredIncoterm: z.string().nullable(),
  missingInfo: z.array(z.string()),
});

/** Turns a client's request into RFQ items; items get stable refs (ITEM-1, ITEM-2, ...) in code. */
export async function parsePurchaseRequest(
  deps: AiDeps,
  args: { text: string; files?: LLMFile[]; lang: Lang; rfqId?: string | null },
) {
  const r = await generateValidated({
    provider: deps.provider,
    schema: ParsedRequestSchema,
    schemaName: 'rfq_request',
    prompt: PARSE_REQUEST_PROMPT,
    purpose: args.files?.length ? 'vision' : 'text',
    files: args.files,
    timeoutMs: deps.timeoutMs,
    messages: [
      { role: 'system', content: PARSE_REQUEST_PROMPT.system },
      {
        role: 'user',
        content: `Language for missingInfo: ${args.lang}.\nClient request:\n${untrusted('client_request', args.text)}`,
      },
    ],
    audit: auditSink(deps.sql, 'sourcing'),
    auditContext: {
      refId: args.rfqId ?? null,
      entityType: 'rfq',
      entityId: args.rfqId ?? null,
      action: 'ai.parse_request',
    },
  });
  const d = r.data;
  return {
    ...d,
    requiredBy: d.requiredBy && /^\d{4}-\d{2}-\d{2}$/.test(d.requiredBy) ? d.requiredBy : null,
    items: d.items.map((it, i) => ({ ref: `ITEM-${i + 1}`, ...it })),
    auditId: r.auditId,
  };
}
