import { z } from 'zod';
import { auditSink, untrusted, type AiDeps } from '../../../core/ai/context.js';
import { requestApproval } from '../../../core/approvals.js';
import { conflict, notFound } from '../../../core/errors.js';
import { generateValidated } from '../../../core/llm/generate.js';
import { DRAFT_RFQ_EMAIL_PROMPT } from '../../../prompts/sourcing/draft-rfq-email.v1.js';

export const EmailDraftSchema = z.object({ subject: z.string().min(3), body: z.string().min(10) });

/**
 * Drafts the RFQ email for one supplier and queues it for buyer approval. Nothing is sent here:
 * the approved payload is what the mail sender later uses.
 */
export async function draftRfqEmail(
  deps: AiDeps,
  args: {
    rfqRef: string;
    rfqId?: string | null;
    supplierId: string;
    items: {
      ref: string;
      description: string;
      specs?: string | null;
      quantity: string | number;
      unit: string;
    }[];
    replyBy: string;
    buyerName: string;
    requestedBy: string;
  },
) {
  const [supplier] = await deps.sql<
    {
      id: string;
      name: string;
      status: string;
      email: string | null;
      contact_name: string | null;
      language: string | null;
    }[]
  >`
    SELECT s.id, s.name, s.status, c.email, c.name AS contact_name, c.language
    FROM sourcing.suppliers s
    LEFT JOIN sourcing.supplier_contacts c ON c.supplier_id = s.id AND c.is_primary
    WHERE s.id = ${args.supplierId}`;
  if (!supplier) throw notFound('supplier');
  if (supplier.status === 'blocked') throw conflict('supplier is blocked');
  if (!supplier.email) throw notFound('supplier contact email');

  const language =
    supplier.language === 'zh' || supplier.language === 'es' ? supplier.language : 'en';
  const tag = `[${args.rfqRef}]`;
  const r = await generateValidated({
    provider: deps.provider,
    schema: EmailDraftSchema,
    schemaName: 'email_draft',
    prompt: DRAFT_RFQ_EMAIL_PROMPT,
    timeoutMs: deps.timeoutMs,
    messages: [
      { role: 'system', content: DRAFT_RFQ_EMAIL_PROMPT.system },
      {
        role: 'user',
        content: [
          `Supplier language: ${language}`,
          `Supplier company: ${untrusted('supplier_name', supplier.name)}`,
          `Contact name: ${untrusted('contact_name', supplier.contact_name ?? '')}`,
          `Reference tag: ${tag}`,
          `Reply by: ${args.replyBy}`,
          `Buyer (signature): ${args.buyerName}, RUTA CARGO`,
          `Items: ${JSON.stringify(args.items)}`,
        ].join('\n'),
      },
    ],
    audit: auditSink(deps.sql, 'sourcing'),
    auditContext: {
      refId: args.rfqId ?? null,
      entityType: 'supplier',
      entityId: supplier.id,
      action: 'ai.draft_rfq_email',
    },
  });

  const subject = r.data.subject.includes(tag) ? r.data.subject : `${tag} ${r.data.subject}`;
  const approval = await requestApproval(deps.sql, {
    agent: 'sourcing',
    kind: 'email.send',
    title: `RFQ ${args.rfqRef} → ${supplier.name}`,
    refId: args.rfqId ?? null,
    requiredRole: 'buyer',
    requestedByType: 'ai',
    requestedBy: args.requestedBy,
    payload: {
      to: supplier.email,
      subject,
      body: r.data.body,
      language,
      supplierId: supplier.id,
      rfqRef: args.rfqRef,
    },
  });
  return { approval, auditId: r.auditId };
}
