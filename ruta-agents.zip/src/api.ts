import { Hono, type Context } from 'hono';
import { z } from 'zod';
import { calculateDuties } from './agents/customs/calculator.js';
import { crossCheck } from './agents/customs/crosscheck.js';
import { ExtractedDocumentSchema } from './agents/customs/extraction-schema.js';
import { checkPermits } from './agents/customs/permits.js';
import { DbCustomsReference } from './agents/customs/rate-source.js';
import { normalizeCode } from './agents/customs/reference/csv.js';
import { quoteFreight } from './agents/logistics/quote.js';
import { DbLogisticsReference } from './agents/logistics/reference.js';
import { detectExceptions, SHIPMENT_STATUSES } from './agents/logistics/tracking.js';
import { compareQuotes } from './agents/sourcing/compare.js';
import { searchSuppliers } from './agents/sourcing/suppliers.js';
import { buildChecklist } from './agents/trade/checklist.js';
import { INCOTERMS, responsibilityMatrix } from './agents/trade/incoterms.js';
import { agreementsBetween, DbTradeReference } from './agents/trade/reference.js';
import { decideApproval, getApproval, listApprovals } from './core/approvals.js';
import { requireAuth, requireRole, type AuthEnv, type TokenVerifier } from './core/auth.js';
import type { Queryable } from './core/db/client.js';
import type { LLMProvider } from './core/llm/provider.js';
import { aiRoutes } from './ai-api.js';

const today = () => new Date().toISOString().slice(0, 10);
const lang = (c: Context) => (c.req.query('lang') === 'en' ? 'en' : 'es');
const body = async (c: Context) => {
  try {
    return await c.req.json();
  } catch {
    return {};
  }
};

/** Countries whose goods may get preferential treatment in `country` on `date`. */
async function preferentialOrigins(trade: DbTradeReference, country: string, date: string) {
  const all = await trade.agreements();
  const partners = new Set(all.flatMap((a) => a.members.map((m) => m.country)));
  return [...partners].filter(
    (p) => p !== country && agreementsBetween(all, country, p, date).length,
  );
}

/**
 * JSON API under /api. Every route needs a Supabase session token; roles gate what each user
 * can do. These endpoints are deterministic tools; the LLM-driven workflows build on them.
 */
export function apiRoutes(deps: {
  sql: Queryable;
  verify: TokenVerifier;
  provider: LLMProvider | null;
  aiTimeoutMs: number;
  allowedFileHosts: string[];
}) {
  const api = new Hono<AuthEnv>();
  const customs = new DbCustomsReference(deps.sql);
  const trade = new DbTradeReference(deps.sql);
  const logistics = new DbLogisticsReference(deps.sql);

  api.use('*', requireAuth(deps.verify));

  api.get('/me', (c) => c.json(c.get('user')));

  api.route(
    '/ai',
    aiRoutes({
      sql: deps.sql,
      provider: deps.provider,
      timeoutMs: deps.aiTimeoutMs,
      allowedFileHosts: deps.allowedFileHosts,
    }),
  );

  // ---- Customs -------------------------------------------------------------------------
  api.post('/customs/calculate', requireRole('staff', 'broker'), async (c) =>
    c.json(await calculateDuties(await body(c), customs)),
  );

  api.post('/customs/cross-check', requireRole('staff', 'broker'), async (c) => {
    const input = z
      .object({
        country: z.string().length(2).toUpperCase().default('NI'),
        lang: z.enum(['es', 'en']).default('es'),
        date: z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}$/)
          .default(today()),
        documents: z.array(ExtractedDocumentSchema).min(1),
      })
      .parse(await body(c));
    const flags = crossCheck(input.documents, {
      lang: input.lang,
      preferentialOrigins: await preferentialOrigins(trade, input.country, input.date),
    });
    return c.json({ flags });
  });

  api.post('/customs/permits', requireRole('staff', 'broker'), async (c) => {
    const input = z
      .object({
        country: z.string().length(2).toUpperCase().default('NI'),
        lang: z.enum(['es', 'en']).default('es'),
        lines: z
          .array(
            z.object({
              ref: z.string(),
              sacCode: z
                .string()
                .transform(normalizeCode)
                .pipe(z.string().regex(/^\d{2,12}$/)),
            }),
          )
          .min(1),
        provided: z
          .array(z.object({ agency: z.string(), permitName: z.string().optional() }))
          .default([]),
      })
      .parse(await body(c));
    return c.json(await checkPermits(customs, input));
  });

  // ---- Import / export -----------------------------------------------------------------
  api.get('/trade/incoterms', (c) =>
    c.json(INCOTERMS.map((t) => responsibilityMatrix(t, lang(c)))),
  );

  api.post('/trade/checklist', requireRole('staff', 'ops', 'broker', 'buyer'), async (c) =>
    c.json(await buildChecklist(await body(c), trade, customs)),
  );

  // ---- Logistics -----------------------------------------------------------------------
  api.post('/logistics/quote', requireRole('staff', 'ops', 'buyer'), async (c) =>
    c.json(await quoteFreight(await body(c), logistics)),
  );

  api.post('/logistics/exceptions', requireRole('staff', 'ops'), async (c) => {
    const input = z
      .object({
        lang: z.enum(['es', 'en']).default('es'),
        mode: z.enum(['air', 'courier', 'sea_lcl', 'sea_fcl', 'ground']),
        status: z.enum(SHIPMENT_STATUSES),
        etaPromised: z.string().nullable().default(null),
        etaCurrent: z.string().nullable().default(null),
        statusSince: z.coerce.date(),
        lastEventAt: z.coerce.date().nullable().default(null),
        arrivedAt: z.coerce.date().nullable().default(null),
        freeDays: z.number().int().nullable().default(null),
      })
      .parse(await body(c));
    return c.json({ flags: detectExceptions(input, new Date(), input.lang) });
  });

  // ---- Sourcing ------------------------------------------------------------------------
  api.get('/sourcing/suppliers', requireRole('staff', 'buyer'), async (c) => {
    const csv = (k: string) => c.req.query(k)?.split(',').filter(Boolean);
    return c.json(
      await searchSuppliers(deps.sql, {
        text: c.req.query('q'),
        categories: csv('category'),
        countries: csv('country'),
        includeUnvetted: c.req.query('includeUnvetted') === 'true',
      }),
    );
  });

  api.post('/sourcing/compare', requireRole('staff', 'buyer'), async (c) =>
    c.json(await compareQuotes(await body(c), { customs, logistics })),
  );

  // ---- Human approvals (shared) ---------------------------------------------------------
  api.get('/approvals', async (c) => {
    const q = z
      .object({
        status: z
          .enum(['pending', 'approved', 'rejected', 'executed', 'failed', 'cancelled'])
          .optional(),
        agent: z.enum(['customs', 'sourcing', 'logistics', 'trade']).optional(),
      })
      .parse(c.req.query());
    return c.json(await listApprovals(deps.sql, q));
  });

  api.get('/approvals/:id', async (c) => c.json(await getApproval(deps.sql, c.req.param('id'))));

  api.post('/approvals/:id/decision', async (c) => {
    const input = z
      .object({
        decision: z.enum(['approve', 'reject']),
        note: z.string().max(2000).optional(),
        editedPayload: z.unknown().optional(),
      })
      .parse(await body(c));
    return c.json(
      await decideApproval(deps.sql, { id: c.req.param('id'), user: c.get('user'), ...input }),
    );
  });

  return api;
}
