import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { secureHeaders } from 'hono/secure-headers';
import { ZodError } from 'zod';
import { apiRoutes } from './api.js';
import { createVerifier, type TokenVerifier } from './core/auth.js';
import type { Config } from './core/config.js';
import type { DbHandle } from './core/db/client.js';
import { AppError } from './core/errors.js';
import { healthRoutes } from './core/health.js';
import { createLLMProvider } from './core/llm/index.js';
import type { LLMProvider } from './core/llm/provider.js';

export interface AppDeps {
  config: Config;
  db: DbHandle;
  /** Override token verification (tests). Defaults to Supabase JWT verification from config. */
  verify?: TokenVerifier;
  /** Override the LLM provider (tests). Defaults to Anthropic when ANTHROPIC_API_KEY is set. */
  provider?: LLMProvider | null;
}

export function createApp({ config, db, verify, provider }: AppDeps) {
  const app = new Hono();

  app.use('*', secureHeaders());
  const origins = config.CORS_ORIGINS.split(',')
    .map((o) => o.trim())
    .filter(Boolean);
  if (origins.length) {
    app.use('*', cors({ origin: origins, allowHeaders: ['Authorization', 'Content-Type'] }));
  }

  app.route('/', healthRoutes({ sql: db.sql, defaultCountry: config.DEFAULT_COUNTRY }));

  const verifier =
    verify ??
    (config.SUPABASE_JWT_SECRET || config.SUPABASE_URL
      ? createVerifier({ jwtSecret: config.SUPABASE_JWT_SECRET, supabaseUrl: config.SUPABASE_URL })
      : null);
  if (verifier)
    app.route(
      '/api',
      apiRoutes({
        sql: db.sql,
        verify: verifier,
        provider: provider === undefined ? createLLMProvider(config) : provider,
        aiTimeoutMs: config.AGENT_STEP_TIMEOUT_MS,
        allowedFileHosts: config.SUPABASE_URL ? [new URL(config.SUPABASE_URL).host] : [],
      }),
    );
  else
    // Fail closed: without auth configuration the API is unavailable rather than open.
    app.all('/api/*', (c) =>
      c.json(
        { error: 'auth_not_configured', message: 'Set SUPABASE_JWT_SECRET or SUPABASE_URL' },
        503,
      ),
    );

  app.notFound((c) => c.json({ error: 'not_found' }, 404));
  app.onError((err, c) => {
    if (err instanceof AppError)
      return c.json({ error: err.code, message: err.message, details: err.details }, err.status);
    if (err instanceof ZodError)
      return c.json(
        {
          error: 'invalid_input',
          issues: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
        },
        400,
      );
    console.error(err);
    return c.json({ error: 'internal_error' }, 500);
  });

  return app;
}
