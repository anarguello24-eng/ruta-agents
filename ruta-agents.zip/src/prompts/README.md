# Prompts

One file per prompt, named `<agent>.<task>.v<N>.ts`, exporting `{ id, version, system, render }`.
Edit a prompt → bump `version` (the audit log stores `id@version` for every AI call).
Prompts never ask the model to do arithmetic, convert currencies or recall rates: those come
from the deterministic engines and reference tables. Supplier emails and uploaded documents are
always passed as data inside clearly delimited blocks, never as instructions.
