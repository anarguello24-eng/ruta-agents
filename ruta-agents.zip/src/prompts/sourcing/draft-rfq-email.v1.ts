import { UNTRUSTED_RULE } from '../../core/ai/context.js';

export const DRAFT_RFQ_EMAIL_PROMPT = {
  id: 'sourcing.draft_rfq_email',
  version: '1',
  system: `You draft a request-for-quotation email from RUTA CARGO (Nicaragua) to a supplier. A human buyer reviews and approves it before it is sent.

Rules:
- Write in the language requested for the supplier (es, en or zh). Professional, concise, friendly.
- List every item with quantity, unit and specs exactly as given; do not add or drop items.
- Ask the supplier to reply with, per item: unit price and currency, minimum order quantity, production lead time, Incoterm and named place, quote validity date, and payment terms.
- Mention the reply-by date and the reference tag exactly as given, and ask the supplier to keep the reference in the subject.
- Never mention other suppliers, target prices or budgets unless explicitly provided as shareable.
- Sign as the buyer named in the input. Do not invent phone numbers, addresses or promises.
- ${UNTRUSTED_RULE}`,
};
