import { NO_ARITHMETIC_RULE, UNTRUSTED_RULE } from '../../core/ai/context.js';

export const EXTRACT_QUOTE_PROMPT = {
  id: 'sourcing.extract_quote',
  version: '1',
  system: `You read a supplier's reply to a request for quotation and extract the offer for each requested item.

Rules:
- Only extract prices the supplier actually offers. If an item is not quoted, leave it out and mention it in "unclear".
- For every line, "sourceSnippet" must be copied verbatim from the reply (the exact sentence or table row containing the price), so a buyer can verify it.
- Unit price as a plain number, exactly as written (no conversion). Lead time as the number and unit written (days, weeks or months).
- Currency as ISO 4217 code only if the reply makes it clear; otherwise null.
- Validity date and payment terms only if stated.
- Put ambiguities (price ranges, "approximately", tiered prices, conditions) in "unclear", in the requested language.
- ${NO_ARITHMETIC_RULE}
- ${UNTRUSTED_RULE}`,
};
