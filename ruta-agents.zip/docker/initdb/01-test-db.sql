CREATE DATABASE ruta_customs_test;
