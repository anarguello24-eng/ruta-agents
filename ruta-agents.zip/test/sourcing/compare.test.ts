import { describe, expect, it } from 'vitest';
import { MemoryCustomsReference, type TariffRow } from '../../src/agents/customs/rate-source.js';
import { MemoryLogisticsReference } from '../../src/agents/logistics/reference.js';
import { compareQuotes, type CompareInput } from '../../src/agents/sourcing/compare.js';
import { canTransitionRfq } from '../../src/agents/sourcing/rfq.js';

const tariff = (code: string, dai: string, isSample = false): TariffRow => ({
  id: code,
  country: 'NI',
  code,
  descriptionEs: code,
  descriptionEn: null,
  daiRate: dai,
  iscRate: null,
  effectiveFrom: '2020-01-01',
  effectiveTo: null,
  isSample,
});

const deps = {
  customs: new MemoryCustomsReference({
    tariff: [tariff('84713000', '0'), tariff('61091000', '15')],
    taxes: [
      {
        id: 'iva',
        country: 'NI',
        taxName: 'IVA',
        rate: '15',
        effectiveFrom: '2013-01-01',
        effectiveTo: null,
        isSample: false,
      },
    ],
  }),
  logistics: new MemoryLogisticsReference([
    {
      id: 'lcl',
      code: 'LCL',
      country: 'NI',
      carrier: 'Ocean',
      mode: 'sea_lcl',
      origin: 'CNSHA',
      destination: 'NICIO',
      containerType: null,
      unit: 'wm',
      volumetricDivisor: null,
      minCharge: '0',
      currency: 'USD',
      transitDaysMin: 35,
      transitDaysMax: 45,
      effectiveFrom: '2026-01-01',
      effectiveTo: null,
      isSample: true,
      breaks: [{ fromQty: '0', rate: '100' }],
      surcharges: [],
    },
  ]),
};

const supplier = (id: string, rating: number | null, onTimeRate: number | null) => ({
  id,
  name: id,
  rating,
  onTimeRate,
});

const base: CompareInput = {
  date: '2026-11-04',
  destination: 'NICIO',
  exchangeRates: { USD: '36' },
  insuranceRatePct: '0.5',
  items: [{ ref: 'LAPTOP', description: 'Laptop 14"', quantity: '100', sacCode: '8471.30.00' }],
  quotes: [
    {
      quoteId: 'A',
      supplier: supplier('cn', 4.2, 0.88),
      currency: 'USD',
      incoterm: 'FOB',
      validUntil: '2026-12-01',
      paymentTerms: 'T/T 30/70',
      freight: { amount: '1200', currency: 'USD' },
      lines: [{ itemRef: 'LAPTOP', unitPrice: '300', moq: '50', leadTimeDays: 40 }],
    },
    {
      quoteId: 'B',
      supplier: supplier('us', 4.5, 0.95),
      currency: 'USD',
      incoterm: 'CIF',
      lines: [{ itemRef: 'LAPTOP', unitPrice: '340', leadTimeDays: 10 }],
    },
  ],
};

describe('compareQuotes', () => {
  it('normalizes FOB and CIF quotes to landed cost in local currency', async () => {
    const r = await compareQuotes(base, deps);
    expect(r.localCurrency).toBe('NIO');
    const [laptop] = r.items;
    const a = laptop!.offers.find((o) => o.quoteId === 'A')!;
    const b = laptop!.offers.find((o) => o.quoteId === 'B')!;
    // A: 100 × 300 × 36 = 1,080,000 + freight 43,200 + insurance 0.5 % of 1,123,200 = 5,616; DAI 0
    expect(a.landed).toEqual({
      goods: '1080000.00',
      freight: '43200.00',
      insurance: '5616.00',
      duties: '0.00',
      vat: '0.00',
      total: '1128816.00',
      perRequiredUnit: '11288.1600',
    });
    // B: CIF price includes freight and insurance.
    expect(b.landed).toMatchObject({ freight: '0.00', insurance: '0.00', total: '1224000.00' });
  });

  it('scores with buyer weights: cheaper is not always best', async () => {
    const r = await compareQuotes(base, deps);
    const [laptop] = r.items;
    expect(laptop!.offers.map((o) => [o.quoteId, o.score])).toEqual([
      ['B', 91.6],
      ['A', 82.2],
    ]);
    expect(laptop!.recommended).toBe('B');
    // Price-only weighting flips the result.
    const priceOnly = await compareQuotes(
      {
        ...base,
        weights: { landedCost: 1, leadTime: 0, onTime: 0, rating: 0, completeness: 0, moq: 0 },
      },
      deps,
    );
    expect(priceOnly.items[0]!.recommended).toBe('A');
  });

  it('adds duties from the customs calculator and optionally IVA', async () => {
    const input: CompareInput = {
      ...base,
      items: [{ ref: 'TSHIRT', description: 'T-shirt', quantity: '1000', sacCode: '61091000' }],
      quotes: [
        {
          quoteId: 'C',
          supplier: supplier('cn2', null, null),
          currency: 'USD',
          incoterm: 'CIF',
          lines: [{ itemRef: 'TSHIRT', unitPrice: '2' }],
        },
      ],
    };
    const r = await compareQuotes(input, deps);
    // CIF 72,000 → DAI 15 % = 10,800
    expect(r.items[0]!.offers[0]!.landed).toMatchObject({
      goods: '72000.00',
      duties: '10800.00',
      vat: '0.00',
      total: '82800.00',
    });
    const withVat = await compareQuotes({ ...input, includeVat: true }, deps);
    // IVA 15 % of (72,000 + 10,800)
    expect(withVat.items[0]!.offers[0]!.landed).toMatchObject({
      vat: '12420.00',
      total: '95220.00',
    });
  });

  it('quotes freight through the logistics agent when only a shipment is given', async () => {
    const r = await compareQuotes(
      {
        ...base,
        quotes: [
          {
            ...base.quotes[0]!,
            freight: undefined,
            shipment: {
              mode: 'sea_lcl',
              origin: 'CNSHA',
              packages: [{ qty: 10, lengthCm: 100, widthCm: 50, heightCm: 40, weightKg: 50 }], // 2 m3
            },
          },
        ],
      },
      deps,
    );
    expect(r.items[0]!.offers[0]!.landed.freight).toBe('7200.00'); // 2 W/M × 100 USD × 36
    expect(r.isEstimate).toBe(true);
    expect(r.flags.map((f) => f.code)).toEqual(['SAMPLE_RATE']);
  });

  it('flags unknown freight, MOQ above quantity, expired quotes and missing tariff codes', async () => {
    const r = await compareQuotes(
      {
        ...base,
        lang: 'en',
        items: [{ ref: 'LAPTOP', description: 'Laptop', quantity: '20' }],
        quotes: [
          { ...base.quotes[0]!, freight: undefined, validUntil: '2026-10-01' },
          base.quotes[1]!,
        ],
      },
      deps,
    );
    const a = r.items[0]!.offers.find((o) => o.quoteId === 'A')!;
    expect(a.eligible).toBe(false);
    expect(a.complete).toBe(false);
    expect(a.purchaseQty).toBe('50');
    expect(a.flags.map((f) => f.code)).toEqual([
      'QUOTE_EXPIRED',
      'FREIGHT_UNKNOWN',
      'DUTIES_UNKNOWN',
      'MOQ_ABOVE_QTY',
    ]);
    expect(r.items[0]!.recommended).toBe('B');
    expect(r.items[0]!.offers[0]!.quoteId).toBe('B'); // eligible offers first
  });

  it('penalizes offers that arrive after the required date', async () => {
    const r = await compareQuotes(
      { ...base, items: [{ ...base.items[0]!, requiredBy: '2026-11-30' }] },
      deps,
    );
    const a = r.items[0]!.offers.find((o) => o.quoteId === 'A')!;
    expect(a.components.leadTime).toBe(0); // 40 days → arrives 14 Dec, 14 days late
    expect(a.flags.map((f) => f.code)).toContain('LATE_FOR_REQUIRED_DATE');
    const b = r.items[0]!.offers.find((o) => o.quoteId === 'B')!;
    expect(b.components.leadTime).toBe(100);
  });

  it('does not add duties for DDP quotes and reports missing exchange rates', async () => {
    const r = await compareQuotes(
      {
        ...base,
        quotes: [
          { ...base.quotes[1]!, quoteId: 'D', incoterm: 'DDP' },
          { ...base.quotes[1]!, quoteId: 'E', currency: 'EUR' },
        ],
      },
      deps,
    );
    expect(r.items[0]!.offers.map((o) => o.quoteId)).toEqual(['D']);
    expect(r.items[0]!.offers[0]!.landed.duties).toBe('0.00');
    expect(r.flags.map((f) => f.code)).toEqual(['MISSING_EXCHANGE_RATE']);
  });
});

describe('RFQ status flow', () => {
  it('only allows defined transitions', () => {
    expect(canTransitionRfq('draft', 'sourcing')).toBe(true);
    expect(canTransitionRfq('draft', 'awarded')).toBe(false);
    expect(canTransitionRfq('evaluating', 'awarded')).toBe(true);
    expect(canTransitionRfq('awarded', 'cancelled')).toBe(false);
    expect(canTransitionRfq('closed', 'draft')).toBe(false);
  });
});
