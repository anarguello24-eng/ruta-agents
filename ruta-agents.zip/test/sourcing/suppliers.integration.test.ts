import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { searchSuppliers } from '../../src/agents/sourcing/suppliers.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { freshTestDb, hasTestDb } from '../helpers/db.js';

describe.skipIf(!hasTestDb)('supplier search (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  it('finds approved suppliers by category, best rated first', async () => {
    const hits = await searchSuppliers(h.sql, { categories: ['electronics'] });
    expect(hits.map((x) => x.code)).toEqual(['SUP-US-01', 'SUP-CN-01', 'SUP-PA-01']);
    expect(hits.every((x) => x.isSample)).toBe(true);
  });

  it('includes unvetted suppliers only on request and filters by country', async () => {
    expect((await searchSuppliers(h.sql, { categories: ['toys'] })).map((x) => x.code)).toEqual([]);
    expect(
      (await searchSuppliers(h.sql, { categories: ['toys'], includeUnvetted: true })).map(
        (x) => x.code,
      ),
    ).toEqual(['SUP-CN-04']);
    expect(
      (await searchSuppliers(h.sql, { text: 'apparel', countries: ['PA'] })).map((x) => x.code),
    ).toEqual(['SUP-PA-01']);
  });

  it('never returns blocked suppliers', async () => {
    await h.sql`UPDATE sourcing.suppliers SET status = 'blocked' WHERE code = 'SUP-US-01'`;
    expect(
      (await searchSuppliers(h.sql, { categories: ['electronics'] })).map((x) => x.code),
    ).not.toContain('SUP-US-01');
  });
});
