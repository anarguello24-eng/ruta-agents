import type Anthropic from '@anthropic-ai/sdk';
import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { AnthropicProvider, fileBlocks, LLMRefusalError } from '../../src/core/llm/anthropic.js';
import { generateValidated } from '../../src/core/llm/generate.js';
import { createLLMProvider } from '../../src/core/llm/index.js';
import { loadConfig } from '../../src/core/config.js';

type Params = Record<string, unknown> & { messages: { role: string; content: unknown }[] };

/** Minimal stand-in for the SDK client: records requests, replays canned messages. */
function fakeClient(replies: Partial<Anthropic.Beta.BetaMessage>[]) {
  const calls: { params: Params; options: unknown }[] = [];
  const client = {
    beta: {
      messages: {
        stream: (params: Params, options: unknown) => {
          calls.push({ params, options });
          const reply = replies.shift();
          if (!reply) throw new Error('no reply left');
          return {
            finalMessage: async () => ({
              model: 'claude-opus-5-5',
              stop_reason: 'end_turn',
              stop_details: null,
              content: [],
              ...reply,
            }),
          };
        },
      },
    },
  } as unknown as Anthropic;
  return { client, calls };
}

const text = (t: string) => ({
  content: [{ type: 'text', text: t, citations: null }] as Anthropic.Beta.BetaContentBlock[],
});

const Schema = z.object({ code: z.string(), confidence: z.number().int().min(0).max(100) });

const provider = (client: Anthropic) =>
  new AnthropicProvider({
    client,
    model: 'claude-opus-5-5',
    visionModel: 'claude-opus-5-5',
    effort: 'medium',
  });

describe('AnthropicProvider.generateJSON', () => {
  it('sends a cached system prompt, structured output format, effort and server-side fallbacks', async () => {
    const { client, calls } = fakeClient([text('{"code":"84713000","confidence":90}')]);
    const r = await provider(client).generateJSON({
      schema: Schema,
      jsonSchema: {},
      schemaName: 'x',
      effort: 'high',
      messages: [
        { role: 'system', content: 'You classify goods.' },
        { role: 'user', content: 'laptop' },
      ],
    });
    expect(r).toEqual({ raw: '{"code":"84713000","confidence":90}', model: 'claude-opus-5-5' });
    const p = calls[0]!.params;
    expect(p).toMatchObject({
      model: 'claude-opus-5-5',
      system: [{ type: 'text', text: 'You classify goods.', cache_control: { type: 'ephemeral' } }],
      messages: [{ role: 'user', content: 'laptop' }],
      output_config: { effort: 'high', format: { type: 'json_schema' } },
      betas: ['server-side-fallback-2026-07-01'],
      fallbacks: 'default',
    });
    const schema = (p.output_config as { format: { schema: Record<string, unknown> } }).format
      .schema;
    expect(schema).toMatchObject({ type: 'object', additionalProperties: false });
    expect(Object.keys((schema as { properties: object }).properties)).toEqual([
      'code',
      'confidence',
    ]);
  });

  it('puts PDFs and images before the text of the first user message', async () => {
    const { client, calls } = fakeClient([text('{}')]);
    await provider(client).generateJSON({
      jsonSchema: { type: 'object' },
      schemaName: 'x',
      purpose: 'vision',
      files: [
        {
          name: 'invoice.pdf',
          mimeType: 'application/pdf',
          data: new TextEncoder().encode('%PDF'),
        },
        { name: 'bl.png', mimeType: 'image/png', data: new Uint8Array([1, 2, 3]) },
      ],
      messages: [{ role: 'user', content: 'extract' }],
    });
    const content = calls[0]!.params.messages[0]!.content as { type: string }[];
    expect(content.map((b) => b.type)).toEqual(['document', 'image', 'text']);
    expect(content[0]).toMatchObject({
      title: 'invoice.pdf',
      source: {
        type: 'base64',
        media_type: 'application/pdf',
        data: Buffer.from('%PDF').toString('base64'),
      },
    });
  });

  it('turns refusals and truncation into errors (so the validated retry kicks in)', async () => {
    const { client } = fakeClient([
      {
        stop_reason: 'refusal',
        stop_details: { type: 'refusal', category: 'cyber', explanation: null },
      } as never,
      { stop_reason: 'max_tokens' },
    ]);
    const p = provider(client);
    const req = {
      jsonSchema: {},
      schemaName: 'x',
      messages: [{ role: 'user' as const, content: 'x' }],
    };
    await expect(p.generateJSON(req)).rejects.toBeInstanceOf(LLMRefusalError);
    await expect(p.generateJSON(req)).rejects.toThrow(/max_tokens/);
  });

  it('works end-to-end with generateValidated: retry carries the validation error', async () => {
    const { client, calls } = fakeClient([
      text('{"code":"x","confidence":500}'),
      text('{"code":"x","confidence":50}'),
    ]);
    const audits: unknown[] = [];
    const r = await generateValidated({
      provider: provider(client),
      schema: Schema,
      schemaName: 'classification',
      prompt: { id: 't', version: '1' },
      messages: [
        { role: 'system', content: 'sys' },
        { role: 'user', content: 'u' },
      ],
      audit: async (e) => audits.push(e),
      auditContext: { entityType: 'line', action: 'classify' },
    });
    expect(r.data).toEqual({ code: 'x', confidence: 50 });
    const second = calls[1]!.params.messages;
    expect(second.map((m) => m.role)).toEqual(['user', 'assistant', 'user']);
    expect(String(second[2]!.content)).toMatch(/confidence/);
  });

  it('rejects unsupported file types', () => {
    expect(() =>
      fileBlocks([{ name: 'a.docx', mimeType: 'application/msword', data: new Uint8Array() }]),
    ).toThrow(/unsupported/);
  });
});

describe('AnthropicProvider.embed (Voyage)', () => {
  it('batches requests and returns vectors in input order', async () => {
    const bodies: { input: string[]; input_type: string; output_dimension: number }[] = [];
    const fetchFake = (async (_url: string, init: { body: string }) => {
      const b = JSON.parse(init.body) as (typeof bodies)[number];
      bodies.push(b);
      const data = b.input.map((_, i) => ({ index: i, embedding: [i] })).reverse();
      return new Response(JSON.stringify({ data }), { status: 200 });
    }) as unknown as typeof fetch;
    const p = new AnthropicProvider({
      client: {} as Anthropic,
      model: 'm',
      visionModel: 'm',
      effort: 'medium',
      embeddings: { apiKey: 'k', model: 'voyage-3.5', dimensions: 1024, fetch: fetchFake },
    });
    const v = await p.embed(
      Array.from({ length: 130 }, (_, i) => `t${i}`),
      { kind: 'query' },
    );
    expect(v).toHaveLength(130);
    expect(v[0]).toEqual([0]);
    expect(v[129]).toEqual([1]);
    expect(bodies.map((b) => b.input.length)).toEqual([128, 2]);
    expect(bodies[0]).toMatchObject({ input_type: 'query', output_dimension: 1024 });
  });

  it('fails clearly without a Voyage key', async () => {
    await expect(provider({} as Anthropic).embed(['x'])).rejects.toThrow(/VOYAGE_API_KEY/);
  });
});

describe('createLLMProvider', () => {
  it('returns null without an API key and an Anthropic provider with one', () => {
    expect(createLLMProvider(loadConfig({ DATABASE_URL: 'postgres://x/y' }))).toBeNull();
    const p = createLLMProvider(
      loadConfig({ DATABASE_URL: 'postgres://x/y', ANTHROPIC_API_KEY: 'sk-test' }),
    );
    expect(p?.name).toBe('anthropic');
  });
});
