import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { DbCustomsReference } from '../../src/agents/customs/rate-source.js';
import { buildChecklist } from '../../src/agents/trade/checklist.js';
import { DbTradeReference } from '../../src/agents/trade/reference.js';
import { seedTrade } from '../../src/agents/trade/seed.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { freshTestDb, hasTestDb, SEED_DIR } from '../helpers/db.js';

describe.skipIf(!hasTestDb)('trade reference data (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  it('re-seeding is idempotent', async () => {
    const count = async () =>
      (await h.sql<{ n: number }[]>`SELECT count(*)::int AS n FROM trade.doc_requirements`)[0]!.n;
    const before = await count();
    await seedTrade(h.sql, SEED_DIR);
    expect(await count()).toBe(before);
  });

  it('builds a checklist from the seeded sample rules', async () => {
    const r = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'US',
        transportMode: 'sea',
        hsCode: '85171300',
      },
      new DbTradeReference(h.sql),
      new DbCustomsReference(h.sql),
    );
    expect(r.agreements.map((a) => a.code)).toEqual(['CAFTA-DR']);
    expect(r.documents.map((d) => d.code)).toEqual(
      expect.arrayContaining([
        'COMMERCIAL_INVOICE',
        'PACKING_LIST',
        'BILL_OF_LADING',
        'DUCA_D',
        'PROOF_OF_ORIGIN:CAFTA-DR',
      ]),
    );
    expect(r.documents.some((d) => d.source === 'permit' && d.issuer === 'TELCOR')).toBe(true);
    expect(r.flags.map((f) => f.code)).toContain('SAMPLE_TRADE_DATA');
  });

  it('knows EU members are partners under EU-CA', async () => {
    const r = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'export',
        partnerCountry: 'DE',
        transportMode: 'sea',
        hsCode: '09011100',
      },
      new DbTradeReference(h.sql),
    );
    expect(r.agreements.map((a) => a.code)).toEqual(['EU-CA']);
    expect(r.documents.map((d) => d.code)).toContain('PHYTOSANITARY_CERT');
  });
});
