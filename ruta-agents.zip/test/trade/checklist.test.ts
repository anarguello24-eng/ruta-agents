import { describe, expect, it } from 'vitest';
import { MemoryCustomsReference } from '../../src/agents/customs/rate-source.js';
import { buildChecklist, missingDocuments } from '../../src/agents/trade/checklist.js';
import {
  agreementsBetween,
  MemoryTradeReference,
  type AgreementRow,
  type DocRequirementRow,
} from '../../src/agents/trade/reference.js';

const ag = (
  code: string,
  members: [string, string, string?][],
  isSample = false,
): AgreementRow => ({
  id: code,
  code,
  nameEs: code,
  nameEn: code,
  proofOfOrigin: 'Certificado',
  isSample,
  members: members.map(([country, effectiveFrom, effectiveTo]) => ({
    country,
    effectiveFrom,
    effectiveTo: effectiveTo ?? null,
  })),
});

const rule = (over: Partial<DocRequirementRow>): DocRequirementRow => ({
  id: over.docCode ?? 'x',
  country: 'NI',
  direction: 'both',
  partnerScope: 'any',
  transportMode: 'any',
  hsPrefix: null,
  docCode: 'X',
  nameEs: over.docCode ?? 'X',
  nameEn: over.docCode ?? 'X',
  issuer: 'issuer',
  requirement: 'required',
  notes: null,
  isSample: false,
  ...over,
});

const agreements = [
  ag('MCCA', [
    ['NI', '1963-01-01'],
    ['CR', '1963-01-01'],
  ]),
  ag('CAFTA-DR', [
    ['NI', '2006-04-01'],
    ['US', '2006-03-01'],
    ['CR', '2009-01-01'],
  ]),
  ag('CN-NI', [
    ['NI', '2024-01-01'],
    ['CN', '2024-01-01'],
  ]),
];
const docs = [
  rule({ docCode: 'COMMERCIAL_INVOICE' }),
  rule({ docCode: 'BILL_OF_LADING', transportMode: 'sea' }),
  rule({ docCode: 'AIR_WAYBILL', transportMode: 'air' }),
  rule({ docCode: 'DUCA_D', direction: 'import', partnerScope: 'non_mcca' }),
  rule({ docCode: 'DUCA_F', partnerScope: 'mcca' }),
  rule({ docCode: 'EXPORT_DECLARATION', direction: 'export', partnerScope: 'non_mcca' }),
  rule({ docCode: 'IMPORT_PERMITS', direction: 'import', requirement: 'conditional' }),
  rule({ docCode: 'PHYTOSANITARY_CERT', direction: 'export', hsPrefix: '09' }),
];
const tradeRef = new MemoryTradeReference({ agreements, docs });
const customsRef = new MemoryCustomsReference({
  permits: [
    {
      id: 'p',
      country: 'NI',
      sacPrefix: '30',
      agency: 'MINSA',
      permitName: 'Registro sanitario',
      notes: null,
      isSample: false,
    },
  ],
});

const codes = (r: { documents: { code: string }[] }) => r.documents.map((d) => d.code);

describe('agreementsBetween', () => {
  it('respects each member’s entry date', () => {
    expect(agreementsBetween(agreements, 'NI', 'CR', '2008-01-01').map((a) => a.code)).toEqual([
      'MCCA',
    ]);
    expect(agreementsBetween(agreements, 'NI', 'CR', '2010-01-01').map((a) => a.code)).toEqual([
      'MCCA',
      'CAFTA-DR',
    ]);
    expect(agreementsBetween(agreements, 'NI', 'CN', '2023-12-31')).toEqual([]);
  });
});

describe('buildChecklist', () => {
  it('import from the US by sea: DUCA-D, BL, CAFTA-DR proof of origin, permits by HS code', async () => {
    const r = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'US',
        transportMode: 'sea',
        hsCode: '3004.90.00',
      },
      tradeRef,
      customsRef,
    );
    expect(r.intraRegional).toBe(false);
    expect(r.agreements.map((a) => a.code)).toEqual(['CAFTA-DR']);
    expect(codes(r)).toEqual([
      'COMMERCIAL_INVOICE',
      'BILL_OF_LADING',
      'DUCA_D',
      'PERMIT:MINSA:Registro sanitario',
      'PROOF_OF_ORIGIN:CAFTA-DR',
    ]);
    expect(r.flags).toEqual([]);
  });

  it('import from Costa Rica uses DUCA-F instead of DUCA-D', async () => {
    const r = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'CR',
        transportMode: 'air',
        wantsPreference: false,
      },
      tradeRef,
    );
    expect(r.intraRegional).toBe(true);
    expect(codes(r)).toEqual(['COMMERCIAL_INVOICE', 'AIR_WAYBILL', 'DUCA_F', 'IMPORT_PERMITS']);
    expect(r.documents.find((d) => d.code === 'IMPORT_PERMITS')!.requirement).toBe('conditional');
  });

  it('coffee export to China adds the phytosanitary certificate and CN-NI proof of origin', async () => {
    const r = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'export',
        partnerCountry: 'CN',
        transportMode: 'sea',
        hsCode: '09011100',
        lang: 'en',
      },
      tradeRef,
    );
    expect(codes(r)).toEqual([
      'COMMERCIAL_INVOICE',
      'BILL_OF_LADING',
      'EXPORT_DECLARATION',
      'PHYTOSANITARY_CERT',
      'PROOF_OF_ORIGIN:CN-NI',
    ]);
    expect(r.documents.at(-1)!.issuer).toBe('Nicaraguan exporter');
  });

  it('asks for the HS code when product-specific rules exist', async () => {
    const r = await buildChecklist(
      { date: '2026-11-04', direction: 'export', partnerCountry: 'US', transportMode: 'sea' },
      tradeRef,
    );
    expect(r.flags.map((f) => f.code)).toEqual(['HS_CODE_NEEDED']);
  });

  it('warns about Incoterm pitfalls', async () => {
    const exw = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'export',
        partnerCountry: 'US',
        transportMode: 'air',
        hsCode: '6109',
        incoterm: 'EXW',
      },
      tradeRef,
    );
    expect(exw.flags.map((f) => f.code)).toEqual(['EXW_EXPORT_CLEARANCE']);
    const fobAir = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'US',
        transportMode: 'air',
        incoterm: 'FOB',
        lang: 'en',
      },
      tradeRef,
    );
    expect(fobAir.flags[0]!.message).toBe('FOB is for sea transport only; for air use FCA.');
    const ddp = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'US',
        transportMode: 'sea',
        incoterm: 'DDP',
      },
      tradeRef,
    );
    expect(ddp.flags.map((f) => f.code)).toEqual(['DDP_IMPORT_CLEARANCE']);
    const cif = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'US',
        transportMode: 'sea',
        incoterm: 'CIF',
      },
      tradeRef,
    );
    expect(codes(cif)).toContain('INSURANCE_CERTIFICATE');
  });

  it('lists required documents not yet received', async () => {
    const r = await buildChecklist(
      {
        date: '2026-11-04',
        direction: 'import',
        partnerCountry: 'US',
        transportMode: 'sea',
        hsCode: '84713000',
      },
      tradeRef,
      customsRef,
    );
    const missing = missingDocuments(r, [
      { code: 'COMMERCIAL_INVOICE', status: 'verified' },
      { code: 'BILL_OF_LADING', status: 'pending' },
    ]);
    expect(missing.map((d) => d.code)).toEqual(['BILL_OF_LADING', 'DUCA_D']);
  });
});
