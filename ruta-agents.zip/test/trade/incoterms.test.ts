import { describe, expect, it } from 'vitest';
import {
  cifAdjustments,
  INCOTERM_RULES,
  INCOTERMS,
  IncotermSchema,
  responsibilityMatrix,
  sellerPays,
} from '../../src/agents/trade/incoterms.js';

describe('Incoterms 2020', () => {
  it('has the 11 rules, four of them sea-only', () => {
    expect(INCOTERMS).toHaveLength(11);
    expect(INCOTERMS.filter((t) => INCOTERM_RULES[t].mode === 'sea')).toEqual([
      'FAS',
      'FOB',
      'CFR',
      'CIF',
    ]);
  });

  it('normalizes user input', () => {
    expect(IncotermSchema.parse(' fob ')).toBe('FOB');
    expect(() => IncotermSchema.parse('DDU')).toThrow(); // retired in 2010
  });

  it('allocates main carriage and insurance correctly', () => {
    expect(sellerPays('FOB', 'mainCarriage')).toBe(false);
    expect(sellerPays('CFR', 'mainCarriage')).toBe(true);
    expect(sellerPays('CFR', 'insurance')).toBe(false);
    expect(sellerPays('CIF', 'insurance')).toBe(true);
    expect(sellerPays('EXW', 'exportClearance')).toBe(false);
    expect(sellerPays('DDP', 'importDuties')).toBe(true);
    expect(sellerPays('DAP', 'importDuties')).toBe(false);
  });

  it('only CIF and CIP oblige the seller to insure', () => {
    expect(INCOTERMS.filter((t) => INCOTERM_RULES[t].sellerMustInsure)).toEqual(['CIF', 'CIP']);
    expect(INCOTERM_RULES.CIP.sellerMustInsure).toBe('ICC_A');
  });

  it('computes what to add or deduct to reach the CIF customs value', () => {
    expect(cifAdjustments('EXW')).toEqual({
      add: ['exportClearance', 'originCharges', 'mainCarriage', 'insurance'],
      deduct: [],
    });
    expect(cifAdjustments('FOB')).toEqual({ add: ['mainCarriage', 'insurance'], deduct: [] });
    expect(cifAdjustments('CFR')).toEqual({ add: ['insurance'], deduct: [] });
    expect(cifAdjustments('CIF')).toEqual({ add: [], deduct: [] });
    expect(cifAdjustments('DAP')).toEqual({ add: [], deduct: ['destinationCharges'] });
    expect(cifAdjustments('DDP')).toEqual({
      add: [],
      deduct: ['destinationCharges', 'importClearance', 'importDuties'],
    });
  });

  it('builds a bilingual responsibility matrix', () => {
    const m = responsibilityMatrix('FCA', 'es');
    expect(m.name).toBe('Franco transportista');
    expect(m.costs.originCharges).toBe('seller');
    expect(m.costs.mainCarriage).toBe('buyer');
  });
});
