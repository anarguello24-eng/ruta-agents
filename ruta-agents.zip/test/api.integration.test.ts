import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';
import { requestApproval } from '../src/core/approvals.js';
import type { AuthUser, TokenVerifier } from '../src/core/auth.js';
import { loadConfig } from '../src/core/config.js';
import type { DbHandle } from '../src/core/db/client.js';
import { freshTestDb, hasTestDb, TEST_DATABASE_URL } from './helpers/db.js';

const users: Record<string, AuthUser> = {
  staff: { id: '00000000-0000-0000-0000-000000000001', email: 'staff@ruta.test', roles: ['staff'] },
  broker: {
    id: '00000000-0000-0000-0000-000000000002',
    email: 'broker@ruta.test',
    roles: ['broker'],
  },
  ops: { id: '00000000-0000-0000-0000-000000000003', email: 'ops@ruta.test', roles: ['ops'] },
  buyer: { id: '00000000-0000-0000-0000-000000000004', email: 'buyer@ruta.test', roles: ['buyer'] },
};
const verify: TokenVerifier = async (token) => {
  const u = users[token];
  if (!u) throw new Error('bad token');
  return u;
};

describe.skipIf(!hasTestDb)('HTTP API (integration)', () => {
  let h: DbHandle;
  let app: ReturnType<typeof createApp>;
  const config = loadConfig({ DATABASE_URL: TEST_DATABASE_URL ?? 'postgres://x/y' });

  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
    app = createApp({ config, db: h, verify });
  });
  afterAll(async () => {
    await h?.close();
  });

  const call = (method: string, path: string, who?: string, json?: unknown) =>
    app.request(path, {
      method,
      headers: {
        ...(who ? { authorization: `Bearer ${who}` } : {}),
        ...(json ? { 'content-type': 'application/json' } : {}),
      },
      body: json ? JSON.stringify(json) : undefined,
    });

  it('requires a valid session for /api', async () => {
    expect((await call('GET', '/api/me')).status).toBe(401);
    expect((await call('GET', '/api/me', 'nobody')).status).toBe(401);
    expect(await (await call('GET', '/api/me', 'staff')).json()).toEqual(users.staff);
  });

  it('fails closed when auth is not configured', async () => {
    const open = createApp({ config, db: h });
    const res = await open.request('/api/me');
    expect(res.status).toBe(503);
  });

  it('customs: calculates duties from the seeded rates', async () => {
    const res = await call('POST', '/api/customs/calculate', 'broker', {
      calcDate: '2026-11-04',
      currency: 'USD',
      exchangeRate: '36.6243',
      incoterm: 'CIF',
      lines: [{ ref: '1', value: '1000', sacCode: '61091000' }],
    });
    expect(res.status).toBe(200);
    const r = (await res.json()) as { totals: { cif: string }; isEstimate: boolean };
    expect(r.totals.cif).toBe('36624.30');
    expect(r.isEstimate).toBe(true);
  });

  it('returns 400 with field paths for invalid input', async () => {
    const res = await call('POST', '/api/customs/calculate', 'staff', { calcDate: 'yesterday' });
    expect(res.status).toBe(400);
    const r = (await res.json()) as { error: string; issues: { path: string }[] };
    expect(r.error).toBe('invalid_input');
    expect(r.issues.map((i) => i.path)).toContain('calcDate');
  });

  it('customs: cross-check uses trade agreements to ask for a certificate of origin', async () => {
    const doc = {
      docType: 'commercial_invoice',
      documentNumber: '1',
      documentDate: null,
      supplier: null,
      consignee: null,
      invoiceNumber: null,
      incoterm: 'CIF',
      currency: 'USD',
      freight: 10,
      insurance: 1,
      totalAmount: 100,
      grossWeightKg: null,
      netWeightKg: null,
      packages: null,
      originCountry: 'US',
      lines: [],
    };
    const res = await call('POST', '/api/customs/cross-check', 'staff', {
      documents: [doc],
      date: '2026-11-04',
    });
    const r = (await res.json()) as { flags: { code: string }[] };
    expect(r.flags.map((f) => f.code)).toEqual([
      'MISSING_TRANSPORT_DOC',
      'MISSING_CERTIFICATE_OF_ORIGIN',
    ]);
  });

  it('trade, logistics and sourcing endpoints enforce roles', async () => {
    expect((await call('GET', '/api/trade/incoterms?lang=en', 'ops')).status).toBe(200);
    const checklist = await call('POST', '/api/trade/checklist', 'ops', {
      date: '2026-11-04',
      direction: 'export',
      partnerCountry: 'US',
      transportMode: 'sea',
      hsCode: '09011100',
    });
    expect(checklist.status).toBe(200);

    const quoteBody = {
      date: '2026-11-04',
      mode: 'air',
      origin: 'USMIA',
      destination: 'NIMGA',
      packages: [{ qty: 1, lengthCm: 40, widthCm: 30, heightCm: 30, weightKg: 12 }],
    };
    expect((await call('POST', '/api/logistics/quote', 'ops', quoteBody)).status).toBe(200);
    expect((await call('POST', '/api/logistics/quote', 'broker', quoteBody)).status).toBe(403);

    const suppliers = await call('GET', '/api/sourcing/suppliers?category=electronics', 'buyer');
    expect(((await suppliers.json()) as unknown[]).length).toBeGreaterThan(0);
    expect((await call('GET', '/api/sourcing/suppliers', 'ops')).status).toBe(403);
  });

  it('approvals: only the required role can decide', async () => {
    const a = await requestApproval(h.sql, {
      agent: 'sourcing',
      kind: 'email.send',
      title: 'RFQ to supplier',
      payload: { to: 'sales@example.test' },
      requiredRole: 'buyer',
      requestedByType: 'ai',
    });
    const pending = (await (
      await call('GET', '/api/approvals?status=pending', 'staff')
    ).json()) as { id: string }[];
    expect(pending.map((p) => p.id)).toContain(a.id);
    expect(
      (await call('POST', `/api/approvals/${a.id}/decision`, 'staff', { decision: 'approve' }))
        .status,
    ).toBe(403);
    const ok = await call('POST', `/api/approvals/${a.id}/decision`, 'buyer', {
      decision: 'approve',
    });
    expect(ok.status).toBe(200);
    expect(((await ok.json()) as { status: string }).status).toBe('approved');
    expect(
      (await call('POST', `/api/approvals/${a.id}/decision`, 'buyer', { decision: 'reject' }))
        .status,
    ).toBe(409);
  });
});
