import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { calculateDuties } from '../../src/agents/customs/calculator.js';
import { checkPermits } from '../../src/agents/customs/permits.js';
import { DbCustomsReference } from '../../src/agents/customs/rate-source.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { freshTestDb, hasTestDb } from '../helpers/db.js';

describe.skipIf(!hasTestDb)('customs reference data from Postgres (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  it('calculates with the seeded sample rates and warns that they are samples', async () => {
    const r = await calculateDuties(
      {
        calcDate: '2026-11-04',
        currency: 'USD',
        exchangeRate: '36.6243',
        incoterm: 'CIF',
        lines: [{ ref: '1', value: '1000', sacCode: '6109.10.00' }],
      },
      new DbCustomsReference(h.sql),
    );
    expect(r.lines[0]!.vat!.rate).toBe('15');
    expect(r.lines[0]!.dai!.rate).toBe('15');
    expect(r.lines[0]!.rateRefs.tariff).toMatchObject({
      effectiveFrom: '2022-01-01',
      isSample: true,
    });
    expect(r.flags.filter((f) => f.code === 'SAMPLE_RATE')).toHaveLength(2);
    expect(r.isEstimate).toBe(true);
  });

  it('finds permits by prefix in the database', async () => {
    const r = await checkPermits(new DbCustomsReference(h.sql), {
      country: 'NI',
      lang: 'es',
      lines: [{ ref: '1', sacCode: '85171300' }],
    });
    expect(r.required.map((x) => x.agency)).toEqual(['TELCOR']);
  });
});
