import { describe, expect, it } from 'vitest';
import { calculateDuties, type CalcInput } from '../../src/agents/customs/calculator.js';
import {
  MemoryCustomsReference,
  type TariffRow,
  type TaxRateRow,
} from '../../src/agents/customs/rate-source.js';

const tariff = (code: string, dai: string, opts: Partial<TariffRow> = {}): TariffRow => ({
  id: `t-${code}-${opts.effectiveFrom ?? '2020-01-01'}`,
  country: 'NI',
  code,
  descriptionEs: code,
  descriptionEn: null,
  daiRate: dai,
  iscRate: null,
  effectiveFrom: '2020-01-01',
  effectiveTo: null,
  isSample: false,
  ...opts,
});

const iva: TaxRateRow = {
  id: 'iva-15',
  country: 'NI',
  taxName: 'IVA',
  rate: '15',
  effectiveFrom: '2013-01-01',
  effectiveTo: null,
  isSample: false,
};

const refData = new MemoryCustomsReference({
  taxes: [iva],
  tariff: [
    tariff('84713000', '0'),
    tariff('61091000', '10', { effectiveTo: '2023-12-31' }),
    tariff('61091000', '15', { effectiveFrom: '2024-01-01' }),
    tariff('22030000', '15', { iscRate: '37' }),
    tariff('95045000', '15', { isSample: true }),
  ],
});

const fob: CalcInput = {
  calcDate: '2026-11-04',
  currency: 'USD',
  exchangeRate: '36.6243',
  incoterm: 'FOB',
  freight: '500',
  insurance: '50',
  lines: [
    { ref: '1', value: '10000', sacCode: '8471.30.00' },
    { ref: '2', value: '2000', sacCode: '6109.10.00' },
  ],
};

describe('calculateDuties', () => {
  it('builds CIF from FOB + prorated freight and insurance, converted at the given rate', async () => {
    const r = await calculateDuties(fob, refData);
    expect(r.complete).toBe(true);
    expect(r.isEstimate).toBe(false);
    expect(r.flags).toEqual([]);
    const [l1, l2] = r.lines;
    // 10000 × 36.6243 = 366243.00; freight 500 × 36.6243 = 18312.15 split 5:1 (largest remainder).
    expect(l1).toMatchObject({
      valueLocal: '366243.00',
      additions: { freight: '15260.13', insurance: '1526.02' },
      cif: '383029.15',
      dai: { rate: '0', amount: '0.00' },
      isc: null,
      vat: { rate: '15', base: '383029.15', amount: '57454.37' },
    });
    expect(l2).toMatchObject({
      valueLocal: '73248.60',
      additions: { freight: '3052.02', insurance: '305.20' },
      cif: '76605.82',
      dai: { rate: '15', amount: '11490.87' },
      vat: { base: '88096.69', amount: '13214.50' },
    });
    // Prorated charges add up exactly to the converted totals.
    expect(r.totals).toEqual({
      valueLocal: '439491.60',
      cif: '459634.97',
      dai: '11490.87',
      isc: '0.00',
      vat: '70668.87',
      fees: '0.00',
      totalTaxes: '82159.74',
    });
  });

  it('references the exact rate rows and effective dates used', async () => {
    const r = await calculateDuties(fob, refData);
    expect(r.lines[1]!.rateRefs).toEqual({
      tariff: {
        table: 'customs.tariff_sac',
        id: 't-61091000-2024-01-01',
        effectiveFrom: '2024-01-01',
        isSample: false,
      },
      vat: {
        table: 'customs.tax_rates',
        id: 'iva-15',
        effectiveFrom: '2013-01-01',
        isSample: false,
      },
    });
  });

  it('selects the tariff version in force on the calculation date', async () => {
    const r2023 = await calculateDuties({ ...fob, calcDate: '2023-12-31' }, refData);
    const r2024 = await calculateDuties({ ...fob, calcDate: '2024-01-01' }, refData);
    expect(r2023.lines[1]!.dai!.rate).toBe('10');
    expect(r2024.lines[1]!.dai!.rate).toBe('15');
  });

  it('applies ISC on CIF + DAI and IVA on CIF + DAI + ISC', async () => {
    const r = await calculateDuties(
      {
        calcDate: '2026-01-01',
        currency: 'NIO',
        exchangeRate: 1,
        incoterm: 'CIF',
        lines: [{ ref: 'beer', value: '10000', sacCode: '22030000' }],
      },
      refData,
    );
    expect(r.lines[0]).toMatchObject({
      cif: '10000.00',
      dai: { amount: '1500.00' },
      isc: { rate: '37', base: '11500.00', amount: '4255.00' },
      vat: { base: '15755.00', amount: '2363.25' },
      totalTaxes: '8118.25',
    });
  });

  it('rounds each tax half-up per line, and totals are sums of rounded lines', async () => {
    const r = await calculateDuties(
      {
        calcDate: '2026-01-01',
        currency: 'NIO',
        exchangeRate: 1,
        incoterm: 'CIF',
        lines: [
          { ref: 'a', value: '0.10', sacCode: '61091000' }, // DAI 0.015 -> 0.02
          { ref: 'b', value: '0.10', sacCode: '61091000' },
        ],
      },
      refData,
    );
    expect(r.lines.map((l) => l.dai!.amount)).toEqual(['0.02', '0.02']);
    expect(r.totals.dai).toBe('0.04'); // not round(0.03)
  });

  it('warns once per sample rate row and marks the result as an estimate', async () => {
    const r = await calculateDuties(
      {
        ...fob,
        lines: [
          { ref: '1', value: '100', sacCode: '95045000' },
          { ref: '2', value: '100', sacCode: '95045000' },
        ],
      },
      refData,
    );
    expect(r.flags.filter((f) => f.code === 'SAMPLE_RATE')).toHaveLength(1);
    expect(r.isEstimate).toBe(true);
    expect(r.complete).toBe(true);
  });

  it('flags missing freight and insurance for FOB-type terms', async () => {
    const r = await calculateDuties(
      { ...fob, freight: undefined, insurance: undefined, lang: 'en' },
      refData,
    );
    expect(r.complete).toBe(false);
    expect(r.flags.map((f) => [f.code, f.severity])).toEqual([
      ['MISSING_FREIGHT', 'error'],
      ['MISSING_INSURANCE', 'warning'],
    ]);
    expect(r.flags[0]!.message).toBe(
      'Freight is missing: under FOB it must be added to reach the CIF value.',
    );
  });

  it('does not add freight again when the price already includes it', async () => {
    const r = await calculateDuties({ ...fob, incoterm: 'CIF' }, refData);
    expect(r.lines[0]!.cif).toBe('366243.00');
    expect(r.flags.map((f) => f.code)).toEqual([
      'CHARGE_INCLUDED_IN_PRICE',
      'CHARGE_INCLUDED_IN_PRICE',
    ]);
    const cfr = await calculateDuties({ ...fob, incoterm: 'CFR' }, refData);
    expect(cfr.lines[0]!.additions).toMatchObject({ freight: '0.00', insurance: '1526.02' });
  });

  it('deducts post-arrival costs for D-terms and warns when they are unknown', async () => {
    const withBreakdown = await calculateDuties(
      {
        ...fob,
        incoterm: 'DAP',
        freight: undefined,
        insurance: undefined,
        destinationCharges: '120',
      },
      refData,
    );
    expect(withBreakdown.complete).toBe(true);
    expect(withBreakdown.lines[0]!.deductions.destinationCharges).toBe('3662.43');
    const without = await calculateDuties(
      { ...fob, incoterm: 'DAP', freight: undefined, insurance: undefined },
      refData,
    );
    expect(without.flags.map((f) => f.code)).toEqual(['D_TERM_VALUE_ESTIMATED']);
    expect(without.isEstimate).toBe(true);
  });

  it('reports unknown tariff codes without inventing a rate', async () => {
    const r = await calculateDuties(
      { ...fob, lines: [{ ref: 'x', value: '10', sacCode: '99999999' }] },
      refData,
    );
    expect(r.complete).toBe(false);
    expect(r.lines[0]).toMatchObject({
      dai: null,
      vat: null,
      totalTaxes: null,
      rateRefs: { tariff: null },
    });
    expect(r.flags.map((f) => f.code)).toEqual(['TARIFF_NOT_FOUND']);
  });

  it('applies declaration fees; VAT-taxable fees enter the IVA base', async () => {
    const r = await calculateDuties(
      {
        calcDate: '2026-01-01',
        currency: 'NIO',
        exchangeRate: 1,
        incoterm: 'CIF',
        lines: [{ ref: '1', value: '10000', sacCode: '84713000' }],
        fees: [
          { name: 'Servicio aduanero', kind: 'percent_of_cif', value: '0.5' },
          { name: 'Manejo', kind: 'fixed', value: '100', vatTaxable: true },
        ],
      },
      refData,
    );
    expect(r.fees.map((f) => f.amount)).toEqual(['50.00', '100.00']);
    expect(r.lines[0]!.vat).toMatchObject({ base: '10100.00', amount: '1515.00' });
    expect(r.totals).toMatchObject({ fees: '150.00', totalTaxes: '1665.00' });
  });

  it('includes other charges in CIF or only in the IVA base as configured', async () => {
    const r = await calculateDuties(
      {
        calcDate: '2026-01-01',
        currency: 'NIO',
        exchangeRate: 1,
        incoterm: 'CIF',
        otherCharges: [
          { name: 'Comisión de compra', amount: '200', inCustomsValue: true },
          { name: 'Almacenaje', amount: '300', inCustomsValue: false, vatTaxable: true },
        ],
        lines: [{ ref: '1', value: '1000', sacCode: '61091000' }],
      },
      refData,
    );
    expect(r.lines[0]).toMatchObject({
      cif: '1200.00',
      dai: { amount: '180.00' },
      vat: { base: '1680.00', amount: '252.00' },
    });
  });

  it('prorates by net weight when asked, falling back to value if weights are missing', async () => {
    const byWeight = await calculateDuties(
      {
        ...fob,
        prorateBy: 'weight',
        lines: [
          { ref: '1', value: '10000', sacCode: '84713000', netWeightKg: '10' },
          { ref: '2', value: '2000', sacCode: '61091000', netWeightKg: '30' },
        ],
      },
      refData,
    );
    expect(byWeight.lines.map((l) => l.additions.freight)).toEqual(['4578.04', '13734.11']);
    const fallback = await calculateDuties({ ...fob, prorateBy: 'weight' }, refData);
    expect(fallback.flags.map((f) => f.code)).toContain('PRORATE_FALLBACK_VALUE');
  });

  it('requires an exchange rate of 1 for local-currency invoices and rejects bad input', async () => {
    const r = await calculateDuties({ ...fob, currency: 'NIO' }, refData);
    expect(r.flags[0]!.code).toBe('FX_LOCAL_NOT_ONE');
    await expect(calculateDuties({ ...fob, exchangeRate: 0 }, refData)).rejects.toThrow();
    await expect(calculateDuties({ ...fob, lines: [] }, refData)).rejects.toThrow();
    await expect(calculateDuties({ ...fob, country: 'XX' }, refData)).rejects.toMatchObject({
      code: 'unsupported_country',
    });
  });
});
