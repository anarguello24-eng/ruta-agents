import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  CsvValidationError,
  normalizeCode,
  parseCsv,
  PermitRowSchema,
  TariffRowSchema,
  TaxRateRowSchema,
} from '../../src/agents/customs/reference/csv.js';
import { SEED_DIR } from '../helpers/db.js';

const header =
  'country,code,description_es,description_en,dai_rate,isc_rate,notes,effective_from,effective_to,is_sample,source_url';

describe('normalizeCode', () => {
  it('strips dots and spaces', () => {
    expect(normalizeCode('8471.30.00')).toBe('84713000');
    expect(normalizeCode(' 0402.21 00 ')).toBe('04022100');
  });
});

describe('parseCsv(TariffRowSchema)', () => {
  it('parses and normalizes a valid row', () => {
    const rows = parseCsv(`${header}\n,8471.30.00,Laptops,,0,,,2022-01-01,,TRUE,`, TariffRowSchema);
    expect(rows).toEqual([
      {
        country: 'NI',
        code: '84713000',
        description_es: 'Laptops',
        description_en: null,
        dai_rate: 0,
        isc_rate: null,
        notes: null,
        effective_from: '2022-01-01',
        effective_to: null,
        is_sample: true,
        source_url: null,
      },
    ]);
  });

  it('reports every invalid row with its line number', () => {
    const csv = `${header}\nNI,12,x,,5,,,2022-01-01,,false,\nNI,84713000,,,abc,,,01/01/2022,,false,`;
    try {
      parseCsv(csv, TariffRowSchema);
      expect.fail('should have thrown');
    } catch (e) {
      expect(e).toBeInstanceOf(CsvValidationError);
      const errors = (e as CsvValidationError).errors;
      expect(errors).toHaveLength(2);
      expect(errors[0]).toMatch(/^row 2: code/);
      expect(errors[1]).toMatch(/^row 3:/);
      expect(errors[1]).toMatch(/description_es/);
      expect(errors[1]).toMatch(/dai_rate/);
      expect(errors[1]).toMatch(/effective_from/);
    }
  });
});

describe('sample seed files', () => {
  const read = (f: string) => readFileSync(join(SEED_DIR, f), 'utf8');

  it('tariff seed has ~20 Nicaraguan rows, all flagged as samples', () => {
    const rows = parseCsv(read('ni_tariff_sac.sample.csv'), TariffRowSchema);
    expect(rows.length).toBeGreaterThanOrEqual(20);
    expect(rows.every((r) => r.country === 'NI' && r.is_sample)).toBe(true);
    expect(new Set(rows.map((r) => r.code)).size).toBe(rows.length);
  });

  it('tax seed contains Nicaragua IVA at 15 %', () => {
    const rows = parseCsv(read('ni_tax_rates.sample.csv'), TaxRateRowSchema);
    expect(rows).toContainEqual(
      expect.objectContaining({ country: 'NI', tax_name: 'IVA', rate: 15, is_sample: true }),
    );
  });

  it('permit seed rows are samples', () => {
    const rows = parseCsv(read('ni_permits.sample.csv'), PermitRowSchema);
    expect(rows.length).toBeGreaterThan(0);
    expect(rows.every((r) => r.is_sample)).toBe(true);
  });
});
