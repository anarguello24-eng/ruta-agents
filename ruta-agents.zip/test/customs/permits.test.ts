import { describe, expect, it } from 'vitest';
import { checkPermits } from '../../src/agents/customs/permits.js';
import { MemoryCustomsReference, type PermitRow } from '../../src/agents/customs/rate-source.js';

const p = (sacPrefix: string, agency: string, permitName: string, isSample = false): PermitRow => ({
  id: `${sacPrefix}-${agency}`,
  country: 'NI',
  sacPrefix,
  agency,
  permitName,
  notes: null,
  isSample,
});

const refData = new MemoryCustomsReference({
  permits: [
    p('30', 'MINSA', 'Registro sanitario'),
    p('851713', 'TELCOR', 'Homologación'),
    p('8517', 'MIFIC', 'Ejemplo genérico', true),
  ],
});

describe('checkPermits', () => {
  it('matches permits by tariff-code prefix, most specific first', async () => {
    const r = await checkPermits(refData, {
      country: 'NI',
      lang: 'es',
      lines: [
        { ref: '1', sacCode: '85171300' },
        { ref: '2', sacCode: '30049000' },
        { ref: '3', sacCode: '84713000' },
      ],
    });
    expect(r.lines[0]!.permits.map((x) => x.agency)).toEqual(['TELCOR', 'MIFIC']);
    expect(r.lines[2]!.permits).toEqual([]);
    expect(r.required.map((x) => [x.agency, x.lineRefs])).toEqual([
      ['TELCOR', ['1']],
      ['MIFIC', ['1']],
      ['MINSA', ['2']],
    ]);
  });

  it('reports permits the client has not provided and warns about sample data', async () => {
    const r = await checkPermits(refData, {
      country: 'NI',
      lang: 'en',
      lines: [
        { ref: '1', sacCode: '85171300' },
        { ref: '2', sacCode: '30049000' },
      ],
      provided: [{ agency: 'minsa' }, { agency: 'TELCOR', permitName: 'homologación' }],
    });
    expect(r.missing).toEqual([
      { agency: 'MIFIC', permitName: 'Ejemplo genérico', lineRefs: ['1'] },
    ]);
    expect(r.flags.map((f) => f.code)).toEqual(['PERMIT_MISSING', 'SAMPLE_PERMIT_DATA']);
  });
});
