import { describe, expect, it } from 'vitest';
import { crossCheck, nameSimilarity, normalizeParty } from '../../src/agents/customs/crosscheck.js';
import type { ExtractedDocument } from '../../src/agents/customs/extraction-schema.js';

const doc = (over: Partial<ExtractedDocument>): ExtractedDocument => ({
  docType: 'commercial_invoice',
  documentNumber: null,
  documentDate: null,
  supplier: null,
  consignee: null,
  invoiceNumber: null,
  incoterm: null,
  currency: null,
  freight: null,
  insurance: null,
  totalAmount: null,
  grossWeightKg: null,
  netWeightKg: null,
  packages: null,
  originCountry: null,
  lines: [],
  ...over,
});

const line = (qty: number, price: number, total: number, origin: string | null = 'CN') => ({
  description: 'item',
  quantity: qty,
  unit: 'PCS',
  unitPrice: price,
  total,
  grossWeightKg: null,
  netWeightKg: null,
  originCountry: origin,
});

const consignee = (name: string) => ({ name, address: null, taxId: null });

const clean = [
  doc({
    documentNumber: 'INV-001',
    incoterm: 'FOB',
    currency: 'USD',
    freight: 500,
    totalAmount: 1500,
    grossWeightKg: 120,
    netWeightKg: 100,
    consignee: consignee('Importadora Ruta, S.A.'),
    lines: [line(10, 100, 1000), line(5, 100, 500)],
  }),
  doc({
    docType: 'packing_list',
    invoiceNumber: 'INV 001',
    grossWeightKg: 120.4,
    netWeightKg: 100,
    consignee: consignee('IMPORTADORA RUTA SA'),
  }),
  doc({ docType: 'bill_of_lading', grossWeightKg: 120, consignee: consignee('Importadora Ruta') }),
];

const codes = (flags: { code: string }[]) => flags.map((f) => f.code);

describe('crossCheck', () => {
  it('passes a consistent document set', () => {
    expect(crossCheck(clean, { lang: 'es' })).toEqual([]);
  });

  it('flags missing invoice and transport document', () => {
    expect(codes(crossCheck([doc({ docType: 'packing_list' })], { lang: 'es' }))).toEqual([
      'MISSING_INVOICE',
      'MISSING_TRANSPORT_DOC',
    ]);
  });

  it('flags invoice total vs sum of lines, but accepts totals that include freight/insurance', () => {
    const bad = [{ ...clean[0]!, totalAmount: 1600, freight: null }, ...clean.slice(1)];
    expect(codes(crossCheck(bad, { lang: 'es' }))).toContain('INVOICE_TOTAL_MISMATCH');
    const withFreight = [{ ...clean[0]!, totalAmount: 2000, freight: 500 }, ...clean.slice(1)];
    expect(codes(crossCheck(withFreight, { lang: 'es' }))).not.toContain('INVOICE_TOTAL_MISMATCH');
  });

  it('flags line arithmetic errors', () => {
    const bad = [
      { ...clean[0]!, lines: [line(10, 100, 1100), line(5, 100, 500)], totalAmount: 1600 },
    ];
    expect(codes(crossCheck(bad, { lang: 'en' }))).toContain('LINE_TOTAL_MISMATCH');
  });

  it('flags gross weight differences beyond tolerance and net > gross', () => {
    const bad = [clean[0]!, clean[1]!, { ...clean[2]!, grossWeightKg: 150 }];
    const flags = crossCheck(bad, { lang: 'en' });
    expect(codes(flags).filter((c) => c === 'WEIGHT_MISMATCH')).toHaveLength(2);
    expect(flags.find((f) => f.code === 'WEIGHT_MISMATCH')!.message).toContain('150');
    const netGross = [{ ...clean[0]!, netWeightKg: 130 }, ...clean.slice(1)];
    expect(codes(crossCheck(netGross, { lang: 'es' }))).toContain('NET_EXCEEDS_GROSS');
  });

  it('matches consignee names ignoring case, accents and legal suffixes', () => {
    expect(normalizeParty('Importadora Rúta, S.A. de C.V.')).toBe('importadora ruta');
    expect(nameSimilarity('ACME Corp.', 'Acme')).toBe(1);
    const bad = [
      clean[0]!,
      clean[1]!,
      { ...clean[2]!, consignee: consignee('Distribuidora Otro Nombre') },
    ];
    expect(codes(crossCheck(bad, { lang: 'es' }))).toEqual(['CONSIGNEE_MISMATCH']);
  });

  it('asks for the certificate of origin when the origin may get a preference', () => {
    const us = [
      { ...clean[0]!, lines: [line(10, 100, 1000, 'US'), line(5, 100, 500, 'CN')] },
      ...clean.slice(1),
    ];
    const flags = crossCheck(us, { lang: 'en', preferentialOrigins: ['US', 'CR'] });
    expect(codes(flags)).toEqual(['MISSING_CERTIFICATE_OF_ORIGIN']);
    expect(flags[0]!.message).toContain('US');
    const withCoo = [...us, doc({ docType: 'certificate_of_origin', invoiceNumber: 'INV-001' })];
    expect(crossCheck(withCoo, { lang: 'en', preferentialOrigins: ['US'] })).toEqual([]);
  });

  it('checks freight/insurance breakdown for CIF and freight availability for FOB', () => {
    const cif = [
      { ...clean[0]!, incoterm: 'cif', freight: null, totalAmount: 1500 },
      ...clean.slice(1),
    ];
    expect(codes(crossCheck(cif, { lang: 'es' }))).toEqual([
      'MISSING_FREIGHT_FOR_CIF',
      'MISSING_INSURANCE_FOR_CIF',
    ]);
    const fob = [{ ...clean[0]!, freight: null }, ...clean.slice(1)];
    expect(codes(crossCheck(fob, { lang: 'es' }))).toEqual(['FREIGHT_NEEDED']);
    const fobBl = [fob[0]!, fob[1]!, { ...clean[2]!, freight: 450 }];
    expect(crossCheck(fobBl, { lang: 'es' })).toEqual([]);
  });

  it('flags currency and invoice-reference mismatches', () => {
    const bad = [clean[0]!, { ...clean[1]!, invoiceNumber: 'INV-002', currency: 'EUR' }, clean[2]!];
    expect(codes(crossCheck(bad, { lang: 'es' }))).toEqual([
      'CURRENCY_MISMATCH',
      'INVOICE_REFERENCE_MISMATCH',
    ]);
  });

  it('flags a missing or invalid Incoterm', () => {
    const bad = [{ ...clean[0]!, incoterm: 'DDU' }, ...clean.slice(1)];
    expect(codes(crossCheck(bad, { lang: 'es' }))).toEqual(['MISSING_INCOTERM']);
  });
});
