import { getTableConfig, type PgTable } from 'drizzle-orm/pg-core';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { DbHandle } from '../../src/core/db/client.js';
import { runMigrations } from '../../src/core/db/migrate.js';
import * as schema from '../../src/agents/customs/schema.js';
import { freshTestDb, hasTestDb, MIGRATIONS_DIR } from '../helpers/db.js';

const tables: PgTable[] = [
  schema.cases,
  schema.documents,
  schema.lines,
  schema.auditLog,
  schema.tariffSac,
  schema.taxRates,
  schema.permits,
  schema.lineClassifications,
  schema.calculations,
  schema.classificationHistory,
];

describe.skipIf(!hasTestDb)('database (integration)', () => {
  let h: DbHandle;

  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  it('migrations are idempotent', async () => {
    expect(await runMigrations(h.sql, MIGRATIONS_DIR)).toEqual([]);
  });

  it('drizzle schema matches the migrated tables', async () => {
    const [count] = await h.sql<{ n: number }[]>`
      SELECT count(*)::int AS n FROM information_schema.tables WHERE table_schema = 'customs'`;
    expect(tables.length).toBe(count!.n);
    for (const t of tables) {
      const cfg = getTableConfig(t);
      const rows = await h.sql<{ column_name: string }[]>`
        SELECT column_name FROM information_schema.columns
        WHERE table_schema = ${cfg.schema ?? 'public'} AND table_name = ${cfg.name}`;
      const dbCols = rows.map((r) => r.column_name).sort();
      const ormCols = cfg.columns.map((c) => c.name).sort();
      expect({ table: cfg.name, cols: ormCols }).toEqual({ table: cfg.name, cols: dbCols });
    }
  });

  it('seeds sample reference data for Nicaragua', async () => {
    const [t] = await h.sql<{ n: number; samples: number }[]>`
      SELECT count(*)::int AS n, count(*) FILTER (WHERE is_sample)::int AS samples
      FROM customs.tariff_sac WHERE country = 'NI'`;
    expect(t!.n).toBeGreaterThanOrEqual(20);
    expect(t!.samples).toBe(t!.n);

    const [iva] = await h.sql<{ rate: string; is_sample: boolean }[]>`
      SELECT rate, is_sample FROM customs.tax_rates WHERE country = 'NI' AND tax_name = 'IVA'`;
    expect(Number(iva!.rate)).toBe(15);
    expect(iva!.is_sample).toBe(true);
  });

  it('builds a keyword search vector for tariff rows', async () => {
    const rows = await h.sql<{ code: string }[]>`
      SELECT code FROM customs.tariff_sac
      WHERE search_tsv @@ plainto_tsquery('spanish', 'refrigeradores')`;
    expect(rows.map((r) => r.code)).toContain('84182100');
  });

  it('rejects an approved line without a tariff code and broker', async () => {
    const [c] = await h.sql<
      { id: string }[]
    >`INSERT INTO customs.cases DEFAULT VALUES RETURNING id`;
    await expect(
      h.sql`INSERT INTO customs.lines (case_id, line_no, description, status)
            VALUES (${c!.id}, 1, 'Laptop', 'approved')`,
    ).rejects.toThrow(/lines_approved_requires_code/);
  });

  it('rejects a filed case without a DUCA number', async () => {
    await expect(
      h.sql`INSERT INTO customs.cases (status, approved_by)
            VALUES ('filed', gen_random_uuid())`,
    ).rejects.toThrow(/cases_filed_requires_duca/);
  });

  it('requires prompt version, model and input hash on AI audit entries', async () => {
    await expect(
      h.sql`INSERT INTO customs.audit_log (entity_type, actor_type, action)
            VALUES ('line', 'ai', 'classify')`,
    ).rejects.toThrow(/audit_ai_fields/);
  });

  it('keeps the audit log append-only', async () => {
    const [row] = await h.sql<{ id: number }[]>`
      INSERT INTO customs.audit_log (entity_type, actor_type, actor_id, action)
      VALUES ('case', 'user', 'u1', 'create') RETURNING id`;
    await expect(
      h.sql`UPDATE customs.audit_log SET action = 'x' WHERE id = ${row!.id}`,
    ).rejects.toThrow(/append-only/);
    await expect(h.sql`DELETE FROM customs.audit_log WHERE id = ${row!.id}`).rejects.toThrow(
      /append-only/,
    );
  });
});
