import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { classifyProduct } from '../../src/agents/customs/ai/classify.js';
import { extractDocuments, toKg } from '../../src/agents/customs/ai/extract.js';
import { embedMissingTariffRows, searchTariff } from '../../src/agents/customs/tariff-search.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { FakeLLMProvider } from '../../src/core/llm/fake.js';
import { freshTestDb, hasTestDb } from '../helpers/db.js';

const invoice = {
  docType: 'commercial_invoice',
  documentNumber: 'INV-77',
  documentDate: '2026-10-20',
  supplier: { name: 'Shenzhen Co', address: null, taxId: null },
  consignee: { name: 'Importadora Ruta S.A.', address: null, taxId: null },
  invoiceNumber: null,
  incoterm: 'FOB',
  currency: 'usd',
  freight: null,
  insurance: null,
  totalAmount: 3000,
  grossWeight: { value: 220.5, unit: 'lb' },
  netWeight: { value: 90, unit: 'kg' },
  packages: 4,
  originCountry: 'CN',
  lines: [
    {
      description: 'Laptop 14" i5 8GB',
      quantity: 10,
      unit: 'PCS',
      unitPrice: 300,
      total: 3000,
      grossWeight: null,
      netWeight: null,
      originCountry: 'CN',
    },
  ],
  warnings: ['Stamp partially covers the date'],
};

describe('unit conversions', () => {
  it('converts printed weights to kg in code, not in the model', () => {
    expect(toKg({ value: 220.5, unit: 'lb' })).toBe(100.017);
    expect(toKg({ value: 1.2, unit: 't' })).toBe(1200);
    expect(toKg(null)).toBeNull();
  });
});

describe.skipIf(!hasTestDb)('customs AI (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  const deps = (provider: FakeLLMProvider) => ({ provider, sql: h.sql, timeoutMs: 5000 });

  it('extracts a document, normalizes it, cross-checks, and audits the AI call', async () => {
    const provider = new FakeLLMProvider([invoice]);
    const file = {
      name: 'invoice.pdf',
      mimeType: 'application/pdf',
      data: new TextEncoder().encode('%PDF-1.7'),
    };
    const r = await extractDocuments(deps(provider), { files: [file], lang: 'es' });

    expect(provider.calls[0]!.purpose).toBe('vision');
    expect(provider.calls[0]!.files).toEqual([file]);
    expect(provider.calls[0]!.messages[1]!.content).toContain('<untrusted_file_name>');

    const doc = r.documents[0]!.document;
    expect(doc).toMatchObject({ currency: 'USD', grossWeightKg: 100.017, netWeightKg: 90 });
    expect(r.documents[0]!.warnings).toEqual(['Stamp partially covers the date']);
    expect(r.flags.map((f) => f.code)).toEqual(['MISSING_TRANSPORT_DOC', 'FREIGHT_NEEDED']);

    const [audit] = await h.sql<{ prompt_version: string; model: string; actor_type: string }[]>`
      SELECT prompt_version, model, actor_type FROM customs.audit_log WHERE id = ${r.documents[0]!.auditId}`;
    expect(audit).toEqual({
      prompt_version: 'customs.extract_document@1',
      model: 'fake-model',
      actor_type: 'ai',
    });
  });

  it('finds tariff candidates by keywords, code prefix and (after backfill) embeddings', async () => {
    const kw = await searchTariff(h.sql, {
      country: 'NI',
      text: 'refrigerador doméstico',
      date: '2026-11-04',
    });
    expect(kw[0]!.code).toBe('84182100');
    const byCode = await searchTariff(h.sql, {
      country: 'NI',
      text: 'partida 8471.30',
      date: '2026-11-04',
    });
    expect(byCode[0]).toMatchObject({
      code: '84713000',
      matchedBy: expect.arrayContaining(['code']),
    });
    expect(
      await searchTariff(h.sql, { country: 'NI', text: 'laptop', date: '2021-12-31' }),
    ).toEqual([]);

    const provider = new FakeLLMProvider();
    expect(await embedMissingTariffRows(h.sql, provider)).toBe(23);
    expect(await embedMissingTariffRows(h.sql, provider)).toBe(0);
    const [q] = await provider.embed(['camisetas de algodón'], { kind: 'query' });
    const sem = await searchTariff(h.sql, {
      country: 'NI',
      text: 'camisetas de algodón',
      date: '2026-11-04',
      queryEmbedding: q,
    });
    expect(sem[0]!.code).toBe('61091000');
    expect(sem[0]!.matchedBy).toContain('semantic');
  });

  it('classifies only among searched candidates and attaches rates from the table', async () => {
    const provider = new FakeLLMProvider([
      (req) => {
        const user = req.messages[1]!.content;
        expect(user).toContain('<untrusted_product_description>');
        expect(user).toContain('61091000');
        return {
          candidates: [
            { code: '62034200', gri: ['GRI1'], reasoning: 'No: son pantalones', confidence: 5 },
            {
              code: '61091000',
              gri: ['GRI1', 'GRI6'],
              reasoning: 'Camiseta de punto de algodón',
              confidence: 92,
            },
          ],
          needsMoreInfo: null,
        };
      },
    ]);
    const r = await classifyProduct(deps(provider), {
      country: 'NI',
      lang: 'es',
      date: '2026-11-04',
      description: 'Camisetas de algodón tejidas de punto para hombre',
    });
    expect(r.suggestions.map((s) => [s.rank, s.code, s.confidence, s.daiRate])).toEqual([
      [1, '61091000', 92, '15.0000'],
      [2, '62034200', 5, '15.0000'],
    ]);
    expect(provider.calls[0]!.effort).toBe('high');
    expect(r.flags.map((f) => f.code)).toEqual(['SAMPLE_TARIFF']);
  });

  it('rejects invented codes: retries once, then fails visibly', async () => {
    const invented = {
      candidates: [{ code: '99999999', gri: ['GRI1'], reasoning: 'x', confidence: 99 }],
      needsMoreInfo: null,
    };
    const provider = new FakeLLMProvider([invented, invented]);
    await expect(
      classifyProduct(deps(provider), {
        country: 'NI',
        lang: 'en',
        date: '2026-11-04',
        description: 'cotton t-shirts',
      }),
    ).rejects.toMatchObject({ code: 'ai_invalid_output' });
    expect(provider.calls[1]!.messages.at(-1)!.content).toMatch(/rejected: candidates\.0\.code/);
  });

  it('falls back to keyword search without embeddings, and skips the model when nothing matches', async () => {
    const provider = new FakeLLMProvider([]);
    provider.embed = async () => {
      throw new Error('VOYAGE_API_KEY not set');
    };
    const r = await classifyProduct(deps(provider), {
      country: 'NI',
      lang: 'en',
      date: '2026-11-04',
      description: 'zzqx',
    });
    expect(r.suggestions).toEqual([]);
    expect(r.flags.map((f) => f.code)).toEqual(['SEMANTIC_SEARCH_OFF', 'NO_TARIFF_CANDIDATES']);
    expect(provider.calls).toHaveLength(0);
  });
});
