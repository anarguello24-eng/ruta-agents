import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../src/app.js';
import type { AuthUser, TokenVerifier } from '../../src/core/auth.js';
import { loadConfig } from '../../src/core/config.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { loadFiles } from '../../src/core/files.js';
import { FakeLLMProvider } from '../../src/core/llm/fake.js';
import { freshTestDb, hasTestDb, TEST_DATABASE_URL } from '../helpers/db.js';

const users: Record<string, AuthUser> = {
  broker: {
    id: '00000000-0000-0000-0000-000000000002',
    email: 'broker@ruta.test',
    roles: ['broker'],
  },
  buyer: { id: '00000000-0000-0000-0000-000000000004', email: 'ana@ruta.test', roles: ['buyer'] },
  staff: { id: '00000000-0000-0000-0000-000000000001', email: 'staff@ruta.test', roles: ['staff'] },
};
const verify: TokenVerifier = async (t) => {
  if (!users[t]) throw new Error('bad token');
  return users[t]!;
};

describe('loadFiles', () => {
  const pdf = Buffer.from('%PDF-1.7').toString('base64');
  it('accepts base64 and allow-listed signed URLs only', async () => {
    const f = await loadFiles([{ name: 'a.pdf', mimeType: 'application/pdf', base64: pdf }], {
      allowedHosts: [],
    });
    expect(Buffer.from(f[0]!.data).toString()).toBe('%PDF-1.7');

    const fakeFetch = (async () =>
      new Response('%PDF', { status: 200 })) as unknown as typeof fetch;
    const ok = await loadFiles(
      [
        {
          name: 'b.pdf',
          mimeType: 'application/pdf',
          url: 'https://proj.supabase.co/storage/v1/object/sign/docs/b.pdf?token=x',
        },
      ],
      { allowedHosts: ['proj.supabase.co'], fetch: fakeFetch },
    );
    expect(ok).toHaveLength(1);
    for (const url of [
      'http://proj.supabase.co/x',
      'https://169.254.169.254/latest',
      'https://evil.test/x',
    ])
      await expect(
        loadFiles([{ name: 'c', mimeType: 'application/pdf', url }], {
          allowedHosts: ['proj.supabase.co'],
          fetch: fakeFetch,
        }),
      ).rejects.toMatchObject({ code: 'file_url_not_allowed' });
  });
});

describe.skipIf(!hasTestDb)('AI HTTP API (integration)', () => {
  let h: DbHandle;
  const config = loadConfig({
    DATABASE_URL: TEST_DATABASE_URL ?? 'postgres://x/y',
    SUPABASE_URL: 'https://proj.supabase.co',
  });
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  const call = (app: ReturnType<typeof createApp>, path: string, who: string, json: unknown) =>
    app.request(path, {
      method: 'POST',
      headers: { authorization: `Bearer ${who}`, 'content-type': 'application/json' },
      body: JSON.stringify(json),
    });

  it('returns 503 when no Anthropic key is configured', async () => {
    const app = createApp({ config, db: h, verify, provider: null });
    const res = await call(app, '/api/ai/customs/classify', 'broker', { description: 'laptop' });
    expect(res.status).toBe(503);
    expect(((await res.json()) as { error: string }).error).toBe('ai_not_configured');
  });

  it('classifies a product description', async () => {
    const provider = new FakeLLMProvider([
      {
        candidates: [{ code: '84713000', gri: ['GRI1'], reasoning: 'Portátil', confidence: 88 }],
        needsMoreInfo: null,
      },
    ]);
    const app = createApp({ config, db: h, verify, provider });
    const res = await call(app, '/api/ai/customs/classify', 'broker', {
      description: 'Laptop portátil 14 pulgadas, máquina automática para procesamiento de datos',
    });
    expect(res.status).toBe(200);
    const r = (await res.json()) as { suggestions: { code: string; confidence: number }[] };
    expect(r.suggestions[0]).toMatchObject({ code: '84713000', confidence: 88 });
  });

  it('only buyers can draft RFQ emails, and the draft lands in the approvals inbox', async () => {
    const [sup] = await h.sql<
      { id: string }[]
    >`SELECT id FROM sourcing.suppliers WHERE code = 'SUP-US-01'`;
    const provider = new FakeLLMProvider([
      { subject: 'Request for quotation', body: 'Dear Maria, please quote...' },
    ]);
    const app = createApp({ config, db: h, verify, provider });
    const payload = {
      rfqRef: 'RFQ-2026-0050',
      supplierId: sup!.id,
      replyBy: '2026-11-20',
      items: [{ ref: 'ITEM-1', description: 'Tires 205/55R16', quantity: 40, unit: 'pcs' }],
    };
    expect((await call(app, '/api/ai/sourcing/draft-rfq', 'staff', payload)).status).toBe(403);
    const res = await call(app, '/api/ai/sourcing/draft-rfq', 'buyer', payload);
    expect(res.status).toBe(201);
    const r = (await res.json()) as { approval: { id: string; status: string } };
    expect(r.approval.status).toBe('pending');
    const inbox = await app.request('/api/approvals?status=pending&agent=sourcing', {
      headers: { authorization: 'Bearer buyer' },
    });
    expect(((await inbox.json()) as { id: string }[]).map((a) => a.id)).toContain(r.approval.id);
  });

  it('rejects file URLs outside Supabase Storage', async () => {
    const app = createApp({ config, db: h, verify, provider: new FakeLLMProvider() });
    const res = await call(app, '/api/ai/customs/extract', 'broker', {
      files: [{ name: 'x.pdf', mimeType: 'application/pdf', url: 'https://evil.test/x.pdf' }],
    });
    expect(res.status).toBe(400);
  });
});
