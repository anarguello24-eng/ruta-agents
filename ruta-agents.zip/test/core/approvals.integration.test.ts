import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  decideApproval,
  listApprovals,
  markExecuted,
  requestApproval,
} from '../../src/core/approvals.js';
import type { AuthUser } from '../../src/core/auth.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { freshTestDb, hasTestDb } from '../helpers/db.js';

const broker: AuthUser = {
  id: '22222222-2222-2222-2222-222222222222',
  email: null,
  roles: ['broker'],
};
const staff: AuthUser = {
  id: '33333333-3333-3333-3333-333333333333',
  email: null,
  roles: ['staff'],
};

describe.skipIf(!hasTestDb)('approvals (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb();
  });
  afterAll(async () => {
    await h?.close();
  });

  const queue = () =>
    requestApproval(h.sql, {
      agent: 'customs',
      kind: 'email.send',
      title: 'Send draft to client',
      payload: { to: 'client@example.com', body: 'Hola' },
      requiredRole: 'broker',
      requestedByType: 'ai',
      requestedBy: 'customs-agent',
    });

  it('queues, approves with edits, and executes, auditing every step', async () => {
    const a = await queue();
    expect(a.status).toBe('pending');
    expect((await listApprovals(h.sql, { status: 'pending' })).map((x) => x.id)).toContain(a.id);

    const decided = await decideApproval(h.sql, {
      id: a.id,
      user: broker,
      decision: 'approve',
      editedPayload: { to: 'client@example.com', body: 'Hola, saludos' },
    });
    expect(decided).toMatchObject({ status: 'approved', decidedBy: broker.id });
    expect(decided.payload).toEqual({ to: 'client@example.com', body: 'Hola, saludos' });

    const done = await markExecuted(h.sql, a.id, { ok: true, result: { messageId: 'm1' } });
    expect(done.status).toBe('executed');

    const audit = await h.sql<{ action: string; actor_type: string }[]>`
      SELECT action, actor_type FROM customs.audit_log WHERE entity_id = ${a.id} ORDER BY id`;
    expect(audit).toEqual([
      { action: 'approval.requested:email.send', actor_type: 'system' },
      { action: 'approval.approved:email.send', actor_type: 'user' },
      { action: 'approval.executed:email.send', actor_type: 'system' },
    ]);
  });

  it('enforces the required role and single decision', async () => {
    const a = await queue();
    await expect(
      decideApproval(h.sql, { id: a.id, user: staff, decision: 'approve' }),
    ).rejects.toMatchObject({
      status: 403,
    });
    await decideApproval(h.sql, { id: a.id, user: broker, decision: 'reject', note: 'tone' });
    await expect(
      decideApproval(h.sql, { id: a.id, user: broker, decision: 'approve' }),
    ).rejects.toMatchObject({
      status: 409,
    });
    await expect(markExecuted(h.sql, a.id, { ok: true })).rejects.toMatchObject({ status: 409 });
  });
});
