import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createApp } from '../../src/app.js';
import { loadConfig } from '../../src/core/config.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { freshTestDb, hasTestDb, TEST_DATABASE_URL } from '../helpers/db.js';

const config = loadConfig({ DATABASE_URL: TEST_DATABASE_URL ?? 'postgres://localhost/unused' });

describe('GET /health', () => {
  it('reports degraded (503) when the database is unreachable', async () => {
    const failingSql = (() => Promise.reject(new Error('connection refused'))) as never;
    const app = createApp({
      config,
      db: { db: {} as never, sql: failingSql, close: async () => {} },
    });
    const res = await app.request('/health');
    expect(res.status).toBe(503);
    expect(await res.json()).toMatchObject({ status: 'degraded', db: { status: 'error' } });
  });

  it('returns 404 JSON for unknown routes', async () => {
    const app = createApp({
      config,
      db: { db: {} as never, sql: {} as never, close: async () => {} },
    });
    const res = await app.request('/nope');
    expect(res.status).toBe(404);
    expect(await res.json()).toEqual({ error: 'not_found' });
  });
});

describe.skipIf(!hasTestDb)('GET /health (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  it('returns ok with reference-data counts', async () => {
    const app = createApp({ config, db: h });
    const res = await app.request('/health');
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      referenceData: { tariffRows: number; sampleTariffRows: number };
    };
    expect(body).toMatchObject({ status: 'ok', country: 'NI', db: { status: 'ok' } });
    expect(body.referenceData.tariffRows).toBeGreaterThanOrEqual(20);
    expect(body.referenceData.sampleTariffRows).toBe(body.referenceData.tariffRows);
  });
});
