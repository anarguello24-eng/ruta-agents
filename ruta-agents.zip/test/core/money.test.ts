import { describe, expect, it } from 'vitest';
import { allocate, D, money, pct, round, roundUp, sum } from '../../src/core/money.js';

describe('money', () => {
  it('rounds half-up, including the float trap 1.005', () => {
    expect(money('1.005')).toBe('1.01');
    expect(money('2.675')).toBe('2.68');
    expect(money('-1.005')).toBe('-1.01');
    expect(round('0.125', 2).toString()).toBe('0.13');
  });

  it('avoids binary float error', () => {
    expect(sum(['0.1', '0.2']).toString()).toBe('0.3');
    expect(pct('1000', '15').toString()).toBe('150');
  });

  it('rounds chargeable weight up', () => {
    expect(roundUp('10.01', 0).toString()).toBe('11');
    expect(roundUp('10.5', 1).toString()).toBe('10.5');
  });

  it('allocates so the parts add up exactly to the total', () => {
    const parts = allocate('100.00', [1, 1, 1]);
    expect(parts.map((p) => p.toFixed(2))).toEqual(['33.34', '33.33', '33.33']);
    expect(sum(parts).toFixed(2)).toBe('100.00');
  });

  it('allocates proportionally to weights', () => {
    const parts = allocate('250', ['1000', '3000', '1000']);
    expect(parts.map((p) => p.toFixed(2))).toEqual(['50.00', '150.00', '50.00']);
  });

  it('splits equally when all weights are zero, and handles empty input', () => {
    expect(allocate('10', [0, 0]).map((p) => p.toFixed(2))).toEqual(['5.00', '5.00']);
    expect(allocate('10', [])).toEqual([]);
  });

  it('D accepts strings and numbers', () => {
    expect(D(3).plus('0.5').toString()).toBe('3.5');
  });
});
