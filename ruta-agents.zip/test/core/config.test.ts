import { describe, expect, it } from 'vitest';
import { loadConfig } from '../../src/core/config.js';

describe('loadConfig', () => {
  it('applies defaults', () => {
    const c = loadConfig({ DATABASE_URL: 'postgres://u:p@localhost:5432/db' });
    expect(c.PORT).toBe(8787);
    expect(c.DEFAULT_COUNTRY).toBe('NI');
    expect(c.LLM_PROVIDER).toBe('anthropic');
    expect(c.LLM_MODEL).toBe('claude-opus-5-5');
    expect(c.LLM_EFFORT).toBe('medium');
    expect(c.DATABASE_SSL).toBe(false);
    expect(c.EMBEDDING_DIMENSIONS).toBe(1024);
  });

  it('fails with a readable message when DATABASE_URL is missing', () => {
    expect(() => loadConfig({})).toThrow(/DATABASE_URL/);
  });

  it('rejects unknown LLM providers', () => {
    expect(() =>
      loadConfig({ DATABASE_URL: 'postgres://localhost/db', LLM_PROVIDER: 'other' }),
    ).toThrow(/LLM_PROVIDER/);
  });
});
