import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import type { AuditEntry } from '../../src/core/audit.js';
import { hashInput, stableStringify } from '../../src/core/audit.js';
import { FakeLLMProvider } from '../../src/core/llm/fake.js';
import { AiOutputError, generateValidated, parseJsonReply } from '../../src/core/llm/generate.js';

const Schema = z.object({
  code: z.string().regex(/^\d{8}$/),
  confidence: z.number().int().min(0).max(100),
});

function sink() {
  const entries: AuditEntry[] = [];
  return { entries, audit: async (e: AuditEntry) => entries.push(e) };
}

const base = {
  schema: Schema,
  schemaName: 'classification',
  prompt: { id: 'test.classify', version: '1' },
  messages: [{ role: 'user' as const, content: 'classify: laptop' }],
  auditContext: { entityType: 'line', entityId: 'l1', action: 'classify' },
};

describe('parseJsonReply', () => {
  it('handles fences and prose', () => {
    expect(parseJsonReply('```json\n{"a":1}\n```')).toEqual({ a: 1 });
    expect(parseJsonReply('Here you go: {"a":2} thanks')).toEqual({ a: 2 });
    expect(() => parseJsonReply('nope')).toThrow();
  });
});

describe('generateValidated', () => {
  it('returns validated data and audits the call with prompt version, model and input hash', async () => {
    const { entries, audit } = sink();
    const provider = new FakeLLMProvider([{ code: '84713000', confidence: 90 }]);
    const r = await generateValidated({ ...base, provider, audit });
    expect(r.data).toEqual({ code: '84713000', confidence: 90 });
    expect(r.attempts).toBe(1);
    expect(entries).toHaveLength(1);
    expect(entries[0]).toMatchObject({
      actorType: 'ai',
      promptVersion: 'test.classify@1',
      model: 'fake-model',
      entityType: 'line',
      validatedOutput: { code: '84713000', confidence: 90 },
    });
    expect(entries[0]!.inputHash).toMatch(/^[0-9a-f]{64}$/);
    // The JSON schema is passed to the provider.
    expect(provider.calls[0]!.jsonSchema).toMatchObject({ type: 'object' });
  });

  it('retries once with the validation error, then succeeds', async () => {
    const { entries, audit } = sink();
    const provider = new FakeLLMProvider([
      { code: '8471.30', confidence: 90 },
      { code: '84713000', confidence: 90 },
    ]);
    const r = await generateValidated({ ...base, provider, audit });
    expect(r.attempts).toBe(2);
    const retryMsg = provider.calls[1]!.messages.at(-1)!.content;
    expect(retryMsg).toMatch(/rejected: code/);
    expect(entries.map((e) => Boolean(e.error))).toEqual([true, false]);
  });

  it('fails visibly after two invalid outputs', async () => {
    const { entries, audit } = sink();
    const provider = new FakeLLMProvider(['not json', { code: 'x', confidence: 500 }]);
    await expect(generateValidated({ ...base, provider, audit })).rejects.toBeInstanceOf(
      AiOutputError,
    );
    expect(entries).toHaveLength(2);
    expect(entries.every((e) => e.error)).toBe(true);
  });

  it('treats provider errors like invalid output', async () => {
    const { audit } = sink();
    const provider = new FakeLLMProvider([
      () => {
        throw new Error('rate limited');
      },
      { code: '84713000', confidence: 1 },
    ]);
    const r = await generateValidated({ ...base, provider, audit });
    expect(r.attempts).toBe(2);
  });
});

describe('hashInput', () => {
  it('is independent of key order', () => {
    expect(stableStringify({ b: 1, a: [1, { d: 2, c: 3 }] })).toBe('{"a":[1,{"c":3,"d":2}],"b":1}');
    expect(hashInput({ a: 1, b: 2 })).toBe(hashInput({ b: 2, a: 1 }));
  });
});
