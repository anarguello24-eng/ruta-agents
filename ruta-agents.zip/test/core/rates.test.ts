import { describe, expect, it } from 'vitest';
import { isEffective, selectEffective } from '../../src/core/rates.js';

const rows = [
  { id: 'old', effectiveFrom: '2020-01-01', effectiveTo: '2023-12-31' },
  { id: 'new', effectiveFrom: '2024-01-01', effectiveTo: null },
];

describe('effective-date selection', () => {
  it('treats both bounds as inclusive', () => {
    expect(isEffective(rows[0]!, '2023-12-31')).toBe(true);
    expect(isEffective(rows[0]!, '2024-01-01')).toBe(false);
    expect(isEffective(rows[1]!, '2024-01-01')).toBe(true);
  });

  it('picks the row in force on the date', () => {
    expect(selectEffective(rows, '2022-06-01')?.row.id).toBe('old');
    expect(selectEffective(rows, '2026-11-04')?.row.id).toBe('new');
    expect(selectEffective(rows, '2019-12-31')).toBeNull();
  });

  it('flags overlapping rows and prefers the latest start', () => {
    const overlap = [...rows, { id: 'dup', effectiveFrom: '2025-01-01', effectiveTo: null }];
    expect(selectEffective(overlap, '2026-01-01')).toEqual({
      row: overlap[2],
      ambiguous: true,
    });
  });
});
