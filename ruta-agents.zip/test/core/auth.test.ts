import { Hono } from 'hono';
import { SignJWT } from 'jose';
import { describe, expect, it } from 'vitest';
import {
  createVerifier,
  requireAuth,
  requireRole,
  rolesFromClaims,
  type AuthEnv,
} from '../../src/core/auth.js';
import { AppError } from '../../src/core/errors.js';

const SECRET = 'test-secret-at-least-32-characters-long!!';

async function token(
  claims: Record<string, unknown>,
  opts: { exp?: string; secret?: string } = {},
) {
  return new SignJWT(claims)
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject('11111111-1111-1111-1111-111111111111')
    .setAudience('authenticated')
    .setExpirationTime(opts.exp ?? '1h')
    .sign(new TextEncoder().encode(opts.secret ?? SECRET));
}

function app() {
  const a = new Hono<AuthEnv>();
  a.onError((err, c) =>
    err instanceof AppError ? c.json({ error: err.code }, err.status) : c.json({ error: 'x' }, 500),
  );
  a.use('*', requireAuth(createVerifier({ jwtSecret: SECRET })));
  a.get('/me', (c) => c.json(c.get('user')));
  a.post('/approve', requireRole('broker'), (c) => c.json({ ok: true }));
  return a;
}

const call = async (path: string, t?: string, method = 'GET') =>
  app().request(path, { method, headers: t ? { authorization: `Bearer ${t}` } : {} });

describe('auth', () => {
  it('reads roles from app_metadata and ignores unknown ones', () => {
    expect(rolesFromClaims({ app_metadata: { ruta_roles: ['staff', 'hacker', 'staff'] } })).toEqual(
      ['staff'],
    );
    expect(rolesFromClaims({ app_metadata: { role: 'broker' } })).toEqual(['broker']);
    expect(rolesFromClaims({})).toEqual([]);
  });

  it('accepts a valid Supabase token', async () => {
    const res = await call(
      '/me',
      await token({ email: 'a@b.c', app_metadata: { ruta_roles: ['staff'] } }),
    );
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({
      id: '11111111-1111-1111-1111-111111111111',
      email: 'a@b.c',
      roles: ['staff'],
    });
  });

  it('rejects missing, forged and expired tokens with 401', async () => {
    expect((await call('/me')).status).toBe(401);
    const forged = await token(
      { app_metadata: { ruta_roles: ['admin'] } },
      { secret: 'x'.repeat(40) },
    );
    expect((await call('/me', forged)).status).toBe(401);
    const expired = await token({ app_metadata: { ruta_roles: ['staff'] } }, { exp: '-1m' });
    expect((await call('/me', expired)).status).toBe(401);
  });

  it('rejects users without a RUTA role with 403', async () => {
    expect((await call('/me', await token({}))).status).toBe(403);
  });

  it('enforces route roles, with admin as a superuser', async () => {
    const staff = await token({ app_metadata: { ruta_roles: ['staff'] } });
    const broker = await token({ app_metadata: { ruta_roles: ['broker'] } });
    const admin = await token({ app_metadata: { ruta_roles: ['admin'] } });
    expect((await call('/approve', staff, 'POST')).status).toBe(403);
    expect((await call('/approve', broker, 'POST')).status).toBe(200);
    expect((await call('/approve', admin, 'POST')).status).toBe(200);
  });
});
