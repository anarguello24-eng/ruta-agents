import { describe, expect, it } from 'vitest';
import { z } from 'zod';
import { runAgent } from '../../src/core/agent/loop.js';
import { defineTool } from '../../src/core/agent/tool.js';
import { FakeLLMProvider } from '../../src/core/llm/fake.js';

const add = defineTool({
  name: 'add',
  description: 'adds two numbers',
  input: z.object({ a: z.number(), b: z.number() }),
  run: async ({ a, b }) => ({ sum: a + b }),
});
const boom = defineTool({
  name: 'boom',
  description: 'always fails',
  input: z.object({}),
  run: async () => {
    throw new Error('kaput');
  },
});

const common = {
  prompt: { id: 'test.agent', version: '1' },
  system: 'You are a test agent.',
  task: 'add 2 and 3',
  tools: [add, boom],
  finalSchema: z.object({ answer: z.number() }),
  ctx: { lang: 'en' as const, country: 'NI' },
  audit: async () => 1,
  auditContext: { entityType: 'test' },
  maxSteps: 5,
  stepTimeoutMs: 1000,
};

describe('runAgent', () => {
  it('calls tools and returns the validated final output', async () => {
    const provider = new FakeLLMProvider([
      { action: 'call_tool', tool: 'add', args: { a: 2, b: 3 } },
      (req) => {
        const last = req.messages.at(-1)!.content;
        expect(last).toBe('TOOL_RESULT add: {"ok":true,"result":{"sum":5}}');
        return { action: 'final', output: { answer: 5 } };
      },
    ]);
    const r = await runAgent({ ...common, provider });
    expect(r.output).toEqual({ answer: 5 });
    expect(r.steps).toMatchObject([{ tool: 'add', ok: true, result: { sum: 5 } }]);
  });

  it('reports invalid tool arguments and tool errors back to the model', async () => {
    const provider = new FakeLLMProvider([
      { action: 'call_tool', tool: 'add', args: { a: 'two', b: 3 } },
      { action: 'call_tool', tool: 'boom', args: {} },
      { action: 'final', output: { answer: 0 } },
    ]);
    const r = await runAgent({ ...common, provider });
    expect(r.steps[0]).toMatchObject({
      ok: false,
      error: expect.stringMatching(/invalid arguments: a/),
    });
    expect(r.steps[1]).toMatchObject({ ok: false, error: 'kaput' });
    expect(provider.calls[2]!.messages.at(-1)!.content).toContain('"error":"kaput"');
  });

  it('rejects unknown tools through schema validation', async () => {
    const provider = new FakeLLMProvider([
      { action: 'call_tool', tool: 'rm_rf', args: {} },
      { action: 'final', output: { answer: 1 } },
    ]);
    const r = await runAgent({ ...common, provider });
    expect(r.output).toEqual({ answer: 1 });
    expect(provider.calls[1]!.messages.at(-1)!.content).toMatch(/rejected: tool/);
  });

  it('stops after maxSteps', async () => {
    const provider = new FakeLLMProvider(
      Array.from({ length: 3 }, () => ({ action: 'call_tool', tool: 'add', args: { a: 1, b: 1 } })),
    );
    await expect(runAgent({ ...common, provider, maxSteps: 3 })).rejects.toMatchObject({
      code: 'agent_max_steps',
    });
  });
});
