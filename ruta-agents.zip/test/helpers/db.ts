import { createDb, type DbHandle } from '../../src/core/db/client.js';
import { runMigrations } from '../../src/core/db/migrate.js';
import { seedAll } from '../../src/seed.js';
import { MIGRATIONS_DIR, SEED_DIR } from '../../src/core/paths.js';

export const TEST_DATABASE_URL = process.env.TEST_DATABASE_URL;
/** Every schema created by migrations; dropped before each fresh test database. */
export const APP_SCHEMAS = ['core', 'customs', 'sourcing', 'logistics', 'trade'];

export const hasTestDb = Boolean(TEST_DATABASE_URL);

export { MIGRATIONS_DIR, SEED_DIR } from '../../src/core/paths.js';

/** Drops all app schemas, re-applies all migrations and (optionally) the sample seed. */
export async function freshTestDb(opts: { seed?: boolean } = {}): Promise<DbHandle> {
  if (!TEST_DATABASE_URL) throw new Error('TEST_DATABASE_URL is not set');
  const handle = createDb(TEST_DATABASE_URL, { max: 2 });
  for (const schema of APP_SCHEMAS)
    await handle.sql`DROP SCHEMA IF EXISTS ${handle.sql(schema)} CASCADE`;
  await handle.sql`DROP TABLE IF EXISTS public.ruta_customs_migrations`;
  await runMigrations(handle.sql, MIGRATIONS_DIR);
  if (opts.seed) await seedAll(handle.sql, SEED_DIR);
  return handle;
}
