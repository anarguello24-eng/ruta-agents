import { describe, expect, it } from 'vitest';
import {
  canTransition,
  detectExceptions,
  type ShipmentSnapshot,
} from '../../src/agents/logistics/tracking.js';

const now = new Date('2026-11-04T12:00:00Z');
const hoursAgo = (h: number) => new Date(now.getTime() - h * 3_600_000);
const snap = (over: Partial<ShipmentSnapshot>): ShipmentSnapshot => ({
  mode: 'air',
  status: 'departed',
  etaPromised: '2026-11-05',
  etaCurrent: '2026-11-05',
  statusSince: hoursAgo(2),
  lastEventAt: hoursAgo(2),
  arrivedAt: null,
  freeDays: null,
  ...over,
});
const codes = (s: ShipmentSnapshot) =>
  detectExceptions(s, now, 'en').map((f) => `${f.code}:${f.severity}`);

describe('canTransition', () => {
  it('allows forward jumps but not going back', () => {
    expect(canTransition('booked', 'departed')).toBe(true);
    expect(canTransition('arrived', 'departed')).toBe(false);
    expect(canTransition('delivered', 'released')).toBe(false);
  });
  it('restricts customs holds and cancellation', () => {
    expect(canTransition('in_customs', 'customs_hold')).toBe(true);
    expect(canTransition('departed', 'customs_hold')).toBe(false);
    expect(canTransition('customs_hold', 'released')).toBe(true);
    expect(canTransition('customs_hold', 'delivered')).toBe(false);
    expect(canTransition('at_origin_hub', 'cancelled')).toBe(true);
    expect(canTransition('departed', 'cancelled')).toBe(false);
  });
});

describe('detectExceptions', () => {
  it('is quiet for a healthy shipment and for finished ones', () => {
    expect(codes(snap({}))).toEqual([]);
    expect(codes(snap({ status: 'delivered', etaCurrent: '2026-12-01' }))).toEqual([]);
  });

  it('grades ETA slips', () => {
    expect(codes(snap({ etaCurrent: '2026-11-07' }))).toEqual(['ETA_SLIP:warning']);
    expect(codes(snap({ etaCurrent: '2026-11-10' }))).toEqual(['ETA_SLIP:error']);
  });

  it('flags overdue arrivals and stale tracking by mode', () => {
    expect(codes(snap({ etaPromised: '2026-11-01', etaCurrent: '2026-11-01' }))).toEqual([
      'OVERDUE_ARRIVAL:error',
    ]);
    expect(codes(snap({ lastEventAt: hoursAgo(30) }))).toEqual(['STALE_TRACKING:warning']);
    expect(
      codes(
        snap({
          mode: 'sea_lcl',
          etaPromised: '2026-12-01',
          etaCurrent: '2026-12-01',
          lastEventAt: hoursAgo(30),
        }),
      ),
    ).toEqual([]);
  });

  it('flags customs holds and long customs dwell', () => {
    expect(codes(snap({ status: 'customs_hold', statusSince: hoursAgo(5) }))).toEqual([
      'CUSTOMS_HOLD:error',
    ]);
    expect(codes(snap({ status: 'in_customs', statusSince: hoursAgo(80) }))).toEqual([
      'CUSTOMS_DWELL:warning',
    ]);
  });

  it('warns before container free time runs out and errors after', () => {
    const fcl = {
      mode: 'sea_fcl' as const,
      status: 'in_customs' as const,
      statusSince: hoursAgo(1),
    };
    expect(codes(snap({ ...fcl, arrivedAt: hoursAgo(24 * 6), freeDays: 7 }))).toEqual([
      'DEMURRAGE_RISK:warning',
    ]);
    expect(codes(snap({ ...fcl, arrivedAt: hoursAgo(24 * 9), freeDays: 7 }))).toEqual([
      'DEMURRAGE:error',
    ]);
    expect(
      codes(snap({ ...fcl, status: 'released', arrivedAt: hoursAgo(24 * 9), freeDays: 7 })),
    ).toEqual([]);
  });
});
