import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { quoteFreight } from '../../src/agents/logistics/quote.js';
import { DbLogisticsReference, seedLogistics } from '../../src/agents/logistics/reference.js';
import type { DbHandle } from '../../src/core/db/client.js';
import { freshTestDb, hasTestDb, SEED_DIR } from '../helpers/db.js';

describe.skipIf(!hasTestDb)('logistics rate cards (integration)', () => {
  let h: DbHandle;
  beforeAll(async () => {
    h = await freshTestDb({ seed: true });
  });
  afterAll(async () => {
    await h?.close();
  });

  it('quotes from the seeded sample rate cards', async () => {
    const r = await quoteFreight(
      {
        date: '2026-11-04',
        mode: 'air',
        origin: 'USMIA',
        destination: 'NIMGA',
        packages: [{ qty: 3, lengthCm: 50, widthCm: 40, heightCm: 30, weightKg: 18 }],
      },
      new DbLogisticsReference(h.sql),
    );
    // 54 kg actual vs 30 kg volumetric → 54 kg at the 45 kg break (1.85)
    expect(r.options[0]!.chargeable).toEqual({ qty: '54', unit: 'kg' });
    expect(r.options[0]!.lines.map((l) => [l.code, l.amount])).toEqual([
      ['FREIGHT', '99.90'],
      ['AWB', '35.00'],
      ['FSC', '18.90'],
      ['SSC', '8.10'],
    ]);
    expect(r.isEstimate).toBe(true);
  });

  it('re-seeding is idempotent', async () => {
    const n = async () =>
      (await h.sql<{ n: number }[]>`SELECT count(*)::int n FROM logistics.surcharges`)[0]!.n;
    const before = await n();
    await seedLogistics(h.sql, SEED_DIR);
    expect(await n()).toBe(before);
  });
});
