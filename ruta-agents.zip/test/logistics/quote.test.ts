import { describe, expect, it } from 'vitest';
import {
  chargeableKg,
  cheapest,
  freightForBreaks,
  quoteFreight,
  revenueTons,
  type QuoteInput,
} from '../../src/agents/logistics/quote.js';
import { MemoryLogisticsReference, type RateCard } from '../../src/agents/logistics/reference.js';
import { D } from '../../src/core/money.js';

const card = (over: Partial<RateCard>): RateCard => ({
  id: over.code ?? 'c',
  code: 'c',
  country: 'NI',
  carrier: 'Carrier',
  mode: 'air',
  origin: 'USMIA',
  destination: 'NIMGA',
  containerType: null,
  unit: 'kg',
  volumetricDivisor: 6000,
  minCharge: '75',
  currency: 'USD',
  transitDaysMin: 1,
  transitDaysMax: 3,
  effectiveFrom: '2026-01-01',
  effectiveTo: null,
  isSample: false,
  breaks: [],
  surcharges: [],
  ...over,
});

const airBreaks = [
  { fromQty: '0', rate: '2.10' },
  { fromQty: '45', rate: '1.85' },
  { fromQty: '100', rate: '1.60' },
];

const refData = new MemoryLogisticsReference([
  card({
    code: 'AIR-A',
    carrier: 'Air A',
    breaks: airBreaks,
    surcharges: [
      {
        code: 'FSC',
        nameEs: 'Combustible',
        nameEn: 'Fuel',
        basis: 'per_unit',
        amount: '0.35',
        minAmount: null,
      },
      {
        code: 'AWB',
        nameEs: 'Guía',
        nameEn: 'AWB fee',
        basis: 'per_shipment',
        amount: '35',
        minAmount: null,
      },
    ],
  }),
  card({
    code: 'AIR-OLD',
    carrier: 'Air Old',
    breaks: airBreaks,
    effectiveTo: '2025-12-31',
    effectiveFrom: '2025-01-01',
  }),
  card({
    code: 'LCL',
    mode: 'sea_lcl',
    origin: 'CNSHA',
    destination: 'NICIO',
    unit: 'wm',
    volumetricDivisor: null,
    minCharge: '95',
    breaks: [{ fromQty: '0', rate: '95' }],
    surcharges: [
      {
        code: 'DTHC',
        nameEs: 'Manejo',
        nameEn: 'Handling',
        basis: 'per_unit',
        amount: '15',
        minAmount: '30',
      },
      {
        code: 'BL',
        nameEs: 'BL',
        nameEn: 'BL fee',
        basis: 'per_shipment',
        amount: '50',
        minAmount: null,
      },
    ],
  }),
  ...(['20GP', '40HC'] as const).map((t) =>
    card({
      code: `FCL-${t}`,
      carrier: 'Ocean',
      mode: 'sea_fcl',
      origin: 'CNSHA',
      destination: 'NICIO',
      unit: 'container',
      containerType: t,
      volumetricDivisor: null,
      minCharge: '0',
      isSample: true,
      breaks: [{ fromQty: '0', rate: t === '20GP' ? '2900' : '4400' }],
      surcharges: [
        {
          code: 'THC',
          nameEs: 'THC',
          nameEn: 'THC',
          basis: 'per_container',
          amount: '250',
          minAmount: null,
        },
        {
          code: 'BAF',
          nameEs: 'BAF',
          nameEn: 'BAF',
          basis: 'percent_of_freight',
          amount: '10',
          minAmount: null,
        },
        {
          code: 'BL',
          nameEs: 'BL',
          nameEn: 'BL fee',
          basis: 'per_shipment',
          amount: '75',
          minAmount: null,
        },
      ],
    }),
  ),
]);

const air = (packages: QuoteInput['packages']): QuoteInput => ({
  date: '2026-11-04',
  mode: 'air',
  origin: 'usmia',
  destination: 'NIMGA',
  packages,
  lang: 'en',
});

describe('chargeable quantities', () => {
  it('uses the greater of actual and volumetric weight, rounded up to 0.5 kg', () => {
    // 60×40×40 cm = 96,000 cm3 / 6000 = 16 kg volumetric vs 10 kg actual
    expect(chargeableKg(D(10), D(96000), 6000).toString()).toBe('16');
    expect(chargeableKg(D(20.1), D(96000), 6000).toString()).toBe('20.5');
    expect(chargeableKg(D(20.5), D(96000), 6000).toString()).toBe('20.5');
    expect(chargeableKg(D(7), D(96000), 5000).toString()).toBe('19.5'); // courier divisor
  });

  it('computes LCL revenue tons as max(m3, tonnes)', () => {
    expect(revenueTons(D(800), D('2.5')).toString()).toBe('2.5');
    expect(revenueTons(D(3200), D('2.5')).toString()).toBe('3.2');
    expect(revenueTons(D(1), D('0.0123')).toString()).toBe('0.02');
  });

  it('charges the next weight break when it is cheaper', () => {
    // 40 kg × 2.10 = 84.00 but 45 kg × 1.85 = 83.25
    expect(freightForBreaks(D(40), airBreaks)).toMatchObject({
      amount: D('83.25'),
      rate: D('1.85'),
    });
    expect(freightForBreaks(D(30), airBreaks).amount.toString()).toBe('63');
    expect(freightForBreaks(D(150), airBreaks).amount.toString()).toBe('240');
  });
});

describe('quoteFreight', () => {
  it('quotes air with chargeable weight, break rates, surcharges and only effective cards', async () => {
    const r = await quoteFreight(
      air([{ qty: 2, lengthCm: 60, widthCm: 40, heightCm: 40, weightKg: 10 }]), // 20 kg actual, 32 kg vol
      refData,
    );
    expect(r.measures).toEqual({ pieces: 2, actualKg: '20', volumeM3: '0.192' });
    expect(r.options).toHaveLength(1); // AIR-OLD expired
    const o = r.options[0]!;
    expect(o.chargeable).toEqual({ qty: '32', unit: 'kg' });
    expect(o.lines.map((l) => [l.code, l.amount])).toEqual([
      ['FREIGHT_MIN', '75.00'], // 32 × 2.10 = 67.20 → minimum 75
      ['FSC', '11.20'], // 32 × 0.35
      ['AWB', '35.00'],
    ]);
    expect(o.total).toBe('121.20');
    expect(r.isEstimate).toBe(false);
  });

  it('quotes LCL by W/M with surcharge minimums', async () => {
    const r = await quoteFreight(
      {
        date: '2026-11-04',
        mode: 'sea_lcl',
        origin: 'CNSHA',
        destination: 'NICIO',
        packages: [{ qty: 10, lengthCm: 100, widthCm: 80, heightCm: 50, weightKg: 120 }], // 4 m3, 1.2 t
      },
      refData,
    );
    const o = r.options[0]!;
    expect(o.chargeable).toEqual({ qty: '4', unit: 'wm' });
    expect(o.lines.map((l) => [l.code, l.amount])).toEqual([
      ['FREIGHT', '380.00'],
      ['DTHC', '60.00'],
      ['BL', '50.00'],
    ]);
    expect(o.total).toBe('490.00');
  });

  it('quotes FCL per container type, charging per-shipment fees once', async () => {
    const r = await quoteFreight(
      {
        date: '2026-11-04',
        mode: 'sea_fcl',
        origin: 'CNSHA',
        destination: 'NICIO',
        containers: [
          { type: '20GP', qty: 2 },
          { type: '40HC', qty: 1 },
        ],
      },
      refData,
    );
    const o = r.options[0]!;
    expect(o.containerType).toBe('20GP+40HC');
    expect(o.lines.map((l) => [l.code, l.amount])).toEqual([
      ['FREIGHT', '5800.00'],
      ['THC', '500.00'],
      ['BAF', '580.00'],
      ['BL', '75.00'],
      ['FREIGHT', '4400.00'],
      ['THC', '250.00'],
      ['BAF', '440.00'],
    ]);
    expect(o.total).toBe('12045.00');
    expect(r.isEstimate).toBe(true);
    expect(r.flags.map((f) => f.code)).toEqual(['SAMPLE_RATE']);
    expect(cheapest(r)).toBe(o);
  });

  it('reports lanes and container types without rates', async () => {
    const lane = await quoteFreight(
      { ...air([{ qty: 1, lengthCm: 1, widthCm: 1, heightCm: 1, weightKg: 1 }]), origin: 'CNSHA' },
      refData,
    );
    expect(lane.options).toEqual([]);
    expect(lane.flags.map((f) => f.code)).toEqual(['NO_RATE']);
    const fcl = await quoteFreight(
      {
        date: '2026-11-04',
        mode: 'sea_fcl',
        origin: 'CNSHA',
        destination: 'NICIO',
        containers: [{ type: '40RF', qty: 1 }],
      },
      refData,
    );
    expect(fcl.flags.map((f) => f.code)).toEqual(['NO_RATE_FOR_CONTAINER']);
  });

  it('validates input', async () => {
    await expect(quoteFreight(air([]), refData)).rejects.toThrow(/package/);
    const pkg = [{ qty: 1, lengthCm: 1, widthCm: 1, heightCm: 1, weightKg: 1 }];
    await expect(quoteFreight({ ...air(pkg), origin: 'MIA' }, refData)).rejects.toThrow(/LOCODE/);
    await expect(
      quoteFreight(
        { date: '2026-11-04', mode: 'sea_fcl', origin: 'CNSHA', destination: 'NICIO' },
        refData,
      ),
    ).rejects.toThrow(/containers/);
  });
});
