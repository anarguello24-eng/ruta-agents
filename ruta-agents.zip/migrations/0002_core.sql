-- 0002_core: shared platform objects used by every agent.

CREATE SCHEMA IF NOT EXISTS core;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA core FROM anon';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA core FROM authenticated';
  END IF;
END $$;

CREATE OR REPLACE FUNCTION core.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END $$;

CREATE OR REPLACE FUNCTION core.append_only() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION '%.% is append-only', TG_TABLE_SCHEMA, TG_TABLE_NAME;
END $$;

-- Human approval queue for anything an agent wants to do outside the system
-- (send an email, award a supplier, notify a client, issue a document).
CREATE TABLE core.approvals (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country          char(2) NOT NULL DEFAULT 'NI',
  agent            text NOT NULL CHECK (agent IN ('customs', 'sourcing', 'logistics', 'trade')),
  kind             text NOT NULL,
  ref_id           uuid,
  title            text NOT NULL,
  payload          jsonb NOT NULL,
  status           text NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending', 'approved', 'rejected', 'executed', 'failed', 'cancelled')),
  required_role    text NOT NULL,
  requested_by_type text NOT NULL CHECK (requested_by_type IN ('ai', 'user', 'system')),
  requested_by     text,
  decided_by       uuid,
  decided_at       timestamptz,
  decision_note    text,
  executed_at      timestamptz,
  result           jsonb,
  error            text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT approvals_decision_fields CHECK (
    status IN ('pending', 'cancelled') OR (decided_by IS NOT NULL AND decided_at IS NOT NULL)
  )
);
CREATE INDEX approvals_queue_idx ON core.approvals (status, agent, required_role, created_at);
CREATE INDEX approvals_ref_idx ON core.approvals (ref_id);
CREATE TRIGGER approvals_touch BEFORE UPDATE ON core.approvals
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();
