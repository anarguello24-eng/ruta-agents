-- 0003_trade: import/export operations, trade agreements, document requirements.

CREATE SCHEMA IF NOT EXISTS trade;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA trade FROM anon';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA trade FROM authenticated';
  END IF;
END $$;

CREATE TABLE trade.operations (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country             char(2) NOT NULL DEFAULT 'NI',
  direction           text NOT NULL CHECK (direction IN ('import', 'export')),
  partner_country     char(2) NOT NULL,
  transport_mode      text NOT NULL CHECK (transport_mode IN ('sea', 'air', 'ground', 'courier')),
  incoterm            text,
  hs_code             text CHECK (hs_code IS NULL OR hs_code ~ '^[0-9]{2,12}$'),
  product_description text NOT NULL,
  value               numeric(18, 2),
  currency            char(3),
  wants_preference    boolean NOT NULL DEFAULT true,
  status              text NOT NULL DEFAULT 'draft'
                      CHECK (status IN ('draft', 'collecting_documents', 'ready', 'in_transit', 'closed', 'cancelled')),
  lang                char(2) NOT NULL DEFAULT 'es' CHECK (lang IN ('es', 'en')),
  client_ref          text,
  customs_case_id     uuid,
  shipment_id         uuid,
  created_by          uuid,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER operations_touch BEFORE UPDATE ON trade.operations
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TABLE trade.operation_documents (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  operation_id  uuid NOT NULL REFERENCES trade.operations (id) ON DELETE CASCADE,
  doc_code      text NOT NULL,
  status        text NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending', 'received', 'verified', 'not_applicable')),
  storage_path  text,
  notes         text,
  updated_by    uuid,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (operation_id, doc_code)
);
CREATE TRIGGER operation_documents_touch BEFORE UPDATE ON trade.operation_documents
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TABLE trade.agreements (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code           text NOT NULL UNIQUE,
  name_es        text NOT NULL,
  name_en        text NOT NULL,
  proof_of_origin text NOT NULL,
  notes          text,
  is_sample      boolean NOT NULL DEFAULT false,
  source_url     text
);

CREATE TABLE trade.agreement_members (
  agreement_id   uuid NOT NULL REFERENCES trade.agreements (id) ON DELETE CASCADE,
  country        char(2) NOT NULL,
  effective_from date NOT NULL,
  effective_to   date,
  PRIMARY KEY (agreement_id, country, effective_from),
  CHECK (effective_to IS NULL OR effective_to >= effective_from)
);
CREATE INDEX agreement_members_country_idx ON trade.agreement_members (country);

CREATE TABLE trade.doc_requirements (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country        char(2) NOT NULL DEFAULT 'NI',
  direction      text NOT NULL CHECK (direction IN ('import', 'export', 'both')),
  -- 'any', 'mcca' (Central American common market partner), 'non_mcca', or an ISO-2 code
  partner_scope  text NOT NULL DEFAULT 'any',
  transport_mode text NOT NULL DEFAULT 'any' CHECK (transport_mode IN ('any', 'sea', 'air', 'ground', 'courier')),
  hs_prefix      text CHECK (hs_prefix IS NULL OR hs_prefix ~ '^[0-9]{2,12}$'),
  doc_code       text NOT NULL,
  name_es        text NOT NULL,
  name_en        text NOT NULL,
  issuer         text NOT NULL,
  requirement    text NOT NULL DEFAULT 'required' CHECK (requirement IN ('required', 'conditional')),
  notes          text,
  is_sample      boolean NOT NULL DEFAULT false,
  source_url     text,
  UNIQUE NULLS NOT DISTINCT (country, direction, partner_scope, transport_mode, hs_prefix, doc_code)
);

CREATE TABLE trade.audit_log (
  id               bigserial PRIMARY KEY,
  country          char(2) NOT NULL DEFAULT 'NI',
  operation_id     uuid REFERENCES trade.operations (id) ON DELETE SET NULL,
  entity_type      text NOT NULL,
  entity_id        text,
  actor_type       text NOT NULL CHECK (actor_type IN ('ai', 'user', 'system')),
  actor_id         text,
  action           text NOT NULL,
  prompt_version   text,
  model            text,
  input_hash       text,
  raw_output       text,
  validated_output jsonb,
  before           jsonb,
  after            jsonb,
  error            text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT audit_ai_fields CHECK (actor_type <> 'ai' OR (prompt_version IS NOT NULL AND model IS NOT NULL AND input_hash IS NOT NULL)),
  CONSTRAINT audit_user_fields CHECK (actor_type <> 'user' OR actor_id IS NOT NULL)
);
CREATE INDEX trade_audit_log_ref_idx ON trade.audit_log (operation_id, created_at);
CREATE TRIGGER audit_log_no_update BEFORE UPDATE OR DELETE ON trade.audit_log
  FOR EACH ROW EXECUTE FUNCTION core.append_only();
