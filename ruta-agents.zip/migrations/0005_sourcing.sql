-- 0005_sourcing: suppliers, RFQ events, invitations, quotes, comparisons.

CREATE SCHEMA IF NOT EXISTS sourcing;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA sourcing FROM anon';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA sourcing FROM authenticated';
  END IF;
END $$;

CREATE TABLE sourcing.suppliers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code          text UNIQUE,
  name          text NOT NULL,
  country       char(2) NOT NULL,
  categories    text[] NOT NULL DEFAULT '{}',
  languages     text[] NOT NULL DEFAULT '{en}',
  rating        numeric(3, 2) CHECK (rating IS NULL OR rating BETWEEN 0 AND 5),
  on_time_rate  numeric(5, 4) CHECK (on_time_rate IS NULL OR on_time_rate BETWEEN 0 AND 1),
  status        text NOT NULL DEFAULT 'unvetted' CHECK (status IN ('approved', 'unvetted', 'blocked')),
  website       text,
  notes         text,
  embedding     vector(1024),
  is_sample     boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX suppliers_categories_idx ON sourcing.suppliers USING gin (categories);
CREATE INDEX suppliers_embedding_idx ON sourcing.suppliers USING hnsw (embedding vector_cosine_ops);
CREATE TRIGGER suppliers_touch BEFORE UPDATE ON sourcing.suppliers
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TABLE sourcing.supplier_contacts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id  uuid NOT NULL REFERENCES sourcing.suppliers (id) ON DELETE CASCADE,
  name         text,
  email        text NOT NULL,
  phone        text,
  language     text NOT NULL DEFAULT 'en',
  is_primary   boolean NOT NULL DEFAULT false,
  UNIQUE (supplier_id, email)
);

CREATE TABLE sourcing.rfq_events (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country         char(2) NOT NULL DEFAULT 'NI',
  reference       text NOT NULL UNIQUE,
  title           text NOT NULL,
  client_ref      text,
  status          text NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft', 'sourcing', 'quoting', 'evaluating', 'negotiating',
                                    'awarded', 'po_issued', 'closed', 'cancelled')),
  destination     text NOT NULL DEFAULT 'NIMGA',
  required_by     date,
  preferred_incoterm text,
  lang            char(2) NOT NULL DEFAULT 'es' CHECK (lang IN ('es', 'en')),
  guardrails      jsonb NOT NULL DEFAULT '{}'::jsonb,
  weights         jsonb,
  awarded_by      uuid,
  awarded_at      timestamptz,
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT rfq_award_requires_buyer CHECK (status NOT IN ('awarded', 'po_issued', 'closed') OR awarded_by IS NOT NULL)
);
CREATE TRIGGER rfq_events_touch BEFORE UPDATE ON sourcing.rfq_events
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TABLE sourcing.rfq_items (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id       uuid NOT NULL REFERENCES sourcing.rfq_events (id) ON DELETE CASCADE,
  ref          text NOT NULL,
  description  text NOT NULL,
  specs        text,
  quantity     numeric(18, 4) NOT NULL CHECK (quantity > 0),
  unit         text NOT NULL,
  sac_code     text CHECK (sac_code IS NULL OR sac_code ~ '^[0-9]{4,12}$'),
  target_price numeric(18, 6),
  UNIQUE (rfq_id, ref)
);

CREATE TABLE sourcing.invitations (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id       uuid NOT NULL REFERENCES sourcing.rfq_events (id) ON DELETE CASCADE,
  supplier_id  uuid NOT NULL REFERENCES sourcing.suppliers (id),
  status       text NOT NULL DEFAULT 'drafted'
               CHECK (status IN ('drafted', 'approved', 'sent', 'replied', 'declined', 'expired')),
  thread_id    text,
  sent_at      timestamptz,
  last_reminder_at timestamptz,
  reminders    integer NOT NULL DEFAULT 0,
  UNIQUE (rfq_id, supplier_id)
);

CREATE TABLE sourcing.messages (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id         uuid NOT NULL REFERENCES sourcing.rfq_events (id) ON DELETE CASCADE,
  invitation_id  uuid REFERENCES sourcing.invitations (id) ON DELETE SET NULL,
  direction      text NOT NULL CHECK (direction IN ('outbound', 'inbound')),
  approval_id    uuid REFERENCES core.approvals (id),
  subject        text,
  body           text NOT NULL,
  attachments    jsonb NOT NULL DEFAULT '[]'::jsonb,
  provider_message_id text,
  received_at    timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT outbound_needs_approval CHECK (direction = 'inbound' OR approval_id IS NOT NULL)
);

CREATE TABLE sourcing.quotes (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id         uuid NOT NULL REFERENCES sourcing.rfq_events (id) ON DELETE CASCADE,
  supplier_id    uuid NOT NULL REFERENCES sourcing.suppliers (id),
  source_message_id uuid REFERENCES sourcing.messages (id),
  currency       char(3) NOT NULL,
  incoterm       text,
  named_place    text,
  valid_until    date,
  payment_terms  text,
  status         text NOT NULL DEFAULT 'extracted' CHECK (status IN ('extracted', 'confirmed', 'rejected', 'superseded')),
  confirmed_by   uuid,
  confirmed_at   timestamptz,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sourcing.quote_lines (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quote_id         uuid NOT NULL REFERENCES sourcing.quotes (id) ON DELETE CASCADE,
  item_id          uuid NOT NULL REFERENCES sourcing.rfq_items (id) ON DELETE CASCADE,
  unit_price       numeric(18, 6) NOT NULL CHECK (unit_price >= 0),
  moq              numeric(18, 4),
  lead_time_days   integer,
  notes            text,
  -- Every extracted number keeps the exact text it came from.
  source_snippet   text NOT NULL,
  source_message_id uuid REFERENCES sourcing.messages (id),
  UNIQUE (quote_id, item_id)
);

CREATE TABLE sourcing.comparisons (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rfq_id      uuid NOT NULL REFERENCES sourcing.rfq_events (id) ON DELETE CASCADE,
  input       jsonb NOT NULL,
  result      jsonb NOT NULL,
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE sourcing.audit_log (
  id               bigserial PRIMARY KEY,
  country          char(2) NOT NULL DEFAULT 'NI',
  rfq_id           uuid REFERENCES sourcing.rfq_events (id) ON DELETE SET NULL,
  entity_type      text NOT NULL,
  entity_id        text,
  actor_type       text NOT NULL CHECK (actor_type IN ('ai', 'user', 'system')),
  actor_id         text,
  action           text NOT NULL,
  prompt_version   text,
  model            text,
  input_hash       text,
  raw_output       text,
  validated_output jsonb,
  before           jsonb,
  after            jsonb,
  error            text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT audit_ai_fields CHECK (actor_type <> 'ai' OR (prompt_version IS NOT NULL AND model IS NOT NULL AND input_hash IS NOT NULL)),
  CONSTRAINT audit_user_fields CHECK (actor_type <> 'user' OR actor_id IS NOT NULL)
);
CREATE INDEX sourcing_audit_log_ref_idx ON sourcing.audit_log (rfq_id, created_at);
CREATE TRIGGER audit_log_no_update BEFORE UPDATE OR DELETE ON sourcing.audit_log
  FOR EACH ROW EXECUTE FUNCTION core.append_only();
