-- 0001_init: customs schema, core tables, reference tables.
-- Rates are stored as PERCENTAGES (15 = 15 %). Tariff codes are stored as digits only.

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS customs;

-- Keep the customs schema private: the service talks to Postgres directly, never via PostgREST.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA customs FROM anon';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA customs FROM authenticated';
  END IF;
END $$;

CREATE OR REPLACE FUNCTION customs.touch_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END $$;

-- ---------------------------------------------------------------------------
-- Workflow tables
-- ---------------------------------------------------------------------------

CREATE TABLE customs.cases (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country         char(2) NOT NULL DEFAULT 'NI',
  reference       text,
  shipment_id     text,
  status          text NOT NULL DEFAULT 'draft'
                  CHECK (status IN ('draft', 'in_review', 'approved', 'filed', 'released')),
  lang            char(2) NOT NULL DEFAULT 'es' CHECK (lang IN ('es', 'en')),
  currency        char(3),
  exchange_rate   numeric(18, 6),
  header          jsonb NOT NULL DEFAULT '{}'::jsonb,
  flags           jsonb NOT NULL DEFAULT '[]'::jsonb,
  duca_number     text,
  created_by      uuid,
  approved_by     uuid,
  approved_at     timestamptz,
  filed_by        uuid,
  filed_at        timestamptz,
  released_at     timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT cases_filed_requires_duca CHECK (status NOT IN ('filed', 'released') OR duca_number IS NOT NULL),
  CONSTRAINT cases_approved_requires_broker CHECK (status IN ('draft', 'in_review') OR approved_by IS NOT NULL)
);
CREATE INDEX cases_country_status_idx ON customs.cases (country, status);
CREATE TRIGGER cases_touch BEFORE UPDATE ON customs.cases
  FOR EACH ROW EXECUTE FUNCTION customs.touch_updated_at();

CREATE TABLE customs.documents (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id           uuid NOT NULL REFERENCES customs.cases (id) ON DELETE CASCADE,
  country           char(2) NOT NULL DEFAULT 'NI',
  doc_type          text NOT NULL
                    CHECK (doc_type IN ('commercial_invoice', 'packing_list', 'bill_of_lading',
                                        'air_waybill', 'certificate_of_origin', 'other')),
  storage_path      text NOT NULL,
  file_name         text,
  mime_type         text,
  extraction_status text NOT NULL DEFAULT 'pending'
                    CHECK (extraction_status IN ('pending', 'done', 'failed')),
  extraction        jsonb,
  uploaded_by       uuid,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX documents_case_idx ON customs.documents (case_id);
CREATE TRIGGER documents_touch BEFORE UPDATE ON customs.documents
  FOR EACH ROW EXECUTE FUNCTION customs.touch_updated_at();

CREATE TABLE customs.lines (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id            uuid NOT NULL REFERENCES customs.cases (id) ON DELETE CASCADE,
  country            char(2) NOT NULL DEFAULT 'NI',
  line_no            integer NOT NULL,
  description        text NOT NULL,
  quantity           numeric(18, 4),
  unit               text,
  unit_price         numeric(18, 6),
  total              numeric(18, 2),
  gross_weight_kg    numeric(18, 3),
  net_weight_kg      numeric(18, 3),
  origin_country     char(2),
  source_document_id uuid REFERENCES customs.documents (id) ON DELETE SET NULL,
  sac_code           text CHECK (sac_code IS NULL OR sac_code ~ '^[0-9]{4,12}$'),
  status             text NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending', 'suggested', 'accepted', 'approved')),
  approved_by        uuid,
  approved_at        timestamptz,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, line_no),
  CONSTRAINT lines_approved_requires_code CHECK (status <> 'approved' OR (sac_code IS NOT NULL AND approved_by IS NOT NULL))
);
CREATE INDEX lines_case_idx ON customs.lines (case_id);
CREATE TRIGGER lines_touch BEFORE UPDATE ON customs.lines
  FOR EACH ROW EXECUTE FUNCTION customs.touch_updated_at();

CREATE TABLE customs.audit_log (
  id              bigserial PRIMARY KEY,
  country         char(2) NOT NULL DEFAULT 'NI',
  case_id         uuid REFERENCES customs.cases (id) ON DELETE SET NULL,
  entity_type     text NOT NULL,
  entity_id       text,
  actor_type      text NOT NULL CHECK (actor_type IN ('ai', 'user', 'system')),
  actor_id        text,
  action          text NOT NULL,
  -- AI call fields
  prompt_version  text,
  model           text,
  input_hash      text,
  raw_output      text,
  validated_output jsonb,
  -- Human change fields
  before          jsonb,
  after           jsonb,
  error           text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT audit_ai_fields CHECK (actor_type <> 'ai' OR (prompt_version IS NOT NULL AND model IS NOT NULL AND input_hash IS NOT NULL)),
  CONSTRAINT audit_user_fields CHECK (actor_type <> 'user' OR actor_id IS NOT NULL)
);
CREATE INDEX audit_log_case_idx ON customs.audit_log (case_id, created_at);
CREATE INDEX audit_log_entity_idx ON customs.audit_log (entity_type, entity_id);

-- The audit log is append-only.
CREATE OR REPLACE FUNCTION customs.audit_log_immutable() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'customs.audit_log is append-only';
END $$;
CREATE TRIGGER audit_log_no_update BEFORE UPDATE OR DELETE ON customs.audit_log
  FOR EACH ROW EXECUTE FUNCTION customs.audit_log_immutable();

-- ---------------------------------------------------------------------------
-- Reference tables (versioned by effective date)
-- ---------------------------------------------------------------------------

CREATE TABLE customs.tariff_sac (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country         char(2) NOT NULL DEFAULT 'NI',
  code            text NOT NULL CHECK (code ~ '^[0-9]{4,12}$'),
  description_es  text NOT NULL,
  description_en  text,
  dai_rate        numeric(7, 4) NOT NULL CHECK (dai_rate >= 0),
  isc_rate        numeric(7, 4) CHECK (isc_rate IS NULL OR isc_rate >= 0),
  notes           text,
  embedding       vector(1024),
  search_tsv      tsvector GENERATED ALWAYS AS (
                    setweight(to_tsvector('simple', code), 'A') ||
                    setweight(to_tsvector('spanish', coalesce(description_es, '')), 'B') ||
                    setweight(to_tsvector('english', coalesce(description_en, '')), 'B') ||
                    setweight(to_tsvector('simple', coalesce(notes, '')), 'D')
                  ) STORED,
  effective_from  date NOT NULL,
  effective_to    date,
  is_sample       boolean NOT NULL DEFAULT false,
  source_url      text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (country, code, effective_from),
  CHECK (effective_to IS NULL OR effective_to >= effective_from)
);
CREATE INDEX tariff_sac_country_code_idx ON customs.tariff_sac (country, code);
CREATE INDEX tariff_sac_tsv_idx ON customs.tariff_sac USING gin (search_tsv);
CREATE INDEX tariff_sac_trgm_idx ON customs.tariff_sac USING gin (description_es gin_trgm_ops);
CREATE INDEX tariff_sac_embedding_idx ON customs.tariff_sac USING hnsw (embedding vector_cosine_ops);
CREATE TRIGGER tariff_sac_touch BEFORE UPDATE ON customs.tariff_sac
  FOR EACH ROW EXECUTE FUNCTION customs.touch_updated_at();

CREATE TABLE customs.tax_rates (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country          char(2) NOT NULL DEFAULT 'NI',
  tax_name         text NOT NULL,
  rate             numeric(7, 4) NOT NULL CHECK (rate >= 0),
  base_description text,
  effective_from   date NOT NULL,
  effective_to     date,
  is_sample        boolean NOT NULL DEFAULT false,
  source_url       text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (country, tax_name, effective_from),
  CHECK (effective_to IS NULL OR effective_to >= effective_from)
);
CREATE TRIGGER tax_rates_touch BEFORE UPDATE ON customs.tax_rates
  FOR EACH ROW EXECUTE FUNCTION customs.touch_updated_at();

CREATE TABLE customs.permits (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country     char(2) NOT NULL DEFAULT 'NI',
  sac_prefix  text NOT NULL CHECK (sac_prefix ~ '^[0-9]{2,12}$'),
  agency      text NOT NULL,
  permit_name text NOT NULL,
  notes       text,
  is_sample   boolean NOT NULL DEFAULT false,
  source_url  text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (country, sac_prefix, agency, permit_name)
);
CREATE INDEX permits_country_prefix_idx ON customs.permits (country, sac_prefix);

CREATE TABLE customs.line_classifications (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  line_id      uuid NOT NULL REFERENCES customs.lines (id) ON DELETE CASCADE,
  country      char(2) NOT NULL DEFAULT 'NI',
  rank         smallint NOT NULL CHECK (rank BETWEEN 1 AND 3),
  sac_code     text NOT NULL CHECK (sac_code ~ '^[0-9]{4,12}$'),
  tariff_id    uuid REFERENCES customs.tariff_sac (id) ON DELETE RESTRICT,
  gri_applied  text[] NOT NULL DEFAULT '{}',
  reasoning    text,
  confidence   smallint NOT NULL CHECK (confidence BETWEEN 0 AND 100),
  is_selected  boolean NOT NULL DEFAULT false,
  audit_id     bigint REFERENCES customs.audit_log (id),
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX line_classifications_line_idx ON customs.line_classifications (line_id);

CREATE TABLE customs.calculations (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id        uuid NOT NULL REFERENCES customs.cases (id) ON DELETE CASCADE,
  country        char(2) NOT NULL DEFAULT 'NI',
  calc_date      date NOT NULL,
  currency       char(3) NOT NULL,
  exchange_rate  numeric(18, 6) NOT NULL CHECK (exchange_rate > 0),
  input          jsonb NOT NULL,
  result         jsonb NOT NULL,
  warnings       jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_cif      numeric(18, 2) NOT NULL,
  total_taxes    numeric(18, 2) NOT NULL,
  created_by     uuid,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX calculations_case_idx ON customs.calculations (case_id, created_at DESC);

CREATE TABLE customs.classification_history (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country             char(2) NOT NULL DEFAULT 'NI',
  product_description text NOT NULL,
  embedding           vector(1024),
  accepted_code       text NOT NULL CHECK (accepted_code ~ '^[0-9]{4,12}$'),
  case_id             uuid REFERENCES customs.cases (id) ON DELETE SET NULL,
  line_id             uuid REFERENCES customs.lines (id) ON DELETE SET NULL,
  approved_by         uuid NOT NULL,
  approved_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX classification_history_country_idx ON customs.classification_history (country);
CREATE INDEX classification_history_embedding_idx ON customs.classification_history
  USING hnsw (embedding vector_cosine_ops);
