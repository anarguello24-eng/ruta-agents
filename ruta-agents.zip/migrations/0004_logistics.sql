-- 0004_logistics: freight rate cards, quotes, shipments, tracking.

CREATE SCHEMA IF NOT EXISTS logistics;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA logistics FROM anon';
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    EXECUTE 'REVOKE ALL ON SCHEMA logistics FROM authenticated';
  END IF;
END $$;

-- Locations use UN/LOCODE (e.g. USMIA Miami, NIMGA Managua, NICIO Corinto, CNSHA Shanghai).
CREATE TABLE logistics.rate_cards (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code                text NOT NULL UNIQUE,
  country             char(2) NOT NULL DEFAULT 'NI',
  carrier             text NOT NULL,
  mode                text NOT NULL CHECK (mode IN ('air', 'courier', 'sea_lcl', 'sea_fcl', 'ground')),
  origin              text NOT NULL CHECK (origin ~ '^[A-Z]{2}[A-Z0-9]{3}$'),
  destination         text NOT NULL CHECK (destination ~ '^[A-Z]{2}[A-Z0-9]{3}$'),
  container_type      text CHECK (container_type IN ('20GP', '40GP', '40HC', '40RF')),
  -- kg (air/courier/ground), wm (sea LCL: revenue ton = max(m3, t)), container (FCL)
  unit                text NOT NULL CHECK (unit IN ('kg', 'wm', 'container')),
  volumetric_divisor  integer CHECK (volumetric_divisor IS NULL OR volumetric_divisor > 0),
  min_charge          numeric(18, 2) NOT NULL DEFAULT 0,
  currency            char(3) NOT NULL,
  transit_days_min    integer,
  transit_days_max    integer,
  effective_from      date NOT NULL,
  effective_to        date,
  is_sample           boolean NOT NULL DEFAULT false,
  source_url          text,
  notes               text,
  CHECK (effective_to IS NULL OR effective_to >= effective_from),
  CHECK ((mode = 'sea_fcl') = (container_type IS NOT NULL)),
  CHECK (mode NOT IN ('air', 'courier') OR volumetric_divisor IS NOT NULL)
);
CREATE INDEX rate_cards_lane_idx ON logistics.rate_cards (country, mode, origin, destination);

-- Weight/volume breaks: the rate applies from `from_qty` (in the card's unit) upwards.
CREATE TABLE logistics.rate_breaks (
  rate_card_id uuid NOT NULL REFERENCES logistics.rate_cards (id) ON DELETE CASCADE,
  from_qty     numeric(18, 3) NOT NULL CHECK (from_qty >= 0),
  rate         numeric(18, 4) NOT NULL CHECK (rate >= 0),
  PRIMARY KEY (rate_card_id, from_qty)
);

CREATE TABLE logistics.surcharges (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rate_card_id uuid NOT NULL REFERENCES logistics.rate_cards (id) ON DELETE CASCADE,
  code         text NOT NULL,
  name_es      text NOT NULL,
  name_en      text NOT NULL,
  basis        text NOT NULL CHECK (basis IN ('per_unit', 'per_shipment', 'per_container', 'percent_of_freight')),
  amount       numeric(18, 4) NOT NULL CHECK (amount >= 0),
  min_amount   numeric(18, 2),
  UNIQUE (rate_card_id, code)
);

CREATE TABLE logistics.shipments (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country             char(2) NOT NULL DEFAULT 'NI',
  reference           text NOT NULL UNIQUE,
  client_ref          text,
  mode                text NOT NULL CHECK (mode IN ('air', 'courier', 'sea_lcl', 'sea_fcl', 'ground')),
  origin              text NOT NULL,
  destination         text NOT NULL,
  carrier             text,
  carrier_ref         text,
  status              text NOT NULL DEFAULT 'booked',
  eta_promised        date,
  eta_current         date,
  arrived_at          timestamptz,
  status_since        timestamptz NOT NULL DEFAULT now(),
  last_event_at       timestamptz,
  free_days           integer,
  quote               jsonb,
  customs_case_id     uuid,
  trade_operation_id  uuid,
  rfq_id              uuid,
  lang                char(2) NOT NULL DEFAULT 'es' CHECK (lang IN ('es', 'en')),
  created_by          uuid,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX shipments_status_idx ON logistics.shipments (country, status);
CREATE TRIGGER shipments_touch BEFORE UPDATE ON logistics.shipments
  FOR EACH ROW EXECUTE FUNCTION core.touch_updated_at();

CREATE TABLE logistics.packages (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id  uuid NOT NULL REFERENCES logistics.shipments (id) ON DELETE CASCADE,
  qty          integer NOT NULL CHECK (qty > 0),
  length_cm    numeric(10, 2) NOT NULL CHECK (length_cm > 0),
  width_cm     numeric(10, 2) NOT NULL CHECK (width_cm > 0),
  height_cm    numeric(10, 2) NOT NULL CHECK (height_cm > 0),
  weight_kg    numeric(12, 3) NOT NULL CHECK (weight_kg > 0),
  description  text
);

CREATE TABLE logistics.tracking_events (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shipment_id  uuid NOT NULL REFERENCES logistics.shipments (id) ON DELETE CASCADE,
  status       text NOT NULL,
  occurred_at  timestamptz NOT NULL,
  location     text,
  description  text,
  source       text NOT NULL CHECK (source IN ('carrier', 'manual', 'ai')),
  raw          jsonb,
  created_by   uuid,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tracking_events_shipment_idx ON logistics.tracking_events (shipment_id, occurred_at);

CREATE TABLE logistics.audit_log (
  id               bigserial PRIMARY KEY,
  country          char(2) NOT NULL DEFAULT 'NI',
  shipment_id      uuid REFERENCES logistics.shipments (id) ON DELETE SET NULL,
  entity_type      text NOT NULL,
  entity_id        text,
  actor_type       text NOT NULL CHECK (actor_type IN ('ai', 'user', 'system')),
  actor_id         text,
  action           text NOT NULL,
  prompt_version   text,
  model            text,
  input_hash       text,
  raw_output       text,
  validated_output jsonb,
  before           jsonb,
  after            jsonb,
  error            text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT audit_ai_fields CHECK (actor_type <> 'ai' OR (prompt_version IS NOT NULL AND model IS NOT NULL AND input_hash IS NOT NULL)),
  CONSTRAINT audit_user_fields CHECK (actor_type <> 'user' OR actor_id IS NOT NULL)
);
CREATE INDEX logistics_audit_log_ref_idx ON logistics.audit_log (shipment_id, created_at);
CREATE TRIGGER audit_log_no_update BEFORE UPDATE OR DELETE ON logistics.audit_log
  FOR EACH ROW EXECUTE FUNCTION core.append_only();
